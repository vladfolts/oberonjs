var RTL$ = require("rtl.js");
var Code = require("js/Code.js");
var EberonTypes = require("js/EberonTypes.js");
var Errors = require("js/Errors.js");
var LanguageContext = require("js/LanguageContext.js");
var Procedure = require("js/Procedure.js");
var Types = require("js/Types.js");
var methodNameIndexOf = "indexOf";
function Method(){
	Procedure.Std.call(this);
}
RTL$.extend(Method, Procedure.Std);
function MethodField(){
	Types.Field.call(this);
	this.method = null;
}
RTL$.extend(MethodField, Types.Field);
function MethodIndexOf(){
	Method.call(this);
	this.elementsType = null;
}
RTL$.extend(MethodIndexOf, Method);
function MethodCallIndexOf(){
	Procedure.StdCall.call(this);
}
RTL$.extend(MethodCallIndexOf, Procedure.StdCall);
function StaticArray(){
	Types.StaticArray.call(this);
}
RTL$.extend(StaticArray, Types.StaticArray);
function OpenArray(){
	Types.OpenArray.call(this);
}
RTL$.extend(OpenArray, Types.OpenArray);
Method.prototype.description = function(){
	return "array method '" + this.name + "'";
}
MethodField.prototype.id = function(){
	return this.method.name;
}
MethodField.prototype.exported = function(){
	return false;
}
MethodField.prototype.type = function(){
	return this.method;
}
MethodField.prototype.asVar = function(){
	return EberonTypes.makeMethod(this.method);
}

function makeIndexOfMethod(elementsType/*PType*/){
	var result = null;
	result = new MethodIndexOf();
	result.name = methodNameIndexOf;
	result.elementsType = elementsType;
	return result;
}
MethodIndexOf.prototype.designatorCode = function(id/*STRING*/){
	return "indexOf";
}
MethodIndexOf.prototype.callGenerator = function(cx/*PType*/){
	var a = null;
	var call = null;
	call = new MethodCallIndexOf();
	Procedure.initStdCall(call);
	a = new Types.ProcedureArgument();
	a.type = this.elementsType;
	call.args.push(a);
	return Procedure.makeCallGenerator(call, cx);
}
MethodCallIndexOf.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
	var argCode = Procedure.makeArgumentsCode(cx);
	var argType = Procedure.checkSingleArgument(args, this, cx.types, argCode).type();
	return Code.makeSimpleExpression("(" + argCode.result() + ")", Types.basic().integer);
}

function denoteMethod(id/*STRING*/, elementsType/*PType*/){
	var result = null;
	if (id == methodNameIndexOf){
		result = makeIndexOfMethod(elementsType);
	}
	return result;
}

function makeMethodField(method/*PMethod*/){
	var result = null;
	result = new MethodField();
	result.method = method;
	return result;
}

function denote(id/*STRING*/, a/*Array*/){
	var result = null;
	if (id == methodNameIndexOf){
		if (a.elementsType instanceof Types.Record || a.elementsType instanceof Types.Array){
			Errors.raise("'" + methodNameIndexOf + "' is not defined for array of '" + a.elementsType.description() + "'");
		}
		result = makeMethodField(makeIndexOfMethod(a.elementsType));
	}
	return result;
}
StaticArray.prototype.denote = function(id/*STRING*/){
	var result = denote(id, this);
	if (result == null){
		result = Types.StaticArray.prototype.denote.call(this, id);
	}
	return result;
}
OpenArray.prototype.denote = function(id/*STRING*/){
	var result = denote(id, this);
	if (result == null){
		result = Types.OpenArray.prototype.denote.call(this, id);
	}
	return result;
}

function makeStaticArray(initializer/*STRING*/, elementsType/*PType*/, len/*INTEGER*/){
	var result = null;
	result = new StaticArray();
	Types.initStaticArray(initializer, elementsType, len, result);
	return result;
}

function makeOpenArray(elementsType/*PType*/){
	var result = null;
	result = new OpenArray();
	Types.initArray(elementsType, result);
	return result;
}
exports.Method = Method;
exports.denoteMethod = denoteMethod;
exports.makeMethodField = makeMethodField;
exports.makeStaticArray = makeStaticArray;
exports.makeOpenArray = makeOpenArray;
