var Code = require("js/Code.js");
var EberonTypes = require("js/EberonTypes.js");
var Errors = require("js/Errors.js");
var LanguageContext = require("js/LanguageContext.js");
var Procedure = require("js/Procedure.js");
var Types = require("js/Types.js");
var methodNameIndexOf = "indexOf";
var Method = Procedure.Std.extend({
	init: function Method(){
		Procedure.Std.prototype.init.call(this);
	}
});
var MethodField = Types.Field.extend({
	init: function MethodField(){
		Types.Field.prototype.init.call(this);
		this.method = null;
	}
});
var MethodIndexOf = Method.extend({
	init: function MethodIndexOf(){
		Method.prototype.init.call(this);
		this.elementsType = null;
	}
});
var MethodCallIndexOf = Procedure.StdCall.extend({
	init: function MethodCallIndexOf(){
		Procedure.StdCall.prototype.init.call(this);
	}
});
var StaticArray = Types.StaticArray.extend({
	init: function StaticArray(){
		Types.StaticArray.prototype.init.call(this);
	}
});
Method.prototype.description = function(){
	return "array method '" + this.name + "'";
}
MethodField.prototype.id = function(){
	return "add";
}
MethodField.prototype.exported = function(){
	return false;
}
MethodField.prototype.type = function(){
	return this.method;
}
MethodField.prototype.asVar = function(){
	return EberonTypes.makeMethod(this.method);
}

function makeIndexOfMethod(elementsType/*PType*/){
	var result = null;
	result = new MethodIndexOf();
	result.name = methodNameIndexOf;
	result.elementsType = elementsType;
	return result;
}
MethodIndexOf.prototype.designatorCode = function(id/*STRING*/){
	return "indexOf";
}
MethodIndexOf.prototype.callGenerator = function(cx/*PType*/){
	var a = null;
	var call = null;
	call = new MethodCallIndexOf();
	Procedure.initStdCall(call);
	a = new Types.ProcedureArgument();
	a.type = this.elementsType;
	call.args.push(a);
	return Procedure.makeCallGenerator(call, cx);
}
MethodCallIndexOf.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
	var argCode = Procedure.makeArgumentsCode(cx);
	var argType = Procedure.checkSingleArgument(args, this, cx.types, argCode).type();
	return Code.makeSimpleExpression("(" + argCode.result() + ")", Types.basic().integer);
}

function denoteMethod(id/*STRING*/, elementsType/*PType*/){
	var result = null;
	if (id == methodNameIndexOf){
		result = makeIndexOfMethod(elementsType);
	}
	return result;
}
StaticArray.prototype.denote = function(id/*STRING*/){
	var field = null;
	var result = null;
	if (id == methodNameIndexOf){
		if (this.elementsType instanceof Types.Record || this.elementsType instanceof Types.Array){
			Errors.raise("'" + methodNameIndexOf + "' is not defined for array of '" + this.elementsType.description() + "'");
		}
		field = new MethodField();
		field.method = makeIndexOfMethod(this.elementsType);
		result = field;
	}
	else {
		result = Types.StaticArray.prototype.denote.call(this, id);
	}
	return result;
}

function makeStaticArray(initializer/*STRING*/, elementsType/*PType*/, len/*INTEGER*/){
	var result = null;
	result = new StaticArray();
	Types.initStaticArray(initializer, elementsType, len, result);
	return result;
}
exports.Method = Method;
exports.MethodField = MethodField;
exports.denoteMethod = denoteMethod;
exports.makeStaticArray = makeStaticArray;
