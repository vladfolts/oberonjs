var RTL$ = require("rtl.js");
var OberonRtl = require("js/OberonRtl.js");
function Type(){
	OberonRtl.Type.call(this);
	this.clearMap = null;
}
RTL$.extend(Type, OberonRtl.Type);
exports.Type = Type;
