var RTL$ = require("eberon/eberon_rtl.js");
var OberonRtl = require("js/OberonRtl.js");
function Type(){
	OberonRtl.Type.call(this);
	this.clearMap = null;
	this.cloneMapOfScalars = null;
	this.copyMapOfScalars = null;
}
RTL$.extend(Type, OberonRtl.Type);
exports.Type = Type;
