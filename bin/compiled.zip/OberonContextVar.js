var RTL$ = require("eberon/eberon_rtl.js");
var ContextVar = require("js/ContextVar.js");
var Errors = require("js/Errors.js");
var Types = require("js/Types.js");
var $scope = "OberonContextVar";
function Declaration(){
	ContextVar.Declaration.apply(this, arguments);
}
RTL$.extend(Declaration, ContextVar.Declaration, $scope);
Declaration.prototype.doCheckExport = function(id/*STRING*/){
	var type = this.type;
	if (type instanceof Types.Record || type instanceof Types.Array){
		Errors.raise("variable '" + id + "' cannot be exported: only scalar variables can be exported");
	}
};
exports.Declaration = Declaration;
