var JS = GLOBAL;
var Object = require("js/Object.js");
function Type(){
}
function Strings(){
}

function make(){
	var result = null;
	result = {};
	return result;
}

function has(m/*Type*/, s/*STRING*/){
	var result = false;
	result = m.hasOwnProperty(s);
	return result;
}

function find(m/*Type*/, s/*STRING*/, r/*VAR PType*/){
	var result = false;
	var value = m[s]; if (value !== undefined){result = true; r.set(value);};
	return result;
}

function put(m/*Type*/, s/*STRING*/, o/*PType*/){
	m[s] = o;
}

function erase(m/*Type*/, s/*STRING*/){
	delete m[s];
}

function forEach(m/*Type*/, p/*ForEachProc*/, closure/*VAR Type*/){
	for(var key in m){p(key, m[key], closure)};
}

function forEachString(m/*Strings*/, p/*ForEachStringProc*/, closure/*VAR Type*/){
	for(var key in m){p(key, m[key], closure)};
}
exports.Type = Type;
exports.Strings = Strings;
exports.make = make;
exports.has = has;
exports.find = find;
exports.put = put;
exports.erase = erase;
exports.forEach = forEach;
exports.forEachString = forEachString;
