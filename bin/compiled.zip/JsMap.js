var JS = GLOBAL;
var Object = require("js/Object.js");
function Type(){
}
function Strings(){
}

function make(){
	var result = null;
	result = {};
	return result;
}

function makeStrings(){
	var result = null;
	result = {};
	return result;
}

function has(m/*Type*/, s/*STRING*/){
	var result = false;
	result = m.hasOwnProperty(s);
	return result;
}

function find(m/*Type*/, s/*STRING*/, r/*VAR PType*/){
	var result = false;
	if (m.hasOwnProperty(s)){result = true; r.set(m[s]);};
	return result;
}

function put(m/*Type*/, s/*STRING*/, o/*PType*/){
	m[s] = o;
}

function putString(m/*Strings*/, s/*STRING*/, v/*STRING*/){
	m[s] = v;
}

function erase(m/*Type*/, s/*STRING*/){
	delete m[s];
}

function keys(m/*Type*/){
	var result = [];
	result = JS.Object.keys(m);;
	return result.slice();
}

function forEach(m/*Type*/, p/*ForEachProc*/, closure/*VAR Type*/){
	for(var key in m){p(key, m[key], closure)};
}

function forEachString(m/*Strings*/, p/*ForEachStringProc*/, closure/*VAR Type*/){
	for(var key in m){p(key, m[key], closure)};
}
exports.Type = Type;
exports.Strings = Strings;
exports.make = make;
exports.makeStrings = makeStrings;
exports.has = has;
exports.find = find;
exports.put = put;
exports.putString = putString;
exports.erase = erase;
exports.keys = keys;
exports.forEach = forEach;
exports.forEachString = forEachString;
