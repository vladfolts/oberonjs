var RTL$ = require("eberon/eberon_rtl.js");
var Cast = require("js/Cast.js");
var Code = require("js/Code.js");
var Context = require("js/Context.js");
var Errors = require("js/Errors.js");
var LanguageContext = require("js/LanguageContext.js");
var OberonRtl = require("js/OberonRtl.js");
var Object$ = require("js/Object$.js");
var Operator = require("js/Operator.js");
var Precedence = require("js/CodePrecedence.js");
var String = require("js/String.js");
var Symbols = require("js/Symbols.js");
var Types = require("js/Types.js");
function Call(){
}
function StdCall(){
	Call.call(this);
	this.args = [];
}
RTL$.extend(StdCall, Call);
function CallLen(){
	StdCall.call(this);
	this.check = null;
}
RTL$.extend(CallLen, StdCall);
function CallGenerator(){
}
function CallGeneratorImpl(){
	CallGenerator.call(this);
	this.args = [];
	this.cx = null;
	this.call = null;
}
RTL$.extend(CallGeneratorImpl, CallGenerator);
function Type(){
	Types.DefinedProcedure.apply(this, arguments);
	this.mArgs = [];
	this.mResult = null;
}
RTL$.extend(Type, Types.DefinedProcedure);
RTL$.extend(Std, Types.Procedure);
function ArgumentsCode(){
}
function GenArgCode(){
	ArgumentsCode.call(this);
	this.code = '';
	this.cx = null;
}
RTL$.extend(GenArgCode, ArgumentsCode);
var predefined = [];

function checkArgument(actual/*PExpression*/, expected/*PProcedureArgument*/, pos/*INTEGER*/, code/*PArgumentsCode*/, types/*PTypes*/){
	var actualType = null;var expectType = null;
	var designator = null;
	var result = null;
	var castErr = 0;
	expectType = expected.type;
	if (expectType != null){
		actualType = actual.type();
		castErr = types.implicitCast(actualType, expectType, expected.isVar, {set: function($v){result = $v;}, get: function(){return result;}});
		if (castErr == Cast.errVarParameter){
			Errors.raise("type mismatch for argument " + String.fromInt(pos + 1 | 0) + ": cannot pass '" + actualType.description() + "' as VAR parameter of type '" + expectType.description() + "'");
		}
		else if (castErr != Cast.errNo){
			Errors.raise("type mismatch for argument " + String.fromInt(pos + 1 | 0) + ": '" + actualType.description() + "' cannot be converted to '" + expectType.description() + "'");
		}
	}
	if (expected.isVar){
		designator = actual.designator();
		if (designator == null){
			Errors.raise("expression cannot be used as VAR parameter");
		}
		var info = designator.info();
		if (!(info instanceof Types.Variable) || info.isReadOnly()){
			Errors.raise(info.idType() + " cannot be passed as VAR actual parameter");
		}
	}
	if (code != null){
		code.write(actual, expected, result);
	}
}

function checkArgumentsType(actual/*ARRAY OF PExpression*/, expected/*ARRAY OF PProcedureArgument*/, code/*PArgumentsCode*/, types/*PTypes*/){
	for (var i = 0; i <= actual.length - 1 | 0; ++i){
		checkArgument(actual[i], expected[i], i, code, types);
	}
}

function checkArgumentsCount(actual/*INTEGER*/, expected/*INTEGER*/){
	if (actual != expected){
		Errors.raise(String.fromInt(expected) + " argument(s) expected, got " + String.fromInt(actual));
	}
}

function processArguments(actual/*ARRAY OF PExpression*/, expected/*ARRAY OF PProcedureArgument*/, code/*PArgumentsCode*/, types/*PTypes*/){
	checkArgumentsCount(actual.length, expected.length);
	checkArgumentsType(actual, expected, code, types);
}

function checkArguments(actual/*ARRAY OF PExpression*/, expected/*ARRAY OF PProcedureArgument*/, types/*PTypes*/){
	processArguments(actual, expected, null, types);
}
function Std(name/*STRING*/, call/*PCall*/){
	Types.Procedure.call(this, name);
	this.call = null;
	this.call = call;
}
CallGeneratorImpl.prototype.handleArgument = function(e/*PExpression*/){
	this.args.push(e);
}
CallGeneratorImpl.prototype.end = function(){
	return this.call.make(this.args, this.cx);
}

function makeCallGenerator(call/*PCall*/, cx/*PType*/){
	RTL$.assert(cx != null);
	var result = new CallGeneratorImpl();
	result.cx = cx;
	result.call = call;
	return result;
}
GenArgCode.prototype.write = function(actual/*PExpression*/, expected/*PProcedureArgument*/, cast/*PCastOp*/){
	var e = null;
	var coercedArg = null;
	if (expected != null && expected.isVar){
		var referenceCode = RTL$.typeGuard(actual.designator().info(), Types.Variable).referenceCode();
		coercedArg = Code.makeSimpleExpression(referenceCode, actual.type());
	}
	else {
		coercedArg = Code.derefExpression(actual);
	}
	if (this.code.length != 0){
		this.code = this.code + ", ";
	}
	if (cast != null){
		e = cast.make(this.cx, coercedArg);
	}
	else {
		e = coercedArg;
	}
	this.code = this.code + e.code();
}
GenArgCode.prototype.result = function(){
	return this.code;
}

function makeProcCallGeneratorWithCustomArgs(cx/*PType*/, type/*DefinedProcedure*/, argumentsCode/*PArgumentsCode*/){
	function CallImpl(){
		Call.call(this);
		this.args = [];
		this.result = null;
		this.argumentsCode = null;
	}
	RTL$.extend(CallImpl, Call);
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		processArguments(args, this.args, this.argumentsCode, cx.types);
		return Code.makeSimpleExpression("(" + this.argumentsCode.result() + ")", this.result);
	}
	var call = new CallImpl();
	Array.prototype.splice.apply(call.args, [0, Number.MAX_VALUE].concat(type.args()));
	call.result = type.result();
	call.argumentsCode = argumentsCode;
	return makeCallGenerator(call, cx);
}

function makeArgumentsCode(cx/*PType*/){
	var result = new GenArgCode();
	result.cx = cx;
	return result;
}

function makeProcCallGenerator(cx/*PType*/, type/*DefinedProcedure*/){
	return makeProcCallGeneratorWithCustomArgs(cx, type, makeArgumentsCode(cx));
}
Std.prototype.description = function(){
	return "standard procedure " + this.name;
}
Std.prototype.callGenerator = function(cx/*PType*/){
	return makeCallGenerator(this.call, cx);
}
Std.prototype.designatorCode = function(id/*STRING*/){
	return "";
}

function makeSymbol(p/*PProcedure*/){
	return new Symbols.Symbol(p.name, new Types.ProcedureId(p));
}

function hasArgument(call/*PStdCall*/, type/*PType*/){
	call.args.push(new Types.ProcedureArgument(type, false));
}

function hasVarArgument(call/*PStdCall*/, type/*PType*/){
	call.args.push(new Types.ProcedureArgument(type, true));
}

function hasArgumentWithCustomType(call/*PStdCall*/){
	call.args.push(new Types.ProcedureArgument(null, false));
}

function hasVarArgumnetWithCustomType(call/*PStdCall*/){
	call.args.push(new Types.ProcedureArgument(null, true));
}

function checkSingleArgument(actual/*ARRAY OF PExpression*/, call/*StdCall*/, types/*PTypes*/, code/*PArgumentsCode*/){
	RTL$.assert(call.args.length == 1);
	processArguments(actual, call.args, code, types);
	RTL$.assert(actual.length == 1);
	return actual[0];
}

function makeNew(){
	function CallImpl(){
		StdCall.call(this);
	}
	RTL$.extend(CallImpl, StdCall);
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var result = null;
		var arg = checkSingleArgument(args, this, cx.types, null);
		var argType = arg.type();
		if (!(argType instanceof Types.Pointer)){
			Errors.raise("POINTER variable expected, got '" + argType.description() + "'");
		}
		else {
			var baseType = Types.pointerBase(argType);
			if (baseType instanceof Types.NonExportedRecord){
				Errors.raise("non-exported RECORD type cannot be used in NEW");
			}
			var right = Code.makeSimpleExpression(baseType.codeForNew(cx), argType);
			result = Code.makeSimpleExpression(Operator.assign(arg, right, cx), null);
		}
		return result;
	}
	var call = new CallImpl();
	hasVarArgumnetWithCustomType(call);
	return makeSymbol(new Std("NEW", call));
}

function lenArgumentCheck(argType/*PType*/){
	return argType instanceof Types.Array || argType instanceof Types.String;
}
CallLen.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
	var arg = null;
	var argType = null;
	arg = checkSingleArgument(args, this, cx.types, null);
	argType = arg.type();
	if (!this.check(argType)){
		Errors.raise("ARRAY or string is expected as an argument of LEN, got '" + argType.description() + "'");
	}
	return Code.makeSimpleExpression(arg.code() + ".length", Types.basic().integer);
}

function makeLen(check/*LenArgumentCheck*/){
	var call = new CallLen();
	call.check = check;
	hasArgumentWithCustomType(call);
	return makeSymbol(new Std("LEN", call));
}

function makeOdd(){
	function CallImpl(){
		StdCall.call(this);
	}
	RTL$.extend(CallImpl, StdCall);
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var arg = null;
		var code = '';
		var constValue = null;
		arg = checkSingleArgument(args, this, cx.types, null);
		code = Code.adjustPrecedence(arg, Precedence.bitAnd);
		constValue = arg.constValue();
		if (constValue != null){
			constValue = Code.makeIntConst(RTL$.typeGuard(constValue, Code.IntConst).value & 1 ? 1 : 0);
		}
		return new Code.Expression(code + " & 1", Types.basic().bool, null, constValue, Precedence.bitAnd);
	}
	var call = new CallImpl();
	hasArgument(call, Types.basic().integer);
	return makeSymbol(new Std("ODD", call));
}

function makeAssert(){
	function CallImpl(){
		StdCall.call(this);
	}
	RTL$.extend(CallImpl, StdCall);
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var arg = null;
		arg = checkSingleArgument(args, this, cx.types, null);
		return Code.makeSimpleExpression(cx.rtl.assertId() + "(" + arg.code() + ")", null);
	}
	var call = new CallImpl();
	hasArgument(call, Types.basic().bool);
	return makeSymbol(new Std("ASSERT", call));
}

function setBitImpl(name/*STRING*/, bitOp/*BinaryOpStr*/){
	function CallImpl(){
		StdCall.call(this);
		this.name = '';
		this.bitOp = null;
	}
	RTL$.extend(CallImpl, StdCall);
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var x = null;var y = null;
		var yValue = 0;
		var value = null;
		var valueCodeExp = null;
		var valueCode = '';
		var comment = '';
		checkArguments(args, this.args, cx.types);
		RTL$.assert(args.length == 2);
		x = args[0];
		y = args[1];
		value = y.constValue();
		if (value == null){
			valueCodeExp = Operator.lsl(Code.makeExpression("1", Types.basic().integer, null, Code.makeIntConst(1)), y);
			valueCode = valueCodeExp.code();
		}
		else {
			yValue = RTL$.typeGuard(value, Code.IntConst).value;
			if (yValue < 0 || yValue > 31){
				Errors.raise("value (0..31) expected as a second argument of " + this.name + ", got " + String.fromInt(yValue));
			}
			comment = "bit: ";
			if (y.isTerm()){
				comment = comment + String.fromInt(yValue);
			}
			else {
				comment = comment + Code.adjustPrecedence(y, Precedence.shift);
			}
			yValue = 1 << yValue;
			valueCode = String.fromInt(yValue) + "/*" + comment + "*/";
		}
		return Code.makeSimpleExpression(this.bitOp(Code.adjustPrecedence(x, Precedence.assignment), valueCode), null);
	}
	var call = new CallImpl();
	call.name = name;
	call.bitOp = bitOp;
	hasVarArgument(call, Types.basic().set);
	hasArgument(call, Types.basic().integer);
	return makeSymbol(new Std(call.name, call));
}

function checkVariableArgumentsCount(min/*INTEGER*/, max/*INTEGER*/, actual/*ARRAY OF PExpression*/){
	var len = actual.length;
	if (len < min){
		Errors.raise("at least " + String.fromInt(min) + " argument expected, got " + String.fromInt(len));
	}
	else if (len > max){
		Errors.raise("at most " + String.fromInt(max) + " arguments expected, got " + String.fromInt(len));
	}
}

function incImpl(name/*STRING*/, unary/*STRING*/, incOp/*BinaryOpStr*/, incRefOp/*BinaryProc*/){
	function CallImpl(){
		StdCall.call(this);
		this.name = '';
		this.unary = '';
		this.incOp = null;
		this.incRefOp = null;
	}
	RTL$.extend(CallImpl, StdCall);
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var x = null;var y = null;
		var code = '';
		var value = null;
		var valueCode = '';
		checkVariableArgumentsCount(1, 2, args);
		checkArgumentsType(args, this.args, null, cx.types);
		x = args[0];
		if (Cast.passedByReference(x)){
			if (args.length == 1){
				y = Code.makeSimpleExpression("1", null);
			}
			else {
				y = args[1];
			}
			var addExp = this.incRefOp(x, y);
			code = Cast.assignByReference(x, addExp);
		}
		else if (args.length == 1){
			code = this.unary + x.code();
		}
		else {
			y = args[1];
			value = y.constValue();
			if (value == null){
				valueCode = y.code();
			}
			else {
				valueCode = String.fromInt(RTL$.typeGuard(value, Code.IntConst).value);
				if (!y.isTerm()){
					valueCode = valueCode + "/*" + y.code() + "*/";
				}
			}
			code = this.incOp(x.code(), valueCode);
		}
		return Code.makeSimpleExpression(code, null);
	}
	var call = new CallImpl();
	call.name = name;
	call.unary = unary;
	call.incOp = incOp;
	call.incRefOp = incRefOp;
	hasVarArgument(call, Types.basic().integer);
	hasArgument(call, Types.basic().integer);
	return makeSymbol(new Std(call.name, call));
}

function inclOp(x/*STRING*/, y/*STRING*/){
	return x + " |= " + y;
}

function exclOp(x/*STRING*/, y/*STRING*/){
	return x + " &= ~(" + y + ")";
}

function incOp(x/*STRING*/, y/*STRING*/){
	return x + " += " + y;
}

function decOp(x/*STRING*/, y/*STRING*/){
	return x + " -= " + y;
}

function makeAbs(){
	function CallImpl(){
		StdCall.call(this);
	}
	RTL$.extend(CallImpl, StdCall);
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var arg = null;
		var argType = null;
		arg = checkSingleArgument(args, this, cx.types, null);
		argType = arg.type();
		if (Types.numeric().indexOf(argType) == -1){
			Errors.raise("type mismatch: expected numeric type, got '" + argType.description() + "'");
		}
		return Code.makeSimpleExpression("Math.abs(" + arg.code() + ")", argType);
	}
	var call = new CallImpl();
	hasArgumentWithCustomType(call);
	return makeSymbol(new Std("ABS", call));
}

function makeFloor(){
	function CallImpl(){
		StdCall.call(this);
	}
	RTL$.extend(CallImpl, StdCall);
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var arg = null;
		arg = checkSingleArgument(args, this, cx.types, null);
		var code = Code.adjustPrecedence(arg, Precedence.bitOr) + " | 0";
		return new Code.Expression(code, Types.basic().integer, null, null, Precedence.bitOr);
	}
	var call = new CallImpl();
	hasArgument(call, Types.basic().real);
	return makeSymbol(new Std("FLOOR", call));
}

function makeFlt(){
	function CallImpl(){
		StdCall.call(this);
	}
	RTL$.extend(CallImpl, StdCall);
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var arg = null;
		var value = null;
		arg = checkSingleArgument(args, this, cx.types, null);
		value = arg.constValue();
		if (value != null){
			value = Code.makeRealConst(RTL$.typeGuard(value, Code.IntConst).value);
		}
		return new Code.Expression(arg.code(), Types.basic().real, null, value, arg.maxPrecedence());
	}
	var call = new CallImpl();
	hasArgument(call, Types.basic().integer);
	return makeSymbol(new Std("FLT", call));
}

function bitShiftImpl(name/*STRING*/, op/*BinaryProc*/){
	function CallImpl(){
		StdCall.call(this);
		this.name = '';
		this.op = null;
	}
	RTL$.extend(CallImpl, StdCall);
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		checkArguments(args, this.args, cx.types);
		RTL$.assert(args.length == 2);
		return this.op(args[0], args[1]);
	}
	var call = new CallImpl();
	call.name = name;
	call.op = op;
	hasArgument(call, Types.basic().integer);
	hasArgument(call, Types.basic().integer);
	return makeSymbol(new Std(call.name, call));
}

function makeOrd(){
	function CallImpl(){
		StdCall.call(this);
	}
	RTL$.extend(CallImpl, StdCall);
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var arg = null;
		var argType = null;
		var value = null;
		var code = '';
		var ch = 0;
		var result = null;
		arg = checkSingleArgument(args, this, cx.types, null);
		argType = arg.type();
		if (argType == Types.basic().ch || argType == Types.basic().set){
			value = arg.constValue();
			if (value != null && argType == Types.basic().set){
				value = Code.makeIntConst(RTL$.typeGuard(value, Code.SetConst).value);
			}
			result = Code.makeExpression(arg.code(), Types.basic().integer, null, value);
		}
		else if (argType == Types.basic().bool){
			code = Code.adjustPrecedence(arg, Precedence.conditional) + " ? 1 : 0";
			result = new Code.Expression(code, Types.basic().integer, null, arg.constValue(), Precedence.conditional);
		}
		else if (argType instanceof Types.String && Types.stringAsChar(RTL$.typeGuard(argType, Types.String), {set: function($v){ch = $v;}, get: function(){return ch;}})){
			result = Code.makeExpression(String.fromInt(ch), Types.basic().integer, null, Code.makeIntConst(ch));
		}
		else {
			Errors.raise("ORD function expects CHAR or BOOLEAN or SET as an argument, got '" + argType.description() + "'");
		}
		return result;
	}
	var call = new CallImpl();
	hasArgumentWithCustomType(call);
	return makeSymbol(new Std("ORD", call));
}

function makeChr(){
	function CallImpl(){
		StdCall.call(this);
	}
	RTL$.extend(CallImpl, StdCall);
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var arg = null;
		arg = checkSingleArgument(args, this, cx.types, null);
		return Code.makeSimpleExpression(arg.code(), Types.basic().ch);
	}
	var call = new CallImpl();
	hasArgument(call, Types.basic().integer);
	return makeSymbol(new Std("CHR", call));
}

function makePack(){
	function CallImpl(){
		StdCall.call(this);
	}
	RTL$.extend(CallImpl, StdCall);
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var x = null;var y = null;
		checkArguments(args, this.args, cx.types);
		x = args[0];
		y = args[1];
		return Code.makeSimpleExpression(Operator.mulInplace(x, Operator.pow2(y), cx), null);
	}
	var call = new CallImpl();
	hasVarArgument(call, Types.basic().real);
	hasArgument(call, Types.basic().integer);
	return makeSymbol(new Std("PACK", call));
}

function makeUnpk(){
	function CallImpl(){
		StdCall.call(this);
	}
	RTL$.extend(CallImpl, StdCall);
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var x = null;var y = null;
		checkArguments(args, this.args, cx.types);
		x = args[0];
		y = args[1];
		return Code.makeSimpleExpression(Operator.assign(y, Operator.log2(x), cx) + "; " + Operator.divInplace(x, Operator.pow2(y), cx), null);
	}
	var call = new CallImpl();
	hasVarArgument(call, Types.basic().real);
	hasVarArgument(call, Types.basic().integer);
	return makeSymbol(new Std("UNPK", call));
}

function dumpProcArgs(proc/*Type*/){
	var result = '';
	var len = proc.mArgs.length;
	if (len == 0){
		if (proc.mResult != null){
			result = "()";
		}
	}
	else {
		result = "(";
		for (var i = 0; i <= len - 1 | 0; ++i){
			if (i != 0){
				result = result + ", ";
			}
			var arg = proc.mArgs[i];
			RTL$.assert(arg.type != null);
			result = result + arg.type.description();
		}
		result = result + ")";
	}
	return result;
}
Type.prototype.description = function(){
	var result = '';
	result = Types.typeName(this);
	if (result.length == 0){
		result = "PROCEDURE" + dumpProcArgs(this);
		if (this.mResult != null){
			result = result + ": " + this.mResult.description();
		}
	}
	return result;
}
Type.prototype.callGenerator = function(cx/*PType*/){
	return makeProcCallGenerator(cx, this);
}
Type.prototype.define = function(args/*ARRAY OF PProcedureArgument*/, result/*PType*/){
	for (var i = 0; i <= args.length - 1 | 0; ++i){
		RTL$.assert(args[i].type != null);
	}
	Array.prototype.splice.apply(this.mArgs, [0, Number.MAX_VALUE].concat(args));
	for (var i = 0; i <= this.mArgs.length - 1 | 0; ++i){
		RTL$.assert(this.mArgs[i].type != null);
	}
	this.mResult = result;
}
Type.prototype.args = function(){
	return this.mArgs.slice();
}
Type.prototype.result = function(){
	return this.mResult;
}
predefined.push(makeNew());
predefined.push(makeOdd());
predefined.push(makeAssert());
predefined.push(setBitImpl("INCL", inclOp));
predefined.push(setBitImpl("EXCL", exclOp));
predefined.push(incImpl("INC", "++", incOp, Operator.addInt));
predefined.push(incImpl("DEC", "--", decOp, Operator.subInt));
predefined.push(makeAbs());
predefined.push(makeFloor());
predefined.push(makeFlt());
predefined.push(bitShiftImpl("LSL", Operator.lsl));
predefined.push(bitShiftImpl("ASR", Operator.asr));
predefined.push(bitShiftImpl("ROR", Operator.ror));
predefined.push(makeOrd());
predefined.push(makeChr());
predefined.push(makePack());
predefined.push(makeUnpk());
exports.Call = Call;
exports.StdCall = StdCall;
exports.CallLen = CallLen;
exports.CallGenerator = CallGenerator;
exports.Type = Type;
exports.Std = Std;
exports.ArgumentsCode = ArgumentsCode;
exports.predefined = function(){return predefined;};
exports.checkArgument = checkArgument;
exports.checkArgumentsCount = checkArgumentsCount;
exports.processArguments = processArguments;
exports.makeCallGenerator = makeCallGenerator;
exports.makeProcCallGeneratorWithCustomArgs = makeProcCallGeneratorWithCustomArgs;
exports.makeArgumentsCode = makeArgumentsCode;
exports.makeProcCallGenerator = makeProcCallGenerator;
exports.makeSymbol = makeSymbol;
exports.hasArgumentWithCustomType = hasArgumentWithCustomType;
exports.checkSingleArgument = checkSingleArgument;
exports.lenArgumentCheck = lenArgumentCheck;
exports.makeLen = makeLen;
