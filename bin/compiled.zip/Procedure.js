var RTL$ = require("rtl.js");
var Cast = require("js/Cast.js");
var Code = require("js/Code.js");
var Context = require("js/Context.js");
var Errors = require("js/Errors.js");
var Language = require("js/Language.js");
var LanguageContext = require("js/LanguageContext.js");
var OberonRtl = require("js/OberonRtl.js");
var Object = require("js/Object.js");
var Operator = require("js/Operator.js");
var Precedence = require("js/CodePrecedence.js");
var String = require("js/String.js");
var Symbols = require("js/Symbols.js");
var Types = require("js/Types.js");
function Call(){
}
function StdCall(){
	Call.call(this);
	this.args = [];
}
RTL$.extend(StdCall, Call);
function CallLen(){
	StdCall.call(this);
	this.check = null;
}
RTL$.extend(CallLen, StdCall);
function CallGenerator(){
	this.args = [];
	this.cx = null;
	this.call = null;
}
function Type(){
	Types.DefinedProcedure.call(this);
	this.mArgs = [];
	this.mResult = null;
}
RTL$.extend(Type, Types.DefinedProcedure);
function Std(){
	Types.Procedure.call(this);
	this.call = null;
}
RTL$.extend(Std, Types.Procedure);
function ArgumentsCode(){
}
function GenArgCode(){
	ArgumentsCode.call(this);
	this.code = '';
	this.cx = null;
}
RTL$.extend(GenArgCode, ArgumentsCode);
var predefined = [];

function checkArgument(actual/*PExpression*/, expected/*PProcedureArgument*/, pos/*INTEGER*/, code/*PArgumentsCode*/, types/*PTypes*/){
	var actualType = null;var expectType = null;
	var designator = null;
	var info = null;
	var result = null;
	var castErr = 0;
	expectType = expected.type;
	if (expectType != null){
		actualType = actual.type();
		castErr = types.implicitCast(actualType, expectType, expected.isVar, Operator.castOperations(), {set: function($v){result = $v;}, get: function(){return result;}});
		if (castErr == Cast.errVarParameter){
			Errors.raise("type mismatch for argument " + String.fromInt(pos + 1 | 0) + ": cannot pass '" + actualType.description() + "' as VAR parameter of type '" + expectType.description() + "'");
		}
		else if (castErr != Cast.errNo){
			Errors.raise("type mismatch for argument " + String.fromInt(pos + 1 | 0) + ": '" + actualType.description() + "' cannot be converted to '" + expectType.description() + "'");
		}
	}
	if (expected.isVar){
		designator = actual.designator();
		if (designator == null){
			Errors.raise("expression cannot be used as VAR parameter");
		}
		info = designator.info();
		if (info instanceof Types.Const){
			Errors.raise("constant cannot be used as VAR parameter");
		}
		if (info instanceof Types.Variable && RTL$.typeGuard(info, Types.Variable).isReadOnly()){
			Errors.raise(info.idType() + " cannot be used as VAR parameter");
		}
	}
	if (code != null){
		code.write(actual, expected, result);
	}
}

function checkArgumentsType(actual/*ARRAY OF PExpression*/, expected/*ARRAY OF PProcedureArgument*/, code/*PArgumentsCode*/, types/*PTypes*/){
	for (var i = 0; i <= actual.length - 1 | 0; ++i){
		checkArgument(actual[i], expected[i], i, code, types);
	}
}

function checkArgumentsCount(actual/*INTEGER*/, expected/*INTEGER*/){
	if (actual != expected){
		Errors.raise(String.fromInt(expected) + " argument(s) expected, got " + String.fromInt(actual));
	}
}

function processArguments(actual/*ARRAY OF PExpression*/, expected/*ARRAY OF PProcedureArgument*/, code/*PArgumentsCode*/, types/*PTypes*/){
	checkArgumentsCount(actual.length, expected.length);
	checkArgumentsType(actual, expected, code, types);
}

function checkArguments(actual/*ARRAY OF PExpression*/, expected/*ARRAY OF PProcedureArgument*/, types/*PTypes*/){
	processArguments(actual, expected, null, types);
}

function initStd(name/*STRING*/, call/*PCall*/, result/*VAR Std*/){
	Types.initProcedure(result, name);
	result.call = call;
}

function makeStd(name/*STRING*/, call/*PCall*/){
	var result = null;
	result = new Std();
	initStd(name, call, result);
	return result;
}
CallGenerator.prototype.handleArgument = function(e/*PExpression*/){
	this.args.push(e);
}
CallGenerator.prototype.end = function(){
	return this.call.make(this.args, this.cx);
}

function makeCallGenerator(call/*PCall*/, cx/*PType*/){
	var result = null;
	RTL$.assert(cx != null);
	result = new CallGenerator();
	result.cx = cx;
	result.call = call;
	return result;
}
GenArgCode.prototype.write = function(actual/*PExpression*/, expected/*PProcedureArgument*/, cast/*PCastOp*/){
	var e = null;
	var coercedArg = null;
	if (expected != null && expected.isVar){
		coercedArg = Code.refExpression(actual);
	}
	else {
		coercedArg = Code.derefExpression(actual);
	}
	if (this.code.length != 0){
		this.code = this.code + ", ";
	}
	if (cast != null){
		e = cast.make(this.cx.rtl, coercedArg);
	}
	else {
		e = coercedArg;
	}
	this.code = this.code + e.code();
}
GenArgCode.prototype.result = function(){
	return this.code;
}

function makeProcCallGeneratorWithCustomArgs(cx/*PType*/, type/*DefinedProcedure*/, argumentsCode/*PArgumentsCode*/){
	function CallImpl(){
		Call.call(this);
		this.args = [];
		this.result = null;
		this.argumentsCode = null;
	}
	RTL$.extend(CallImpl, Call);
	var call = null;
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		processArguments(args, this.args, this.argumentsCode, cx.types);
		return Code.makeSimpleExpression("(" + this.argumentsCode.result() + ")", this.result);
	}
	call = new CallImpl();
	Array.prototype.splice.apply(call.args, [0, Number.MAX_VALUE].concat(type.args()));
	call.result = type.result();
	call.argumentsCode = argumentsCode;
	return makeCallGenerator(call, cx);
}

function makeArgumentsCode(cx/*PType*/){
	var result = null;
	result = new GenArgCode();
	result.cx = cx;
	return result;
}

function makeProcCallGenerator(cx/*PType*/, type/*DefinedProcedure*/){
	return makeProcCallGeneratorWithCustomArgs(cx, type, makeArgumentsCode(cx));
}
Std.prototype.description = function(){
	return "standard procedure " + this.name;
}
Std.prototype.callGenerator = function(cx/*PType*/){
	return makeCallGenerator(this.call, cx);
}
Std.prototype.designatorCode = function(id/*STRING*/){
	return "";
}

function makeSymbol(p/*PProcedure*/){
	return Symbols.makeSymbol(p.name, Types.makeProcedure(p));
}

function initStdCall(call/*PStdCall*/){
}

function hasArgument(call/*PStdCall*/, type/*PType*/){
	var a = null;
	a = new Types.ProcedureArgument();
	a.type = type;
	call.args.push(a);
}

function hasVarArgument(call/*PStdCall*/, type/*PType*/){
	var a = null;
	a = new Types.ProcedureArgument();
	a.isVar = true;
	a.type = type;
	call.args.push(a);
}

function hasArgumentWithCustomType(call/*PStdCall*/){
	var a = null;
	a = new Types.ProcedureArgument();
	call.args.push(a);
}

function hasVarArgumnetWithCustomType(call/*PStdCall*/){
	var a = null;
	a = new Types.ProcedureArgument();
	a.isVar = true;
	call.args.push(a);
}

function checkSingleArgument(actual/*ARRAY OF PExpression*/, call/*StdCall*/, types/*PTypes*/, code/*PArgumentsCode*/){
	RTL$.assert(call.args.length == 1);
	processArguments(actual, call.args, code, types);
	RTL$.assert(actual.length == 1);
	return actual[0];
}

function makeNew(){
	function CallImpl(){
		StdCall.call(this);
	}
	RTL$.extend(CallImpl, StdCall);
	var call = null;
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var arg = null;
		var argType = null;
		var baseType = null;
		arg = checkSingleArgument(args, this, cx.types, null);
		argType = arg.type();
		if (!(argType instanceof Types.Pointer)){
			Errors.raise("POINTER variable expected, got '" + argType.description() + "'");
		}
		baseType = Types.pointerBase(RTL$.typeGuard(argType, Types.Pointer));
		if (baseType instanceof Types.NonExportedRecord){
			Errors.raise("non-exported RECORD type cannot be used in NEW");
		}
		return Code.makeSimpleExpression(arg.code() + " = " + baseType.initializer(cx, true), null);
	}
	call = new CallImpl();
	initStdCall(call);
	hasVarArgumnetWithCustomType(call);
	return makeSymbol(makeStd("NEW", call));
}

function lenArgumentCheck(argType/*PType*/){
	return argType instanceof Types.Array || argType instanceof Types.String;
}
CallLen.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
	var arg = null;
	var argType = null;
	arg = checkSingleArgument(args, this, cx.types, null);
	argType = arg.type();
	if (!this.check(argType)){
		Errors.raise("ARRAY or string is expected as an argument of LEN, got '" + argType.description() + "'");
	}
	return Code.makeSimpleExpression(arg.code() + ".length", Types.basic().integer);
}

function makeLen(check/*LenArgumentCheck*/){
	var call = null;
	call = new CallLen();
	initStdCall(call);
	call.check = check;
	hasArgumentWithCustomType(call);
	return makeSymbol(makeStd("LEN", call));
}

function makeOdd(){
	function CallImpl(){
		StdCall.call(this);
	}
	RTL$.extend(CallImpl, StdCall);
	var call = null;
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var arg = null;
		var code = '';
		var constValue = null;
		arg = checkSingleArgument(args, this, cx.types, null);
		code = Code.adjustPrecedence(arg, Precedence.bitAnd);
		constValue = arg.constValue();
		if (constValue != null){
			constValue = Code.makeIntConst(RTL$.typeGuard(constValue, Code.IntConst).value & 1 ? 1 : 0);
		}
		return Code.makeExpressionWithPrecedence(code + " & 1", Types.basic().bool, null, constValue, Precedence.bitAnd);
	}
	call = new CallImpl();
	initStdCall(call);
	hasArgument(call, Types.basic().integer);
	return makeSymbol(makeStd("ODD", call));
}

function makeAssert(){
	function CallImpl(){
		StdCall.call(this);
	}
	RTL$.extend(CallImpl, StdCall);
	var call = null;
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var arg = null;
		arg = checkSingleArgument(args, this, cx.types, null);
		return Code.makeSimpleExpression(cx.rtl.assertId() + "(" + arg.code() + ")", null);
	}
	call = new CallImpl();
	initStdCall(call);
	hasArgument(call, Types.basic().bool);
	return makeSymbol(makeStd("ASSERT", call));
}

function setBitImpl(name/*STRING*/, bitOp/*BinaryOpStr*/){
	function CallImpl(){
		StdCall.call(this);
		this.name = '';
		this.bitOp = null;
	}
	RTL$.extend(CallImpl, StdCall);
	var call = null;
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var x = null;var y = null;
		var yValue = 0;
		var value = null;
		var valueCodeExp = null;
		var valueCode = '';
		var comment = '';
		checkArguments(args, this.args, cx.types);
		RTL$.assert(args.length == 2);
		x = args[0];
		y = args[1];
		value = y.constValue();
		if (value == null){
			valueCodeExp = Operator.lsl(Code.makeExpression("1", Types.basic().integer, null, Code.makeIntConst(1)), y, cx.rtl);
			valueCode = valueCodeExp.code();
		}
		else {
			yValue = RTL$.typeGuard(value, Code.IntConst).value;
			if (yValue < 0 || yValue > 31){
				Errors.raise("value (0..31) expected as a second argument of " + this.name + ", got " + String.fromInt(yValue));
			}
			comment = "bit: ";
			if (y.isTerm()){
				comment = comment + String.fromInt(yValue);
			}
			else {
				comment = comment + Code.adjustPrecedence(y, Precedence.shift);
			}
			yValue = 1 << yValue;
			valueCode = String.fromInt(yValue) + "/*" + comment + "*/";
		}
		return Code.makeSimpleExpression(this.bitOp(Code.adjustPrecedence(x, Precedence.assignment), valueCode), null);
	}
	call = new CallImpl();
	initStdCall(call);
	call.name = name;
	call.bitOp = bitOp;
	hasVarArgument(call, Types.basic().set);
	hasArgument(call, Types.basic().integer);
	return makeSymbol(makeStd(call.name, call));
}

function checkVariableArgumentsCount(min/*INTEGER*/, max/*INTEGER*/, actual/*ARRAY OF PExpression*/){
	var len = actual.length;
	if (len < min){
		Errors.raise("at least " + String.fromInt(min) + " argument expected, got " + String.fromInt(len));
	}
	else if (len > max){
		Errors.raise("at most " + String.fromInt(max) + " arguments expected, got " + String.fromInt(len));
	}
}

function incImpl(name/*STRING*/, unary/*STRING*/, incOp/*BinaryOpStr*/){
	function CallImpl(){
		StdCall.call(this);
		this.name = '';
		this.unary = '';
		this.incOp = null;
	}
	RTL$.extend(CallImpl, StdCall);
	var call = null;
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var x = null;var y = null;
		var code = '';
		var value = null;
		var valueCode = '';
		checkVariableArgumentsCount(1, 2, args);
		checkArgumentsType(args, this.args, null, cx.types);
		x = args[0];
		if (args.length == 1){
			code = this.unary + x.code();
		}
		else {
			y = args[1];
			value = y.constValue();
			if (value == null){
				valueCode = y.code();
			}
			else {
				valueCode = String.fromInt(RTL$.typeGuard(value, Code.IntConst).value);
				if (!y.isTerm()){
					valueCode = valueCode + "/*" + y.code() + "*/";
				}
			}
			code = this.incOp(x.code(), valueCode);
		}
		return Code.makeSimpleExpression(code, null);
	}
	call = new CallImpl();
	initStdCall(call);
	call.name = name;
	call.unary = unary;
	call.incOp = incOp;
	hasVarArgument(call, Types.basic().integer);
	hasArgument(call, Types.basic().integer);
	return makeSymbol(makeStd(call.name, call));
}

function inclOp(x/*STRING*/, y/*STRING*/){
	return x + " |= " + y;
}

function exclOp(x/*STRING*/, y/*STRING*/){
	return x + " &= ~(" + y + ")";
}

function incOp(x/*STRING*/, y/*STRING*/){
	return x + " += " + y;
}

function decOp(x/*STRING*/, y/*STRING*/){
	return x + " -= " + y;
}

function makeAbs(){
	function CallImpl(){
		StdCall.call(this);
	}
	RTL$.extend(CallImpl, StdCall);
	var call = null;
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var arg = null;
		var argType = null;
		arg = checkSingleArgument(args, this, cx.types, null);
		argType = arg.type();
		if (Types.numeric().indexOf(argType) == -1){
			Errors.raise("type mismatch: expected numeric type, got '" + argType.description() + "'");
		}
		return Code.makeSimpleExpression("Math.abs(" + arg.code() + ")", argType);
	}
	call = new CallImpl();
	initStdCall(call);
	hasArgumentWithCustomType(call);
	return makeSymbol(makeStd("ABS", call));
}

function makeFloor(){
	function CallImpl(){
		StdCall.call(this);
	}
	RTL$.extend(CallImpl, StdCall);
	var call = null;
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var arg = null;
		arg = checkSingleArgument(args, this, cx.types, null);
		return Code.makeSimpleExpression("Math.floor(" + arg.code() + ")", Types.basic().integer);
	}
	call = new CallImpl();
	initStdCall(call);
	hasArgument(call, Types.basic().real);
	return makeSymbol(makeStd("FLOOR", call));
}

function makeFlt(){
	function CallImpl(){
		StdCall.call(this);
	}
	RTL$.extend(CallImpl, StdCall);
	var call = null;
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var arg = null;
		var value = null;
		arg = checkSingleArgument(args, this, cx.types, null);
		value = arg.constValue();
		if (value != null){
			value = Code.makeRealConst(RTL$.typeGuard(value, Code.IntConst).value);
		}
		return Code.makeExpressionWithPrecedence(arg.code(), Types.basic().real, null, value, arg.maxPrecedence());
	}
	call = new CallImpl();
	initStdCall(call);
	hasArgument(call, Types.basic().integer);
	return makeSymbol(makeStd("FLT", call));
}

function bitShiftImpl(name/*STRING*/, op/*BinaryOp*/){
	function CallImpl(){
		StdCall.call(this);
		this.name = '';
		this.op = null;
	}
	RTL$.extend(CallImpl, StdCall);
	var call = null;
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		checkArguments(args, this.args, cx.types);
		RTL$.assert(args.length == 2);
		return this.op(args[0], args[1], cx.rtl);
	}
	call = new CallImpl();
	initStdCall(call);
	call.name = name;
	call.op = op;
	hasArgument(call, Types.basic().integer);
	hasArgument(call, Types.basic().integer);
	return makeSymbol(makeStd(call.name, call));
}

function makeOrd(){
	function CallImpl(){
		StdCall.call(this);
	}
	RTL$.extend(CallImpl, StdCall);
	var call = null;
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var arg = null;
		var argType = null;
		var value = null;
		var code = '';
		var ch = 0;
		var result = null;
		arg = checkSingleArgument(args, this, cx.types, null);
		argType = arg.type();
		if (argType == Types.basic().ch || argType == Types.basic().set){
			value = arg.constValue();
			if (value != null && argType == Types.basic().set){
				value = Code.makeIntConst(RTL$.typeGuard(value, Code.SetConst).value);
			}
			result = Code.makeExpression(arg.code(), Types.basic().integer, null, value);
		}
		else if (argType == Types.basic().bool){
			code = Code.adjustPrecedence(arg, Precedence.conditional) + " ? 1 : 0";
			result = Code.makeExpressionWithPrecedence(code, Types.basic().integer, null, arg.constValue(), Precedence.conditional);
		}
		else if (argType instanceof Types.String && Types.stringAsChar(RTL$.typeGuard(argType, Types.String), {set: function($v){ch = $v;}, get: function(){return ch;}})){
			result = Code.makeExpression(String.fromInt(ch), Types.basic().integer, null, Code.makeIntConst(ch));
		}
		else {
			Errors.raise("ORD function expects CHAR or BOOLEAN or SET as an argument, got '" + argType.description() + "'");
		}
		return result;
	}
	call = new CallImpl();
	initStdCall(call);
	hasArgumentWithCustomType(call);
	return makeSymbol(makeStd("ORD", call));
}

function makeChr(){
	function CallImpl(){
		StdCall.call(this);
	}
	RTL$.extend(CallImpl, StdCall);
	var call = null;
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var arg = null;
		arg = checkSingleArgument(args, this, cx.types, null);
		return Code.makeSimpleExpression(arg.code(), Types.basic().ch);
	}
	call = new CallImpl();
	initStdCall(call);
	hasArgument(call, Types.basic().integer);
	return makeSymbol(makeStd("CHR", call));
}

function makePack(){
	function CallImpl(){
		StdCall.call(this);
	}
	RTL$.extend(CallImpl, StdCall);
	var call = null;
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var x = null;var y = null;
		checkArguments(args, this.args, cx.types);
		x = args[0];
		y = args[1];
		return Code.makeSimpleExpression(Operator.mulInplace(x, Operator.pow2(y), cx), null);
	}
	call = new CallImpl();
	initStdCall(call);
	hasVarArgument(call, Types.basic().real);
	hasArgument(call, Types.basic().integer);
	return makeSymbol(makeStd("PACK", call));
}

function makeUnpk(){
	function CallImpl(){
		StdCall.call(this);
	}
	RTL$.extend(CallImpl, StdCall);
	var call = null;
	CallImpl.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var x = null;var y = null;
		checkArguments(args, this.args, cx.types);
		x = args[0];
		y = args[1];
		return Code.makeSimpleExpression(Operator.assign(y, Operator.log2(x), cx) + "; " + Operator.divInplace(x, Operator.pow2(y), cx), null);
	}
	call = new CallImpl();
	initStdCall(call);
	hasVarArgument(call, Types.basic().real);
	hasVarArgument(call, Types.basic().integer);
	return makeSymbol(makeStd("UNPK", call));
}

function dumpProcArgs(proc/*Type*/){
	var result = '';
	var len = proc.mArgs.length;
	if (len == 0){
		if (proc.mResult != null){
			result = "()";
		}
	}
	else {
		result = "(";
		for (var i = 0; i <= len - 1 | 0; ++i){
			if (i != 0){
				result = result + ", ";
			}
			var arg = proc.mArgs[i];
			RTL$.assert(arg.type != null);
			result = result + arg.type.description();
		}
		result = result + ")";
	}
	return result;
}
Type.prototype.description = function(){
	var result = '';
	result = Types.typeName(this);
	if (result.length == 0){
		result = "PROCEDURE" + dumpProcArgs(this);
		if (this.mResult != null){
			result = result + ": " + this.mResult.description();
		}
	}
	return result;
}
Type.prototype.callGenerator = function(cx/*PType*/){
	return makeProcCallGenerator(cx, this);
}
Type.prototype.define = function(args/*ARRAY OF PProcedureArgument*/, result/*PType*/){
	for (var i = 0; i <= args.length - 1 | 0; ++i){
		RTL$.assert(args[i].type != null);
	}
	Array.prototype.splice.apply(this.mArgs, [0, Number.MAX_VALUE].concat(args));
	for (var i = 0; i <= this.mArgs.length - 1 | 0; ++i){
		RTL$.assert(this.mArgs[i].type != null);
	}
	this.mResult = result;
}
Type.prototype.args = function(){
	return this.mArgs.slice();
}
Type.prototype.result = function(){
	return this.mResult;
}

function make(name/*STRING*/){
	var result = null;
	result = new Type();
	result.name = name;
	return result;
}
predefined.push(makeNew());
predefined.push(makeOdd());
predefined.push(makeAssert());
predefined.push(setBitImpl("INCL", inclOp));
predefined.push(setBitImpl("EXCL", exclOp));
predefined.push(incImpl("INC", "++", incOp));
predefined.push(incImpl("DEC", "--", decOp));
predefined.push(makeAbs());
predefined.push(makeFloor());
predefined.push(makeFlt());
predefined.push(bitShiftImpl("LSL", Operator.lsl));
predefined.push(bitShiftImpl("ASR", Operator.asr));
predefined.push(bitShiftImpl("ROR", Operator.ror));
predefined.push(makeOrd());
predefined.push(makeChr());
predefined.push(makePack());
predefined.push(makeUnpk());
exports.Call = Call;
exports.StdCall = StdCall;
exports.CallLen = CallLen;
exports.CallGenerator = CallGenerator;
exports.Type = Type;
exports.Std = Std;
exports.ArgumentsCode = ArgumentsCode;
exports.predefined = function(){return predefined;};
exports.checkArgument = checkArgument;
exports.checkArgumentsCount = checkArgumentsCount;
exports.processArguments = processArguments;
exports.initStd = initStd;
exports.makeStd = makeStd;
exports.makeCallGenerator = makeCallGenerator;
exports.makeProcCallGeneratorWithCustomArgs = makeProcCallGeneratorWithCustomArgs;
exports.makeArgumentsCode = makeArgumentsCode;
exports.makeProcCallGenerator = makeProcCallGenerator;
exports.makeSymbol = makeSymbol;
exports.initStdCall = initStdCall;
exports.hasArgumentWithCustomType = hasArgumentWithCustomType;
exports.checkSingleArgument = checkSingleArgument;
exports.lenArgumentCheck = lenArgumentCheck;
exports.makeLen = makeLen;
exports.make = make;
