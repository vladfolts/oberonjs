var RTL$ = require("rtl.js");
var Cast = require("js/Cast.js");
var Code = require("js/Code.js");
var Context = require("js/Context.js");
var Errors = require("js/Errors.js");
var JsArray = require("js/JsArray.js");
var Language = require("js/Language.js");
var LanguageContext = require("js/LanguageContext.js");
var OberonRtl = require("js/OberonRtl.js");
var Object = require("js/Object.js");
var Operator = require("js/Operator.js");
var Precedence = require("js/CodePrecedence.js");
var String = require("js/String.js");
var Symbols = require("js/Symbols.js");
var Types = require("js/Types.js");
var Call = RTL$.extend({
	init: function Call(){
	}
});
var StdCall = Call.extend({
	init: function StdCall(){
		Call.prototype.init.call(this);
		this.args = null;
	}
});
var CallLen = StdCall.extend({
	init: function CallLen(){
		StdCall.prototype.init.call(this);
		this.check = null;
	}
});
var CallGenerator = RTL$.extend({
	init: function CallGenerator(){
		this.args = null;
		this.cx = null;
		this.call = null;
	}
});
var Impl = Types.Procedure.extend({
	init: function Impl(){
		Types.Procedure.prototype.init.call(this);
	}
});
var Type = Types.DefinedProcedure.extend({
	init: function Type(){
		Types.DefinedProcedure.prototype.init.call(this);
		this.mArgs = null;
		this.mResult = null;
	}
});
var Std = Impl.extend({
	init: function Std(){
		Impl.prototype.init.call(this);
		this.call = null;
	}
});
var ArgumentsCode = RTL$.extend({
	init: function ArgumentsCode(){
	}
});
var GenArgCode = ArgumentsCode.extend({
	init: function GenArgCode(){
		ArgumentsCode.prototype.init.call(this);
		this.code = '';
		this.cx = null;
	}
});
var predefined = null;

function checkArgument(actual/*PExpression*/, expected/*PProcedureArgument*/, pos/*INTEGER*/, code/*PArgumentsCode*/, types/*PTypes*/){
	var actualType = null;var expectType = null;
	var designator = null;
	var info = null;
	var result = null;
	var castErr = 0;
	expectType = expected.type;
	if (expectType != null){
		actualType = actual.type();
		castErr = types.implicitCast(actualType, expectType, expected.isVar, Operator.castOperations(), {set: function($v){result = $v;}, get: function(){return result;}});
		if (castErr == Cast.errVarParameter){
			Errors.raise("type mismatch for argument " + String.fromInt(pos + 1 | 0) + ": cannot pass '" + actualType.description() + "' as VAR parameter of type '" + expectType.description() + "'");
		}
		else if (castErr != Cast.errNo){
			Errors.raise("type mismatch for argument " + String.fromInt(pos + 1 | 0) + ": '" + actualType.description() + "' cannot be converted to '" + expectType.description() + "'");
		}
	}
	if (expected.isVar){
		designator = actual.designator();
		if (designator == null){
			Errors.raise("expression cannot be used as VAR parameter");
		}
		info = designator.info();
		if (info instanceof Types.Const){
			Errors.raise("constant cannot be used as VAR parameter");
		}
		if (info instanceof Types.Variable && RTL$.typeGuard(info, Types.Variable).isReadOnly()){
			Errors.raise(info.idType() + " cannot be used as VAR parameter");
		}
	}
	if (code != null){
		code.write(actual, expected, result);
	}
}

function checkArgumentsType(actual/*Type*/, expected/*Type*/, code/*PArgumentsCode*/, types/*PTypes*/){
	var actualLen = 0;
	var i = 0;
	var actualExp = null;
	var expectedArg = null;
	actualLen = JsArray.len(actual);
	while (true){
		if (i < actualLen){
			actualExp = JsArray.at(actual, i);
			expectedArg = JsArray.at(expected, i);
			checkArgument(RTL$.typeGuard(actualExp, Code.Expression), RTL$.typeGuard(expectedArg, Types.ProcedureArgument), i, code, types);
			++i;
		} else break;
	}
}

function checkArgumentsCount(actual/*INTEGER*/, expected/*INTEGER*/){
	if (actual != expected){
		Errors.raise(String.fromInt(expected) + " argument(s) expected, got " + String.fromInt(actual));
	}
}

function processArguments(actual/*Type*/, expected/*Type*/, code/*PArgumentsCode*/, types/*PTypes*/){
	checkArgumentsCount(JsArray.len(actual), JsArray.len(expected));
	checkArgumentsType(actual, expected, code, types);
}

function checkArguments(actual/*Type*/, expected/*Type*/, types/*PTypes*/){
	processArguments(actual, expected, null, types);
}

function initStd(name/*STRING*/, call/*PCall*/, result/*VAR Std*/){
	Types.initProcedure(result, name);
	result.call = call;
}

function makeStd(name/*STRING*/, call/*PCall*/){
	var result = null;
	result = new Std();
	initStd(name, call, result);
	return result;
}
CallGenerator.prototype.handleArgument = function(e/*PExpression*/){
	JsArray.add(this.args, e);
}
CallGenerator.prototype.end = function(){
	return this.call.make(this.args, this.cx);
}

function makeCallGenerator(call/*PCall*/, cx/*PType*/){
	var result = null;
	RTL$.assert(cx != null);
	result = new CallGenerator();
	result.args = JsArray.make();
	result.cx = cx;
	result.call = call;
	return result;
}
GenArgCode.prototype.write = function(actual/*PExpression*/, expected/*PProcedureArgument*/, cast/*PCastOp*/){
	var e = null;
	var coercedArg = null;
	if (expected != null && expected.isVar){
		coercedArg = Code.refExpression(actual);
	}
	else {
		coercedArg = Code.derefExpression(actual);
	}
	if (this.code.length != 0){
		this.code = this.code + ", ";
	}
	if (cast != null){
		e = cast.make(this.cx.rtl, coercedArg);
	}
	else {
		e = coercedArg;
	}
	this.code = this.code + e.code();
}
GenArgCode.prototype.result = function(){
	return this.code;
}

function makeProcCallGeneratorWithCustomArgs(cx/*PType*/, id/*STRING*/, type/*DefinedProcedure*/, argumentsCode/*PArgumentsCode*/){
	var CallImpl = Call.extend({
		init: function CallImpl(){
			Call.prototype.init.call(this);
			this.id = '';
			this.args = null;
			this.result = null;
			this.argumentsCode = null;
		}
	});
	var call = null;
	CallImpl.prototype.make = function(args/*Type*/, cx/*Type*/){
		var expectedArgs = null;
		var a = null;
		expectedArgs = this.args;
		if (expectedArgs != null){
			processArguments(args, expectedArgs, this.argumentsCode, cx.types);
		}
		else {
			for (var i = 0; i <= JsArray.len(args) - 1 | 0; ++i){
				a = JsArray.at(args, i);
				this.argumentsCode.write(RTL$.typeGuard(a, Code.Expression), null, null);
			}
		}
		return Code.makeSimpleExpression(this.id + "(" + this.argumentsCode.result() + ")", this.result);
	}
	call = new CallImpl();
	call.id = id;
	call.args = type.args();
	call.result = type.result();
	call.argumentsCode = argumentsCode;
	return makeCallGenerator(call, cx);
}

function makeArgumentsCode(cx/*PType*/){
	var result = null;
	result = new GenArgCode();
	result.cx = cx;
	return result;
}

function makeProcCallGenerator(cx/*PType*/, id/*STRING*/, type/*DefinedProcedure*/){
	return makeProcCallGeneratorWithCustomArgs(cx, id, type, makeArgumentsCode(cx));
}
Std.prototype.description = function(){
	return "standard procedure " + Types.typeName(this);
}
Std.prototype.callGenerator = function(cx/*PType*/){
	return makeCallGenerator(this.call, cx);
}

function makeSymbol(p/*PProcedure*/){
	return Symbols.makeSymbol(p.name, Types.makeProcedure(p));
}

function nthArgument(args/*Type*/, i/*INTEGER*/){
	var arg = null;
	arg = JsArray.at(args, i);
	return RTL$.typeGuard(arg, Code.Expression);
}

function initStdCall(call/*PStdCall*/){
	call.args = JsArray.make();
}

function hasArgument(call/*PStdCall*/, type/*PType*/){
	var a = null;
	a = new Types.ProcedureArgument();
	a.type = type;
	JsArray.add(call.args, a);
}

function hasVarArgument(call/*PStdCall*/, type/*PType*/){
	var a = null;
	a = new Types.ProcedureArgument();
	a.isVar = true;
	a.type = type;
	JsArray.add(call.args, a);
}

function hasArgumentWithCustomType(call/*PStdCall*/){
	var a = null;
	a = new Types.ProcedureArgument();
	JsArray.add(call.args, a);
}

function hasVarArgumnetWithCustomType(call/*PStdCall*/){
	var a = null;
	a = new Types.ProcedureArgument();
	a.isVar = true;
	JsArray.add(call.args, a);
}

function checkSingleArgument(actual/*Type*/, call/*StdCall*/, types/*PTypes*/){
	RTL$.assert(JsArray.len(call.args) == 1);
	checkArguments(actual, call.args, types);
	RTL$.assert(JsArray.len(actual) == 1);
	return nthArgument(actual, 0);
}

function makeNew(){
	var CallImpl = StdCall.extend({
		init: function CallImpl(){
			StdCall.prototype.init.call(this);
		}
	});
	var call = null;
	CallImpl.prototype.make = function(args/*Type*/, cx/*Type*/){
		var arg = null;
		var argType = null;
		var baseType = null;
		arg = checkSingleArgument(args, this, cx.types);
		argType = arg.type();
		if (!(argType instanceof Types.Pointer)){
			Errors.raise("POINTER variable expected, got '" + argType.description() + "'");
		}
		baseType = Types.pointerBase(RTL$.typeGuard(argType, Types.Pointer));
		if (baseType instanceof Types.NonExportedRecord){
			Errors.raise("non-exported RECORD type cannot be used in NEW");
		}
		return Code.makeSimpleExpression(arg.code() + " = " + baseType.initializer(cx, true), null);
	}
	call = new CallImpl();
	initStdCall(call);
	hasVarArgumnetWithCustomType(call);
	return makeSymbol(makeStd("NEW", call));
}

function lenArgumentCheck(argType/*PType*/){
	return argType instanceof Types.Array || argType instanceof Types.String;
}
CallLen.prototype.make = function(args/*Type*/, cx/*Type*/){
	var arg = null;
	var argType = null;
	arg = checkSingleArgument(args, this, cx.types);
	argType = arg.type();
	if (!this.check(argType)){
		Errors.raise("ARRAY or string is expected as an argument of LEN, got '" + argType.description() + "'");
	}
	return Code.makeSimpleExpression(arg.code() + ".length", Types.basic().integer);
}

function makeLen(check/*LenArgumentCheck*/){
	var call = null;
	call = new CallLen();
	initStdCall(call);
	call.check = check;
	hasArgumentWithCustomType(call);
	return makeSymbol(makeStd("LEN", call));
}

function makeOdd(){
	var CallImpl = StdCall.extend({
		init: function CallImpl(){
			StdCall.prototype.init.call(this);
		}
	});
	var call = null;
	CallImpl.prototype.make = function(args/*Type*/, cx/*Type*/){
		var arg = null;
		var code = '';
		var constValue = null;
		arg = checkSingleArgument(args, this, cx.types);
		code = Code.adjustPrecedence(arg, Precedence.bitAnd);
		constValue = arg.constValue();
		if (constValue != null){
			constValue = Code.makeIntConst(RTL$.typeGuard(constValue, Code.IntConst).value & 1 ? 1 : 0);
		}
		return Code.makeExpressionWithPrecedence(code + " & 1", Types.basic().bool, null, constValue, Precedence.bitAnd);
	}
	call = new CallImpl();
	initStdCall(call);
	hasArgument(call, Types.basic().integer);
	return makeSymbol(makeStd("ODD", call));
}

function makeAssert(){
	var CallImpl = StdCall.extend({
		init: function CallImpl(){
			StdCall.prototype.init.call(this);
		}
	});
	var call = null;
	CallImpl.prototype.make = function(args/*Type*/, cx/*Type*/){
		var arg = null;
		arg = checkSingleArgument(args, this, cx.types);
		return Code.makeSimpleExpression(cx.rtl.assertId() + "(" + arg.code() + ")", null);
	}
	call = new CallImpl();
	initStdCall(call);
	hasArgument(call, Types.basic().bool);
	return makeSymbol(makeStd("ASSERT", call));
}

function setBitImpl(name/*STRING*/, bitOp/*BinaryOpStr*/){
	var CallImpl = StdCall.extend({
		init: function CallImpl(){
			StdCall.prototype.init.call(this);
			this.name = '';
			this.bitOp = null;
		}
	});
	var call = null;
	CallImpl.prototype.make = function(args/*Type*/, cx/*Type*/){
		var x = null;var y = null;
		var yValue = 0;
		var value = null;
		var valueCodeExp = null;
		var valueCode = '';
		var comment = '';
		checkArguments(args, this.args, cx.types);
		RTL$.assert(JsArray.len(args) == 2);
		x = nthArgument(args, 0);
		y = nthArgument(args, 1);
		value = y.constValue();
		if (value == null){
			valueCodeExp = Operator.lsl(Code.makeExpression("1", Types.basic().integer, null, Code.makeIntConst(1)), y, cx.rtl);
			valueCode = valueCodeExp.code();
		}
		else {
			yValue = RTL$.typeGuard(value, Code.IntConst).value;
			if (yValue < 0 || yValue > 31){
				Errors.raise("value (0..31) expected as a second argument of " + this.name + ", got " + String.fromInt(yValue));
			}
			comment = "bit: ";
			if (y.isTerm()){
				comment = comment + String.fromInt(yValue);
			}
			else {
				comment = comment + Code.adjustPrecedence(y, Precedence.shift);
			}
			yValue = 1 << yValue;
			valueCode = String.fromInt(yValue) + "/*" + comment + "*/";
		}
		return Code.makeSimpleExpression(this.bitOp(Code.adjustPrecedence(x, Precedence.assignment), valueCode), null);
	}
	call = new CallImpl();
	initStdCall(call);
	call.name = name;
	call.bitOp = bitOp;
	hasVarArgument(call, Types.basic().set);
	hasArgument(call, Types.basic().integer);
	return makeSymbol(makeStd(call.name, call));
}

function checkVariableArgumentsCount(min/*INTEGER*/, max/*INTEGER*/, actual/*Type*/){
	var len = 0;
	len = JsArray.len(actual);
	if (len < min){
		Errors.raise("at least " + String.fromInt(min) + " argument expected, got " + String.fromInt(len));
	}
	else if (len > max){
		Errors.raise("at most " + String.fromInt(max) + " arguments expected, got " + String.fromInt(len));
	}
}

function incImpl(name/*STRING*/, unary/*STRING*/, incOp/*BinaryOpStr*/){
	var CallImpl = StdCall.extend({
		init: function CallImpl(){
			StdCall.prototype.init.call(this);
			this.name = '';
			this.unary = '';
			this.incOp = null;
		}
	});
	var call = null;
	CallImpl.prototype.make = function(args/*Type*/, cx/*Type*/){
		var x = null;var y = null;
		var code = '';
		var value = null;
		var valueCode = '';
		checkVariableArgumentsCount(1, 2, args);
		checkArgumentsType(args, this.args, null, cx.types);
		x = nthArgument(args, 0);
		if (JsArray.len(args) == 1){
			code = this.unary + x.code();
		}
		else {
			y = nthArgument(args, 1);
			value = y.constValue();
			if (value == null){
				valueCode = y.code();
			}
			else {
				valueCode = String.fromInt(RTL$.typeGuard(value, Code.IntConst).value);
				if (!y.isTerm()){
					valueCode = valueCode + "/*" + y.code() + "*/";
				}
			}
			code = this.incOp(x.code(), valueCode);
		}
		return Code.makeSimpleExpression(code, null);
	}
	call = new CallImpl();
	initStdCall(call);
	call.name = name;
	call.unary = unary;
	call.incOp = incOp;
	hasVarArgument(call, Types.basic().integer);
	hasArgument(call, Types.basic().integer);
	return makeSymbol(makeStd(call.name, call));
}

function inclOp(x/*STRING*/, y/*STRING*/){
	return x + " |= " + y;
}

function exclOp(x/*STRING*/, y/*STRING*/){
	return x + " &= ~(" + y + ")";
}

function incOp(x/*STRING*/, y/*STRING*/){
	return x + " += " + y;
}

function decOp(x/*STRING*/, y/*STRING*/){
	return x + " -= " + y;
}

function makeAbs(){
	var CallImpl = StdCall.extend({
		init: function CallImpl(){
			StdCall.prototype.init.call(this);
		}
	});
	var call = null;
	CallImpl.prototype.make = function(args/*Type*/, cx/*Type*/){
		var arg = null;
		var argType = null;
		arg = checkSingleArgument(args, this, cx.types);
		argType = arg.type();
		if (!JsArray.contains(Types.numeric(), argType)){
			Errors.raise("type mismatch: expected numeric type, got '" + argType.description() + "'");
		}
		return Code.makeSimpleExpression("Math.abs(" + arg.code() + ")", argType);
	}
	call = new CallImpl();
	initStdCall(call);
	hasArgumentWithCustomType(call);
	return makeSymbol(makeStd("ABS", call));
}

function makeFloor(){
	var CallImpl = StdCall.extend({
		init: function CallImpl(){
			StdCall.prototype.init.call(this);
		}
	});
	var call = null;
	CallImpl.prototype.make = function(args/*Type*/, cx/*Type*/){
		var arg = null;
		arg = checkSingleArgument(args, this, cx.types);
		return Code.makeSimpleExpression("Math.floor(" + arg.code() + ")", Types.basic().integer);
	}
	call = new CallImpl();
	initStdCall(call);
	hasArgument(call, Types.basic().real);
	return makeSymbol(makeStd("FLOOR", call));
}

function makeFlt(){
	var CallImpl = StdCall.extend({
		init: function CallImpl(){
			StdCall.prototype.init.call(this);
		}
	});
	var call = null;
	CallImpl.prototype.make = function(args/*Type*/, cx/*Type*/){
		var arg = null;
		var value = null;
		arg = checkSingleArgument(args, this, cx.types);
		value = arg.constValue();
		if (value != null){
			value = Code.makeRealConst(RTL$.typeGuard(value, Code.IntConst).value);
		}
		return Code.makeExpressionWithPrecedence(arg.code(), Types.basic().real, null, value, arg.maxPrecedence());
	}
	call = new CallImpl();
	initStdCall(call);
	hasArgument(call, Types.basic().integer);
	return makeSymbol(makeStd("FLT", call));
}

function bitShiftImpl(name/*STRING*/, op/*BinaryOp*/){
	var CallImpl = StdCall.extend({
		init: function CallImpl(){
			StdCall.prototype.init.call(this);
			this.name = '';
			this.op = null;
		}
	});
	var call = null;
	CallImpl.prototype.make = function(args/*Type*/, cx/*Type*/){
		var x = null;var y = null;
		checkArguments(args, this.args, cx.types);
		RTL$.assert(JsArray.len(args) == 2);
		x = nthArgument(args, 0);
		y = nthArgument(args, 1);
		return this.op(x, y, cx.rtl);
	}
	call = new CallImpl();
	initStdCall(call);
	call.name = name;
	call.op = op;
	hasArgument(call, Types.basic().integer);
	hasArgument(call, Types.basic().integer);
	return makeSymbol(makeStd(call.name, call));
}

function makeOrd(){
	var CallImpl = StdCall.extend({
		init: function CallImpl(){
			StdCall.prototype.init.call(this);
		}
	});
	var call = null;
	CallImpl.prototype.make = function(args/*Type*/, cx/*Type*/){
		var arg = null;
		var argType = null;
		var value = null;
		var code = '';
		var ch = 0;
		var result = null;
		arg = checkSingleArgument(args, this, cx.types);
		argType = arg.type();
		if (argType == Types.basic().ch || argType == Types.basic().set){
			value = arg.constValue();
			if (value != null && argType == Types.basic().set){
				value = Code.makeIntConst(RTL$.typeGuard(value, Code.SetConst).value);
			}
			result = Code.makeExpression(arg.code(), Types.basic().integer, null, value);
		}
		else if (argType == Types.basic().bool){
			code = Code.adjustPrecedence(arg, Precedence.conditional) + " ? 1 : 0";
			result = Code.makeExpressionWithPrecedence(code, Types.basic().integer, null, arg.constValue(), Precedence.conditional);
		}
		else if (argType instanceof Types.String && Types.stringAsChar(RTL$.typeGuard(argType, Types.String), {set: function($v){ch = $v;}, get: function(){return ch;}})){
			result = Code.makeExpression(String.fromInt(ch), Types.basic().integer, null, Code.makeIntConst(ch));
		}
		else {
			Errors.raise("ORD function expects CHAR or BOOLEAN or SET as an argument, got '" + argType.description() + "'");
		}
		return result;
	}
	call = new CallImpl();
	initStdCall(call);
	hasArgumentWithCustomType(call);
	return makeSymbol(makeStd("ORD", call));
}

function makeChr(){
	var CallImpl = StdCall.extend({
		init: function CallImpl(){
			StdCall.prototype.init.call(this);
		}
	});
	var call = null;
	CallImpl.prototype.make = function(args/*Type*/, cx/*Type*/){
		var arg = null;
		arg = checkSingleArgument(args, this, cx.types);
		return Code.makeSimpleExpression(arg.code(), Types.basic().ch);
	}
	call = new CallImpl();
	initStdCall(call);
	hasArgument(call, Types.basic().integer);
	return makeSymbol(makeStd("CHR", call));
}

function makePack(){
	var CallImpl = StdCall.extend({
		init: function CallImpl(){
			StdCall.prototype.init.call(this);
		}
	});
	var call = null;
	CallImpl.prototype.make = function(args/*Type*/, cx/*Type*/){
		var x = null;var y = null;
		checkArguments(args, this.args, cx.types);
		x = nthArgument(args, 0);
		y = nthArgument(args, 1);
		return Code.makeSimpleExpression(Operator.mulInplace(x, Operator.pow2(y), cx), null);
	}
	call = new CallImpl();
	initStdCall(call);
	hasVarArgument(call, Types.basic().real);
	hasArgument(call, Types.basic().integer);
	return makeSymbol(makeStd("PACK", call));
}

function makeUnpk(){
	var CallImpl = StdCall.extend({
		init: function CallImpl(){
			StdCall.prototype.init.call(this);
		}
	});
	var call = null;
	CallImpl.prototype.make = function(args/*Type*/, cx/*Type*/){
		var x = null;var y = null;
		checkArguments(args, this.args, cx.types);
		x = nthArgument(args, 0);
		y = nthArgument(args, 1);
		return Code.makeSimpleExpression(Operator.assign(y, Operator.log2(x), cx) + "; " + Operator.divInplace(x, Operator.pow2(y), cx), null);
	}
	call = new CallImpl();
	initStdCall(call);
	hasVarArgument(call, Types.basic().real);
	hasVarArgument(call, Types.basic().integer);
	return makeSymbol(makeStd("UNPK", call));
}

function dumpProcArgs(proc/*Type*/){
	var result = '';
	var len = 0;
	var arg = null;
	len = JsArray.len(proc.mArgs);
	if (len == 0){
		if (proc.mResult != null){
			result = "()";
		}
	}
	else {
		result = "(";
		for (var i = 0; i <= len - 1 | 0; ++i){
			if (i != 0){
				result = result + ", ";
			}
			arg = JsArray.at(proc.mArgs, i);
			result = result + RTL$.typeGuard(arg, Types.ProcedureArgument).type.description();
		}
		result = result + ")";
	}
	return result;
}
Type.prototype.description = function(){
	var result = '';
	result = Types.typeName(this);
	if (result.length == 0){
		result = "PROCEDURE" + dumpProcArgs(this);
		if (this.mResult != null){
			result = result + ": " + this.mResult.description();
		}
	}
	return result;
}
Type.prototype.callGenerator = function(cx/*PType*/, id/*STRING*/){
	return makeProcCallGenerator(cx, id, this);
}
Type.prototype.define = function(args/*Type*/, result/*PType*/){
	this.mArgs = args;
	this.mResult = result;
}
Type.prototype.args = function(){
	return this.mArgs;
}
Type.prototype.result = function(){
	return this.mResult;
}

function make(name/*STRING*/){
	var result = null;
	result = new Type();
	result.name = name;
	return result;
}
predefined = JsArray.make();
JsArray.add(predefined, makeNew());
JsArray.add(predefined, makeOdd());
JsArray.add(predefined, makeAssert());
JsArray.add(predefined, setBitImpl("INCL", inclOp));
JsArray.add(predefined, setBitImpl("EXCL", exclOp));
JsArray.add(predefined, incImpl("INC", "++", incOp));
JsArray.add(predefined, incImpl("DEC", "--", decOp));
JsArray.add(predefined, makeAbs());
JsArray.add(predefined, makeFloor());
JsArray.add(predefined, makeFlt());
JsArray.add(predefined, bitShiftImpl("LSL", Operator.lsl));
JsArray.add(predefined, bitShiftImpl("ASR", Operator.asr));
JsArray.add(predefined, bitShiftImpl("ROR", Operator.ror));
JsArray.add(predefined, makeOrd());
JsArray.add(predefined, makeChr());
JsArray.add(predefined, makePack());
JsArray.add(predefined, makeUnpk());
exports.Call = Call;
exports.StdCall = StdCall;
exports.CallLen = CallLen;
exports.CallGenerator = CallGenerator;
exports.Type = Type;
exports.Std = Std;
exports.predefined = function(){return predefined;};
exports.checkArgumentsCount = checkArgumentsCount;
exports.initStd = initStd;
exports.makeCallGenerator = makeCallGenerator;
exports.makeProcCallGeneratorWithCustomArgs = makeProcCallGeneratorWithCustomArgs;
exports.makeArgumentsCode = makeArgumentsCode;
exports.makeProcCallGenerator = makeProcCallGenerator;
exports.makeSymbol = makeSymbol;
exports.initStdCall = initStdCall;
exports.hasArgumentWithCustomType = hasArgumentWithCustomType;
exports.checkSingleArgument = checkSingleArgument;
exports.lenArgumentCheck = lenArgumentCheck;
exports.makeLen = makeLen;
exports.make = make;
