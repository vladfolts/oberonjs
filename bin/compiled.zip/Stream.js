var RTL$ = require("rtl.js");
var String = require("js/String.js");
var kCR = "\n";
var Type = RTL$.extend({
	init: function Type(){
		this.s = '';
		this.pos = 0;
	}
});

function make(text/*STRING*/){
	var result = null;
	result = new Type();
	result.s = text;
	return result;
}

function eof(self/*Type*/){
	return self.pos == self.s.length;
}

function pos(self/*Type*/){
	return self.pos;
}

function setPos(self/*Type*/, pos/*INTEGER*/){
	RTL$.assert(pos <= self.s.length);
	self.pos = pos;
}

function next(self/*Type*/, n/*INTEGER*/){
	RTL$.assert((self.pos + n | 0) <= self.s.length);
	self.pos = self.pos + n | 0;
}

function peekChar(self/*Type*/){
	RTL$.assert(!eof(self));
	return self.s.charCodeAt(self.pos);
}

function getChar(self/*Type*/){
	var result = 0;
	RTL$.assert(!eof(self));
	result = self.s.charCodeAt(self.pos);
	++self.pos;
	return result;
}

function peekStr(self/*Type*/, s/*ARRAY OF CHAR*/){
	var result = false;
	var i = 0;
	if (s.length <= (self.s.length - self.pos | 0)){
		while (true){
			if (i < s.length && s.charCodeAt(i) == self.s.charCodeAt(self.pos + i | 0)){
				++i;
			} else break;
		}
		result = i == s.length;
	}
	return result;
}

function read(self/*Type*/, f/*ReaderProc*/){
	while (true){
		if (!eof(self) && f(peekChar(self))){
			next(self, 1);
		} else break;
	}
	return !eof(self);
}

function lineNumber(self/*Type*/){
	var line = 0;
	var lastPos = 0;
	lastPos = String.indexOf(self.s, 10);
	while (true){
		if (lastPos != -1 && lastPos < self.pos){
			++line;
			lastPos = String.indexOfFrom(self.s, 10, lastPos + 1 | 0);
		} else break;
	}
	return line + 1 | 0;
}
exports.kCR = kCR;
exports.Type = Type;
exports.make = make;
exports.eof = eof;
exports.pos = pos;
exports.setPos = setPos;
exports.next = next;
exports.peekChar = peekChar;
exports.getChar = getChar;
exports.peekStr = peekStr;
exports.read = read;
exports.lineNumber = lineNumber;
