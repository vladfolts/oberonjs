var ContextHierarchy = require("js/ContextHierarchy.js");
var EberonContextDesignator = require("js/EberonContextDesignator.js");
var EberonContextProcedure = require("js/EberonContextProcedure.js");
var EberonScope = require("js/EberonScope.js");
var EberonTypePromotion = require("js/EberonTypePromotion.js");
var Scope = require("js/Scope.js");
var $scope = "EberonOperatorScopes";
Type.prototype.$scope = $scope;
function Type(cx/*PNode*/){
	this.context = cx;
	this.scope = null;
	this.ignorePromotions = false;
	this.typePromotion = null;
	this.typePromotions = [];
	this.alternate();
}
Type.prototype.handleMessage = function(msg/*VAR Message*/){
	var result = false;
	if (this.ignorePromotions){
	}
	else if (msg instanceof EberonContextDesignator.TransferPromotedTypesMsg){
		result = true;
	}
	else if (msg instanceof EberonContextDesignator.PromoteTypeMsg){
		this.typePromotion = new EberonTypePromotion.ForVariable(msg.info, msg.type, false);
		this.typePromotions.push(this.typePromotion);
		result = true;
	}
	else if (msg instanceof EberonContextProcedure.BeginTypePromotionOrMsg){
		var tp = new EberonTypePromotion.Or(false);
		this.typePromotion = tp;
		this.typePromotions.push(tp);
		msg.result = tp;
		result = true;
	}
	return result;
};
Type.prototype.doThen = function(){
	if (this.typePromotion != null){
		this.typePromotion.and();
	}
	this.ignorePromotions = true;
};
Type.prototype.alternate = function(){
	var root = this.context.root();
	if (this.scope != null){
		root.popScope();
	}
	this.scope = EberonScope.makeOperator(root.currentScope(), root.language().stdSymbols);
	root.pushScope(this.scope);
	if (this.typePromotion != null){
		this.typePromotion.reset();
		this.typePromotion.or();
		this.typePromotion = null;
	}
	this.ignorePromotions = false;
};
Type.prototype.reset = function(){
	this.context.root().popScope();
	for (var i = 0; i <= this.typePromotions.length - 1 | 0; ++i){
		this.typePromotions[i].reset();
	}
};
exports.Type = Type;
