var RTL$ = require("eberon/eberon_rtl.js");
var Context = require("js/Context.js");
var Errors = require("js/Errors.js");
RTL$.extend(IdentdefInfo, Context.IdentdefInfo);
IdentdefInfo.prototype.isReadOnly = function(){
	return this.ro;
};
function IdentdefInfo(id/*STRING*/, exported/*BOOLEAN*/, ro/*BOOLEAN*/){
	Context.IdentdefInfo.call(this, id, exported);
	this.ro = ro;
}

function checkOrdinaryExport(id/*IdentdefInfo*/, hint/*STRING*/){
	if (id.isReadOnly()){
		Errors.raise(hint + " cannot be exported as read-only using '-' mark (did you mean '*'?)");
	}
}
exports.IdentdefInfo = IdentdefInfo;
exports.checkOrdinaryExport = checkOrdinaryExport;
