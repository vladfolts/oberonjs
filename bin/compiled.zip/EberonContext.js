var RTL$ = require("rtl.js");
var Context = require("js/Context.js");
function IdentdefInfo(){
	Context.IdentdefInfo.call(this);
	this.ro = false;
}
RTL$.extend(IdentdefInfo, Context.IdentdefInfo);
IdentdefInfo.prototype.isReadOnly = function(){
	return this.ro;
}

function makeIdentdefInfo(id/*STRING*/, exported/*BOOLEAN*/, ro/*BOOLEAN*/){
	var result = null;
	result = new IdentdefInfo();
	Context.initIdentdefInfo(id, exported, result);
	result.ro = ro;
	return result;
}
exports.IdentdefInfo = IdentdefInfo;
exports.makeIdentdefInfo = makeIdentdefInfo;
