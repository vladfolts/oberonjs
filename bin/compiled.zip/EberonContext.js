var RTL$ = require("eberon/eberon_rtl.js");
var Context = require("js/Context.js");
RTL$.extend(IdentdefInfo, Context.IdentdefInfo);
IdentdefInfo.prototype.isReadOnly = function(){
	return this.ro;
};
function IdentdefInfo(id/*STRING*/, exported/*BOOLEAN*/, ro/*BOOLEAN*/){
	Context.IdentdefInfo.call(this, id, exported);
	this.ro = ro;
}
exports.IdentdefInfo = IdentdefInfo;
