var ConstValue = require("js/ConstValue.js");
var Designator = require("js/Designator.js");
var Precedence = require("js/CodePrecedence.js");
var Types = require("js/Types.js");
var $scope = "Expression";
Type.prototype.$scope = $scope;
Type.prototype.code = function(){
	return this.mCode;
};
Type.prototype.type = function(){
	return this.mType;
};
Type.prototype.designator = function(){
	return this.mDesignator;
};
Type.prototype.constValue = function(){
	return this.mConstValue;
};
Type.prototype.maxPrecedence = function(){
	return this.mMaxPrecedence;
};
Type.prototype.isTerm = function(){
	return this.mDesignator == null && this.mMaxPrecedence == Precedence.none;
};
function Type(code/*STRING*/, type/*PType*/, designator/*PType*/, constValue/*PType*/, maxPrecedence/*INTEGER*/){
	this.mCode = code;
	this.mType = type;
	this.mDesignator = designator;
	this.mConstValue = constValue;
	this.mMaxPrecedence = maxPrecedence;
}

function make(code/*STRING*/, type/*PType*/, designator/*PType*/, constValue/*PType*/){
	return new Type(code, type, designator, constValue, Precedence.none);
}

function makeSimple(code/*STRING*/, type/*PType*/){
	return make(code, type, null, null);
}

function derefCode(code/*STRING*/){
	return code + ".get()";
}

function deref(e/*PType*/){
	var result = e;
	var designator = e.mDesignator;
	var type = e.mType;
	if (designator != null && !(type instanceof Types.Array || type instanceof Types.Record)){
		var info = designator.info();
		if (info instanceof Types.Variable && info.isReference()){
			result = makeSimple(derefCode(e.code()), type);
		}
	}
	return result;
}

function isTemporary(e/*Type*/){
	return e.designator() == null;
}
exports.Type = Type;
exports.make = make;
exports.makeSimple = makeSimple;
exports.derefCode = derefCode;
exports.deref = deref;
exports.isTemporary = isTemporary;
