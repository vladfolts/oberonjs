var OberonRtl = require("js/OberonRtl.js");
var Object = require("js/Object.js");
var ScopeBase = require("js/ScopeBase.js");
function Type(){
	this.handleChar = null;
	this.handleLiteral = null;
	this.handleString = null;
	this.handleIdent = null;
	this.isLexem = null;
	this.qualifyScope = null;
	this.rtl = null;
}
function IdentdefInfo(){
	this.mId = '';
	this.mExported = false;
}
IdentdefInfo.prototype.id = function(){
	return this.mId;
}
IdentdefInfo.prototype.exported = function(){
	return this.mExported;
}

function initIdentdefInfo(id/*STRING*/, exported/*BOOLEAN*/, result/*VAR IdentdefInfo*/){
	result.mId = id;
	result.mExported = exported;
}

function makeIdentdefInfo(id/*STRING*/, exported/*BOOLEAN*/){
	var result = null;
	result = new IdentdefInfo();
	initIdentdefInfo(id, exported, result);
	return result;
}
exports.Type = Type;
exports.IdentdefInfo = IdentdefInfo;
exports.initIdentdefInfo = initIdentdefInfo;
exports.makeIdentdefInfo = makeIdentdefInfo;
