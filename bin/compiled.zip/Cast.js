var RTL$ = require("rtl.js");
var Code = require("js/Code.js");
var OberonRtl = require("js/OberonRtl.js");
var Object = require("js/Object.js");
var String = require("js/String.js");
var Types = require("js/Types.js");
var errNo = 0;
var err = 1;
var errVarParameter = 2;
var CastOp = Object.Type.extend({
	init: function CastOp(){
		Object.Type.prototype.init.call(this);
	}
});
var CastOpStrToChar = CastOp.extend({
	init: function CastOpStrToChar(){
		CastOp.prototype.init.call(this);
		this.c = 0;
	}
});
var Operations = RTL$.extend({
	init: function Operations(){
		this.castToUint8 = null;
	}
});
var areTypesExactlyMatch = null;
var doNothing = null;

function findBaseType(base/*PRecord*/, type/*PRecord*/){
	var result = type;
	while (true){
		if (result != null && result != base){
			result = Types.recordBase(result);
		} else break;
	}
	return result;
}

function findPointerBaseType(base/*PPointer*/, type/*Pointer*/){
	var result = null;
	if (findBaseType(Types.pointerBase(base), Types.pointerBase(type)) != null){
		result = base;
	}
	return result;
}

function matchesToNIL(t/*VAR Type*/){
	return t instanceof Types.Pointer || t instanceof Types.Procedure;
}

function areTypesMatch(t1/*PType*/, t2/*PType*/){
	return areTypesExactlyMatch(t1, t2) || Types.isInt(t1) && Types.isInt(t2) || (t1 == Types.nil() && matchesToNIL(t2) || t2 == Types.nil() && matchesToNIL(t1));
}

function areArgsMatch(a1/*PProcedureArgument*/, a2/*PProcedureArgument*/, p1/*PDefinedProcedure*/, p2/*PDefinedProcedure*/){
	return a1.isVar == a2.isVar && (a1.type == p1 && a2.type == p2 || areTypesExactlyMatch(a1.type, a2.type));
}

function areProceduresMatch(p1/*PDefinedProcedure*/, p2/*PDefinedProcedure*/){
	var result = false;
	var args1 = p1.args().slice();
	var args2 = p2.args().slice();
	var argsLen = args1.length;
	if (args2.length == argsLen){
		var i = 0;
		while (true){
			if (i < argsLen && areArgsMatch(args1[i], args2[i], p1, p2)){
				++i;
			} else break;
		}
		if (i == argsLen){
			var r1 = p1.result();
			var r2 = p2.result();
			result = r1 == p1 && r2 == p2 || areTypesExactlyMatch(r1, r2);
		}
	}
	return result;
}

function areTypesExactlyMatchImpl(t1/*PType*/, t2/*PType*/){
	var result = false;
	if (t1 == t2){
		result = true;
	}
	else if (t1 instanceof Types.OpenArray && t2 instanceof Types.OpenArray){
		result = areTypesMatch(Types.arrayElementsType(t1), Types.arrayElementsType(t2));
	}
	else if (t1 instanceof Types.StaticArray && t2 instanceof Types.StaticArray){
		result = t1.length() == t2.length() && areTypesMatch(Types.arrayElementsType(t1), Types.arrayElementsType(t2));
	}
	else if (t1 instanceof Types.Pointer && t2 instanceof Types.Pointer){
		result = areTypesMatch(Types.pointerBase(t1), Types.pointerBase(t2));
	}
	else if (t1 instanceof Types.DefinedProcedure && t2 instanceof Types.DefinedProcedure){
		result = areProceduresMatch(t1, t2);
	}
	return result;
}
CastOpStrToChar.prototype.make = function(rtl/*PType*/, e/*PExpression*/){
	return Code.makeSimpleExpression(String.fromInt(this.c), Types.basic().ch);
}

function makeCastOpStrToChar(c/*CHAR*/){
	var result = null;
	result = new CastOpStrToChar();
	result.c = c;
	return result;
}

function implicit(from/*PType*/, to/*PType*/, toVar/*BOOLEAN*/, ops/*Operations*/, op/*VAR PCastOp*/){
	var c = 0;
	var ignore = false;
	var result = err;
	op.set(null);
	if (from == to){
		result = errNo;
	}
	else if (from == Types.basic().uint8 && to == Types.basic().integer){
		if (toVar){
			result = errVarParameter;
		}
		else {
			result = errNo;
		}
	}
	else if (from == Types.basic().integer && to == Types.basic().uint8){
		if (toVar){
			result = errVarParameter;
		}
		else {
			op.set(ops.castToUint8);
			result = errNo;
		}
	}
	else if (from instanceof Types.String){
		if (to == Types.basic().ch){
			if (Types.stringAsChar(from, {set: function($v){c = $v;}, get: function(){return c;}})){
				op.set(makeCastOpStrToChar(c));
				result = errNo;
			}
		}
		else if (Types.isString(to)){
			result = errNo;
		}
	}
	else if (from instanceof Types.Array && to instanceof Types.OpenArray && areTypesExactlyMatch(Types.arrayElementsType(from), Types.arrayElementsType(to))){
		result = errNo;
	}
	else if (from instanceof Types.StaticArray && to instanceof Types.StaticArray && from.length() == to.length() && areTypesExactlyMatch(Types.arrayElementsType(from), Types.arrayElementsType(to))){
		result = errNo;
	}
	else if (from instanceof Types.Pointer && to instanceof Types.Pointer){
		if (!toVar){
			if (findPointerBaseType(to, from) != null){
				result = errNo;
			}
		}
		else if (areTypesExactlyMatchImpl(to, from)){
			result = errNo;
		}
		else {
			result = errVarParameter;
		}
	}
	else if (from instanceof Types.Record && to instanceof Types.Record){
		if (findBaseType(to, from) != null){
			result = errNo;
		}
	}
	else if (from == Types.nil() && matchesToNIL(to)){
		result = errNo;
	}
	else if (from instanceof Types.DefinedProcedure && to instanceof Types.DefinedProcedure){
		if (areProceduresMatch(from, to)){
			result = errNo;
		}
	}
	return result;
}
areTypesExactlyMatch = areTypesExactlyMatchImpl;
exports.errNo = errNo;
exports.err = err;
exports.errVarParameter = errVarParameter;
exports.CastOp = CastOp;
exports.Operations = Operations;
exports.areTypesExactlyMatch = function(){return areTypesExactlyMatch;};
exports.doNothing = function(){return doNothing;};
exports.findPointerBaseType = findPointerBaseType;
exports.areTypesMatch = areTypesMatch;
exports.areProceduresMatch = areProceduresMatch;
exports.implicit = implicit;
