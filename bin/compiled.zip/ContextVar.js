var RTL$ = require("eberon/eberon_rtl.js");
var Chars = require("js/Chars.js");
var Context = require("js/Context.js");
var ContextHierarchy = require("js/ContextHierarchy.js");
var ContextType = require("js/ContextType.js");
var Errors = require("js/Errors.js");
var Object$ = require("js/Object$.js");
var Symbols = require("js/Symbols.js");
var Types = require("js/Types.js");
var Variable = require("js/Variable.js");
var $scope = "ContextVar";
function Declaration(){
	ContextType.DeclarationAndIdentHandle.apply(this, arguments);
	this.idents = [];
	this.type = null;
}
RTL$.extend(Declaration, ContextType.DeclarationAndIdentHandle, $scope);
Declaration.prototype.handleIdentdef = function(id/*PIdentdefInfo*/){
	this.idents.push(id);
};
Declaration.prototype.typeName = function(){
	return "";
};
Declaration.prototype.setType = function(type/*PStorageType*/){
	this.type = type;
};
Declaration.prototype.exportField = function(name/*STRING*/){
	ContextType.checkIfFieldCanBeExported(name, this.idents, "variable");
};
Declaration.prototype.isAnonymousDeclaration = function(){
	return true;
};
Declaration.prototype.handleMessage = function(msg/*VAR Message*/){
	if (msg instanceof ContextType.ForwardTypeMsg){
		Errors.raise("type '" + msg.id + "' was not declared");
	}
	return ContextType.DeclarationAndIdentHandle.prototype.handleMessage.call(this, msg);
};
Declaration.prototype.doInitCode = function(){
	return this.type.initializer(this);
};
Declaration.prototype.doCheckExport = function(name/*STRING*/){
};
Declaration.prototype.endParse = function(){
	var gen = this.codeGenerator();
	for (var i = 0; i <= this.idents.length - 1 | 0; ++i){
		var id = this.idents[i];
		var varName = id.id();
		if (id.exported()){
			this.doCheckExport(varName);
		}
		var v = new Variable.DeclaredVariable(varName, this.type);
		this.root().currentScope().addSymbol(new Symbols.Symbol(varName, v), id.exported());
		gen.write("var " + varName + " = " + this.doInitCode() + ";");
	}
	gen.write(Chars.ln);
	return true;
};
exports.Declaration = Declaration;
