var RTL$ = require("eberon/eberon_rtl.js");
var Procedure = require("js/Procedure.js");
var Scope = require("js/Scope.js");
var Symbols = require("js/Symbols.js");

function makeStd(){
	var result = RTL$.cloneMapOfScalars(Scope.makeStdSymbols());
	var proc = Procedure.makeLen(Procedure.lenArgumentCheck);
	result[proc.id()] = proc;
	return RTL$.cloneMapOfScalars(result);
}
exports.makeStd = makeStd;
