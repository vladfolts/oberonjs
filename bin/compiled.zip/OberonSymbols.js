var JsMap = require("js/JsMap.js");
var Procedure = require("js/Procedure.js");
var Scope = require("js/Scope.js");
var Symbols = require("js/Symbols.js");

function makeStd(){
	var proc = null;
	var result = null;
	result = Scope.makeStdSymbols();
	proc = Procedure.makeLen(Procedure.lenArgumentCheck);
	JsMap.put(result, proc.id(), proc);
	return result;
}
exports.makeStd = makeStd;
