var RTL$ = require("rtl.js");
var Cast = require("js/Cast.js");
var JsString = require("js/JsString.js");
var T = require("js/Types.js");
var Types = RTL$.extend({
	init: function Types(){
	}
});
exports.Types = Types;
