var RTL$ = require("eberon/eberon_rtl.js");
var Chars = require("js/Chars.js");
var CodeGenerator = require("js/CodeGenerator.js");
var ContextLoop = require("js/ContextLoop.js");
var ContextExpression = require("js/ContextExpression.js");
var ContextHierarchy = require("js/ContextHierarchy.js");
var Errors = require("js/Errors.js");
var Expression = require("js/Expression.js");
var EberonContextDesignator = require("js/EberonContextDesignator.js");
var EberonMap = require("js/EberonMap.js");
var EberonScope = require("js/EberonScope.js");
var EberonString = require("js/EberonString.js");
var Scope = require("js/Scope.js");
var Symbols = require("js/Symbols.js");
var Types = require("js/Types.js");
var Variable = require("js/Variable.js");
function ForEachVariable(){
	Variable.TypedVariable.apply(this, arguments);
}
RTL$.extend(ForEachVariable, Variable.TypedVariable);
RTL$.extend(ForEach, ContextExpression.ExpressionHandler);
ForEachVariable.prototype.idType = function(){
	return "FOR variable";
};
ForEachVariable.prototype.referenceCode = function(){
	return "";
};
ForEachVariable.prototype.isReference = function(){
	return false;
};
ForEachVariable.prototype.isReadOnly = function(){
	return true;
};
function ForEach(parent/*PNode*/){
	ContextExpression.ExpressionHandler.call(this, parent);
	this.keyId = '';
	this.valueId = '';
	this.code = CodeGenerator.nullGenerator();
	this.scopeWasCreated = false;
}
ForEach.prototype.handleIdent = function(id/*STRING*/){
	if (this.keyId.length == 0){
		this.keyId = id;
	}
	else {
		this.valueId = id;
	}
};
ForEach.prototype.codeGenerator = function(){
	return this.code;
};

function makeVariable(id/*STRING*/, type/*PStorageType*/, scope/*PType*/){
	var v = new ForEachVariable(type);
	var s = new Symbols.Symbol(id, v);
	scope.addSymbol(s, false);
}
ForEach.prototype.handleExpression = function(e/*PType*/){
	var type = e.type();
	if (!(type instanceof EberonMap.Type)){
		Errors.raise("expression of type MAP is expected in FOR, got '" + type.description() + "'");
	}
	else {
		var root = this.root();
		var scope = EberonScope.makeOperator(root.currentScope(), root.language().stdSymbols);
		root.pushScope(scope);
		this.scopeWasCreated = true;
		var code = this.parent().codeGenerator();
		var mapVar = root.currentScope().generateTempVar("map");
		code.write("var " + mapVar + " = " + e.code() + ";" + Chars.ln);
		code.write("for(var " + this.keyId + " in " + mapVar + ")");
		code.openScope();
		code.write("var " + this.valueId + " = " + mapVar + "[" + this.keyId + "];" + Chars.ln);
		this.code = code;
		makeVariable(this.keyId, EberonString.string(), scope);
		makeVariable(this.valueId, type.valueType, scope);
	}
};
ForEach.prototype.endParse = function(){
	this.code.closeScope("");
	if (this.scopeWasCreated){
		this.root().popScope();
	}
	return true;
};
exports.ForEach = ForEach;
