var ScopeBase = require("js/ScopeBase.js");
var Types = require("js/Types.js");
Type.prototype.code = function(){
	return this.mCode;
};
Type.prototype.lval = function(){
	return this.mLval;
};
Type.prototype.type = function(){
	return this.mType;
};
Type.prototype.info = function(){
	return this.mInfo;
};
Type.prototype.scope = function(){
	return this.mScope;
};
function Type(code/*STRING*/, lval/*STRING*/, type/*PType*/, info/*PId*/, scope/*PType*/){
	this.mCode = code;
	this.mLval = lval;
	this.mType = type;
	this.mInfo = info;
	this.mScope = scope;
}
exports.Type = Type;
