var ScopeBase = require("js/ScopeBase.js");
var Types = require("js/Types.js");
var $scope = "Designator";
Type.prototype.$scope = $scope;
Type.prototype.code = function(){
	return this.mCode;
};
Type.prototype.type = function(){
	return this.mType;
};
Type.prototype.info = function(){
	return this.mInfo;
};
Type.prototype.scope = function(){
	return this.mScope;
};
function Type(code/*STRING*/, type/*PType*/, info/*PId*/, scope/*PType*/){
	this.mCode = code;
	this.mType = type;
	this.mInfo = info;
	this.mScope = scope;
}
exports.Type = Type;
