function Type(){
	this.copy = null;
	this.clone = null;
	this.strCmp = null;
	this.assignArrayFromString = null;
	this.makeSet = null;
	this.setInclL = null;
	this.setInclR = null;
	this.assertId = null;
	this.makeRef = null;
}
exports.Type = Type;
