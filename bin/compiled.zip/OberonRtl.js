var RTL$ = require("rtl.js");
var Type = RTL$.extend({
	init: function Type(){
		this.cloneRecord = null;
		this.copyRecord = null;
		this.cloneArrayOfRecords = null;
		this.cloneArrayOfScalars = null;
		this.copyArrayOfRecords = null;
		this.copyArrayOfScalars = null;
		this.strCmp = null;
		this.assignArrayFromString = null;
		this.setInclL = null;
		this.setInclR = null;
		this.assertId = null;
	}
});
exports.Type = Type;
