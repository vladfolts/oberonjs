function Type(){
	this.copy = null;
	this.clone = null;
	this.strCmp = null;
	this.assignArrayFromString = null;
	this.setInclL = null;
	this.setInclR = null;
	this.assertId = null;
}
exports.Type = Type;
