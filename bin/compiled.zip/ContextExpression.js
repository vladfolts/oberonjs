var RTL$ = require("eberon/eberon_rtl.js");
var Chars = require("js/Chars.js");
var Code = require("js/Code.js");
var ContextHierarchy = require("js/ContextHierarchy.js");
var Operator = require("js/Operator.js");
var String = require("js/String.js");
var Types = require("js/Types.js");
RTL$.extend(Factor, ContextHierarchy.Node);
RTL$.extend(Const, ContextHierarchy.Node);
function Integer(){
	Const.apply(this, arguments);
}
RTL$.extend(Integer, Const);
function Real(){
	Const.apply(this, arguments);
}
RTL$.extend(Real, Const);
function Str(){
	Const.apply(this, arguments);
}
RTL$.extend(Str, Const);
function Factor(parent/*PFactor*/){
	ContextHierarchy.Node.call(this, parent);
	this.factorParent = parent;
	this.logicalNot = false;
	this.e = null;
}
Factor.prototype.handleConst = function(type/*PType*/, value/*PConst*/, code/*STRING*/){
	this.e = Code.makeExpression(code, type, null, value);
};
Factor.prototype.handleLiteral = function(s/*STRING*/){
	if (s == "NIL"){
		this.handleConst(Types.nil(), null, "null");
	}
	else if (s == "TRUE"){
		this.handleConst(Types.basic().bool, Code.makeIntConst(1), "true");
	}
	else if (s == "FALSE"){
		this.handleConst(Types.basic().bool, Code.makeIntConst(0), "false");
	}
	else if (s == "~"){
		this.handleLogicalNot();
	}
};
Factor.prototype.handleLogicalNot = function(){
	this.logicalNot = true;
};
Factor.prototype.handleExpression = function(e/*PExpression*/){
	this.e = e;
};
Factor.prototype.endParse = function(){
	if (this.logicalNot){
		ContextHierarchy.checkTypeMatch(this.e.type(), Types.basic().bool);
		this.e = Operator.not(this.e);
	}
	this.factorParent.handleExpression(this.e);
};
function Const(factor/*PFactor*/){
	ContextHierarchy.Node.call(this, factor);
	this.factor = factor;
}
Integer.prototype.handleInt = function(n/*INTEGER*/){
	this.factor.handleConst(Types.basic().integer, Code.makeIntConst(n), String.fromInt(n));
};
Real.prototype.handleReal = function(r/*REAL*/){
	this.factor.handleConst(Types.basic().real, Code.makeRealConst(r), String.fromReal(r));
};

function escapeString(s/*STRING*/){
	var doubleQuote = Chars.doubleQuote;
	var ln = Chars.ln;
	var cr = Chars.cr;
	var tab = Chars.tab;
	var backspace = Chars.backspace;
	var feed = Chars.feed;
	var backslash = Chars.backslash;
	var result = '';
	result = doubleQuote;
	var from = 0;
	for (var i = 0; i <= s.length - 1 | 0; ++i){
		var escape = 0;
		var $case1 = s.charCodeAt(i);
		if ($case1 === 92){
			escape = 92;
		}
		else if ($case1 === 34){
			escape = 34;
		}
		else if ($case1 === 10){
			escape = 110;
		}
		else if ($case1 === 13){
			escape = 114;
		}
		else if ($case1 === 9){
			escape = 116;
		}
		else if ($case1 === 8){
			escape = 98;
		}
		else if ($case1 === 12){
			escape = 102;
		}
		if (escape != 0){
			result = result + String.substr(s, from, i - from | 0) + backslash + String.fromChar(escape);
			from = i + 1 | 0;
		}
	}
	return result + String.substr(s, from, s.length - from | 0) + doubleQuote;
}
Str.prototype.handleStr = function(s/*STRING*/){
	this.factor.handleConst(new Types.String(s), Code.makeStringConst(s), escapeString(s));
};
exports.Factor = Factor;
exports.Integer = Integer;
exports.Real = Real;
exports.Str = Str;
