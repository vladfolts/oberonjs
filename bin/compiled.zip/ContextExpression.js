var RTL$ = require("eberon/eberon_rtl.js");
var Cast = require("js/Cast.js");
var Chars = require("js/Chars.js");
var ConstValue = require("js/ConstValue.js");
var Context = require("js/Context.js");
var ContextHierarchy = require("js/ContextHierarchy.js");
var Errors = require("js/Errors.js");
var Expression = require("js/Expression.js");
var JS = GLOBAL;
var LanguageContext = require("js/LanguageContext.js");
var Operator = require("js/Operator.js");
var Record = require("js/Record.js");
var String = require("js/String.js");
var TypeId = require("js/TypeId.js");
var Types = require("js/Types.js");
function ExpressionHandler(){
	ContextHierarchy.Node.apply(this, arguments);
	this.expression = null;
}
RTL$.extend(ExpressionHandler, ContextHierarchy.Node);
function RelationOps(){
}
function ExpressionNode(){
	ContextHierarchy.Node.apply(this, arguments);
}
RTL$.extend(ExpressionNode, ContextHierarchy.Node);
RTL$.extend(SimpleExpression, ContextHierarchy.Node);
RTL$.extend(Factor, ExpressionHandler);
RTL$.extend(Term, ExpressionHandler);
function MulOperator(){
	ContextHierarchy.Node.apply(this, arguments);
}
RTL$.extend(MulOperator, ContextHierarchy.Node);
function AddOperator(){
	ContextHierarchy.Node.apply(this, arguments);
}
RTL$.extend(AddOperator, ContextHierarchy.Node);
RTL$.extend(Const, ContextHierarchy.Node);
function Integer(){
	Const.apply(this, arguments);
}
RTL$.extend(Integer, Const);
function Real(){
	Const.apply(this, arguments);
}
RTL$.extend(Real, Const);
function Str(){
	Const.apply(this, arguments);
}
RTL$.extend(Str, Const);
function OpTypeCheck(){
}
function IntOpTypeCheck(){
	OpTypeCheck.call(this);
}
RTL$.extend(IntOpTypeCheck, OpTypeCheck);
function NumericOpTypeCheck(){
	OpTypeCheck.call(this);
}
RTL$.extend(NumericOpTypeCheck, OpTypeCheck);
function NumericOrSetOpTypeCheck(){
	NumericOpTypeCheck.call(this);
}
RTL$.extend(NumericOrSetOpTypeCheck, NumericOpTypeCheck);
var intOpTypeCheck = new IntOpTypeCheck();
var numericOpTypeCheck = new NumericOpTypeCheck();
var numericOrSetOpTypeCheck = new NumericOrSetOpTypeCheck();

function throwOperatorTypeMismatch(op/*STRING*/, expect/*STRING*/, type/*PType*/){
	Errors.raise("operator '" + op + "' type mismatch: " + expect + " expected, got '" + type.description() + "'");
}

function assertOpType(type/*PType*/, check/*OpTypeCheck*/, literal/*STRING*/){
	if (!check.check(type)){
		throwOperatorTypeMismatch(literal, check.expect(), type);
	}
}

function assertNumericOp(type/*PType*/, literal/*STRING*/, op/*BinaryOperator*/, intOp/*BinaryOperator*/){
	var result = null;
	assertOpType(type, numericOpTypeCheck, literal);
	if (intOp != null && Types.isInt(type)){
		result = intOp;
	}
	else {
		result = op;
	}
	return result;
}

function assertNumericOrSetOp(type/*PType*/, literal/*STRING*/, op/*BinaryOperator*/, intOp/*BinaryOperator*/, setOp/*BinaryOperator*/){
	var result = null;
	assertOpType(type, numericOrSetOpTypeCheck, literal);
	if (Types.isInt(type)){
		result = intOp;
	}
	else if (type == Types.basic().set){
		result = setOp;
	}
	else {
		result = op;
	}
	return result;
}

function assertIntOp(type/*PType*/, literal/*STRING*/, op/*BinaryOperator*/){
	assertOpType(type, intOpTypeCheck, literal);
	return op;
}

function useIntOrderOp(t/*PType*/){
	return Types.isInt(t) || t == Types.basic().ch;
}

function useIntEqOp(t/*PType*/){
	return Types.isInt(t) || t == Types.basic().bool || t == Types.basic().ch || t instanceof Record.Pointer || t instanceof Types.Procedure || t == Types.nil();
}

function unwrapTypeId(id/*PId*/){
	var result = null;
	if (!(id instanceof TypeId.Type)){
		Errors.raise("type name expected");
	}
	else {
		result = id;
	}
	return result;
}

function unwrapType(id/*PId*/){
	return unwrapTypeId(id).type();
}

function throwTypeMismatch(from/*PType*/, to/*PType*/){
	var fromDescription = '';
	if (from != null){
		fromDescription = "'" + from.description() + "'";
	}
	else {
		fromDescription = "no type (proper procedure call)";
	}
	Errors.raise("type mismatch: expected '" + to.description() + "', got " + fromDescription);
}

function checkTypeMatch(from/*PType*/, to/*PType*/){
	if (!Cast.areTypesMatch(from, to)){
		throwTypeMismatch(from, to);
	}
}

function checkImplicitCast(cx/*Root*/, from/*PType*/, to/*PType*/){
	var op = null;
	if (cx.language().types.implicitCast(from, to, false, {set: function($v){op = $v;}, get: function(){return op;}}) != Cast.errNo){
		throwTypeMismatch(from, to);
	}
}

function promoteExpressionType(cx/*Root*/, left/*PType*/, right/*PType*/){
	if (left != null){
		var rightType = right.type();
		var leftType = left.type();
		if (leftType != null && rightType != null){
			checkImplicitCast(cx, rightType, leftType);
		}
	}
}

function promoteTypeInExpression(e/*PType*/, type/*PType*/){
	var v = 0;
	var result = null;
	var fromType = e.type();
	if (type == Types.basic().ch && fromType instanceof Types.String && Types.stringAsChar(fromType, {set: function($v){v = $v;}, get: function(){return v;}})){
		result = Expression.makeSimple(String.fromInt(v), type);
	}
	else {
		result = e;
	}
	return result;
}

function checkTypeCast(fromInfo/*PVariable*/, fromType/*PType*/, toType/*PType*/, msg/*STRING*/){
	
	function checkCommonBase(from/*PType*/, to/*PType*/, prefix/*STRING*/){
		var t = to.base;
		while (true){
			if (t != null && t != from){
				t = t.base;
			} else break;
		}
		if (t == null){
			Errors.raise(prefix + ": '" + to.description() + "' is not an extension of '" + from.description() + "'");
		}
	}
	var prefix = "invalid " + msg;
	var pointerExpected = fromType instanceof Record.Pointer;
	if (!pointerExpected && !(fromType instanceof Record.Type)){
		Errors.raise(prefix + ": POINTER to type or RECORD expected, got '" + fromType.description() + "'");
	}
	if (!pointerExpected){
		if (!fromInfo.isReference()){
			Errors.raise(prefix + ": a value variable cannot be used");
		}
		else if (!(toType instanceof Record.Type)){
			Errors.raise(prefix + ": RECORD type expected as an argument of RECORD " + msg + ", got '" + toType.description() + "'");
		}
	}
	else if (!(toType instanceof Record.Pointer)){
		Errors.raise(prefix + ": POINTER type expected as an argument of POINTER " + msg + ", got '" + toType.description() + "'");
	}
	if (pointerExpected){
		checkCommonBase(Record.pointerBase(RTL$.typeGuard(fromType, Record.Pointer)), Record.pointerBase(RTL$.typeGuard(toType, Record.Pointer)), prefix);
	}
	else {
		checkCommonBase(RTL$.typeGuard(fromType, Record.Type), RTL$.typeGuard(toType, Record.Type), prefix);
	}
}
RelationOps.prototype.eq = function(type/*PType*/){
	var result = null;
	if (useIntEqOp(type)){
		result = Operator.equalInt;
	}
	else if (Types.isString(type)){
		result = Operator.equalStr;
	}
	else if (type == Types.basic().real){
		result = Operator.equalReal;
	}
	else if (type == Types.basic().set){
		result = Operator.equalSet;
	}
	return result;
};
RelationOps.prototype.notEq = function(type/*PType*/){
	var result = null;
	if (useIntEqOp(type)){
		result = Operator.notEqualInt;
	}
	else if (Types.isString(type)){
		result = Operator.notEqualStr;
	}
	else if (type == Types.basic().real){
		result = Operator.notEqualReal;
	}
	else if (type == Types.basic().set){
		result = Operator.notEqualSet;
	}
	return result;
};
RelationOps.prototype.less = function(type/*PType*/){
	var result = null;
	if (useIntOrderOp(type)){
		result = Operator.lessInt;
	}
	else if (Types.isString(type)){
		result = Operator.lessStr;
	}
	else if (type == Types.basic().real){
		result = Operator.lessReal;
	}
	return result;
};
RelationOps.prototype.greater = function(type/*PType*/){
	var result = null;
	if (useIntOrderOp(type)){
		result = Operator.greaterInt;
	}
	else if (Types.isString(type)){
		result = Operator.greaterStr;
	}
	else if (type == Types.basic().real){
		result = Operator.greaterReal;
	}
	return result;
};
RelationOps.prototype.lessEq = function(type/*PType*/){
	var result = null;
	if (useIntOrderOp(type)){
		result = Operator.eqLessInt;
	}
	else if (Types.isString(type)){
		result = Operator.eqLessStr;
	}
	else if (type == Types.basic().real){
		result = Operator.eqLessReal;
	}
	else if (type == Types.basic().set){
		result = Operator.setInclL;
	}
	return result;
};
RelationOps.prototype.greaterEq = function(type/*PType*/){
	var result = null;
	if (useIntOrderOp(type)){
		result = Operator.eqGreaterInt;
	}
	else if (Types.isString(type)){
		result = Operator.eqGreaterStr;
	}
	else if (type == Types.basic().real){
		result = Operator.eqGreaterReal;
	}
	else if (type == Types.basic().set){
		result = Operator.setInclR;
	}
	return result;
};

function castCode(type/*PType*/, cx/*Type*/){
	var result = '';
	if (type instanceof Record.Pointer){
		var baseType = Record.pointerBase(type);
		result = Record.constructor$(cx, baseType);
	}
	else {
		result = Record.constructor$(cx, RTL$.typeGuard(type, Record.Type));
	}
	return result;
}
RelationOps.prototype.is = function(type/*PType*/, cx/*Type*/){
	var r = null;
	
	function is(left/*PType*/, right/*PType*/, unused/*PType*/){
		var leftVar = null;
		var d = left.designator();
		if (d != null){
			var info = d.info();
			if (info instanceof Types.Variable){
				leftVar = info;
			}
		}
		var rightType = RTL$.typeGuard(right.designator().info(), TypeId.Type).type();
		checkTypeCast(leftVar, left.type(), rightType, "type test");
		return Operator.is(left, Expression.makeSimple(castCode(rightType, cx), null));
	}
	r = is;
	return r;
};
RelationOps.prototype.eqExpect = function(){
	return "numeric type or SET or BOOLEAN or CHAR or character array or POINTER or PROCEDURE";
};
RelationOps.prototype.strongRelExpect = function(){
	return "numeric type or CHAR or character array";
};
RelationOps.prototype.relExpect = function(){
	return "numeric type or SET or CHAR or character array";
};
RelationOps.prototype.coalesceType = function(leftType/*PType*/, rightType/*PType*/){
	var result = null;
	if (leftType instanceof Record.Pointer && rightType instanceof Record.Pointer){
		result = Cast.findPointerBaseType(leftType, rightType);
		if (result == null){
			result = Cast.findPointerBaseType(rightType, leftType);
		}
	}
	if (result == null){
		var isStrings = Types.isString(leftType) && Types.isString(rightType);
		if (!isStrings){
			checkTypeMatch(rightType, leftType);
		}
		result = leftType;
	}
	return result;
};
function SimpleExpression(parent/*PExpressionNode*/){
	ContextHierarchy.Node.call(this, parent);
	this.parentExpression = parent;
	this.mType = null;
	this.unaryOperator = '';
	this.binaryOperator = null;
	this.expression = null;
}
SimpleExpression.prototype.handleTerm = function(e/*PType*/){
	var o = null;
	var type = e.type();
	this.setType(type);
	if (this.unaryOperator == "-"){
		if (Types.isInt(type)){
			o = Operator.negateInt;
		}
		else if (type == Types.basic().set){
			o = Operator.setComplement;
		}
		else if (type == Types.basic().real){
			o = Operator.negateReal;
		}
		else {
			throwOperatorTypeMismatch(this.unaryOperator, numericOrSetOpTypeCheck.expect(), type);
		}
	}
	else if (this.unaryOperator == "+"){
		assertOpType(type, numericOpTypeCheck, this.unaryOperator);
		o = Operator.unaryPlus;
	}
	if (o != null){
		this.expression = o(e);
		this.unaryOperator = "";
	}
	else if (this.expression != null){
		this.expression = this.binaryOperator(this.expression, e);
	}
	else {
		this.expression = e;
	}
};
SimpleExpression.prototype.handleLiteral = function(s/*STRING*/){
	this.unaryOperator = s;
};
SimpleExpression.prototype.type = function(){
	return this.mType;
};
SimpleExpression.prototype.setType = function(type/*PType*/){
	if (type == null || this.mType == null){
		this.mType = type;
	}
	else {
		checkImplicitCast(this.root(), type, this.mType);
	}
};
SimpleExpression.prototype.handleOperator = function(o/*BinaryOperator*/){
	this.binaryOperator = o;
};
SimpleExpression.prototype.endParse = function(){
	this.parentExpression.handleSimpleExpression(this.expression);
};
function Factor(parent/*PFactor*/){
	ExpressionHandler.call(this, parent);
	this.factorParent = parent;
	this.logicalNot = false;
}
Factor.prototype.handleConst = function(type/*PType*/, value/*PType*/, code/*STRING*/){
	this.expression = Expression.make(code, type, null, value);
};
Factor.prototype.handleLiteral = function(s/*STRING*/){
	if (s == "NIL"){
		this.handleConst(Types.nil(), null, "null");
	}
	else if (s == "TRUE"){
		this.handleConst(Types.basic().bool, new ConstValue.Int(1), "true");
	}
	else if (s == "FALSE"){
		this.handleConst(Types.basic().bool, new ConstValue.Int(0), "false");
	}
	else if (s == "~"){
		this.handleLogicalNot();
	}
};
Factor.prototype.handleLogicalNot = function(){
	this.logicalNot = true;
};
Factor.prototype.handleExpression = function(e/*PType*/){
	this.expression = e;
};
Factor.prototype.endParse = function(){
	if (this.logicalNot){
		checkTypeMatch(this.expression.type(), Types.basic().bool);
		this.expression = Operator.not(this.expression);
	}
	this.factorParent.handleExpression(this.expression);
};
function Term(parent/*PSimpleExpression*/){
	ExpressionHandler.call(this, parent);
	this.simpleExpression = parent;
	this.operator = null;
}
Term.prototype.type = function(){
	var result = null;
	if (this.expression != null){
		result = this.expression.type();
	}
	else {
		result = this.attributes.designator.type();
	}
	return result;
};
Term.prototype.handleOperator = function(op/*BinaryOperator*/){
	this.operator = op;
};
Term.prototype.handleExpression = function(e/*PType*/){
	promoteExpressionType(this.root(), this.expression, e);
	if (this.operator == null){
		this.expression = e;
	}
	else if (this.expression != null){
		this.expression = this.operator(this.expression, e);
	}
	else {
		this.expression = this.operator(e, null);
	}
};
Term.prototype.endParse = function(){
	var const$ = null;
	var e = this.expression;
	if (e == null){
		var d = this.attributes.designator;
		var info = d.info();
		if (info instanceof Types.Const){
			const$ = info.value;
		}
		e = Expression.make(d.code(), d.type(), d, const$);
	}
	this.simpleExpression.handleTerm(e);
};
MulOperator.prototype.handleLiteral = function(s/*STRING*/){
	var o = null;
	var parent = RTL$.typeGuard(this.parent(), Term);
	var type = parent.type();
	if (s == "*"){
		o = assertNumericOrSetOp(type, s, Operator.mulReal, Operator.mulInt, Operator.setIntersection);
	}
	else if (s == "/"){
		if (Types.isInt(type)){
			Errors.raise("operator DIV expected for integer division");
		}
		o = assertNumericOrSetOp(type, s, Operator.divReal, null, Operator.setSymmetricDiff);
	}
	else if (s == "DIV"){
		o = assertIntOp(type, s, Operator.divInt);
	}
	else if (s == "MOD"){
		o = assertIntOp(type, s, Operator.mod);
	}
	else if (s == "&"){
		if (type != Types.basic().bool){
			Errors.raise("BOOLEAN expected as operand of '&', got '" + type.description() + "'");
		}
		o = Operator.and;
	}
	else {
		RTL$.assert(false);
	}
	parent.handleOperator(o);
};

function matchAddOperator(cx/*AddOperator*/, s/*STRING*/, type/*PType*/){
	var result = null;
	if (s == "+"){
		result = cx.doMatchPlusOperator(type);
		if (result == null){
			throwOperatorTypeMismatch(s, cx.doExpectPlusOperator(), type);
		}
	}
	else if (s == "-"){
		result = assertNumericOrSetOp(type, s, Operator.subReal, Operator.subInt, Operator.setDiff);
	}
	else if (s == "OR"){
		if (type != Types.basic().bool){
			Errors.raise("BOOLEAN expected as operand of 'OR', got '" + type.description() + "'");
		}
		result = Operator.or;
	}
	return result;
}
AddOperator.prototype.handleLiteral = function(s/*STRING*/){
	var parent = RTL$.typeGuard(this.parent(), SimpleExpression);
	var type = parent.type();
	var o = matchAddOperator(this, s, type);
	if (o != null){
		parent.handleOperator(o);
	}
};
AddOperator.prototype.doMatchPlusOperator = function(type/*PType*/){
	var result = null;
	if (type == Types.basic().set){
		result = Operator.setUnion;
	}
	else if (Types.isInt(type)){
		result = Operator.addInt;
	}
	else if (type == Types.basic().real){
		result = Operator.addReal;
	}
	return result;
};
AddOperator.prototype.doExpectPlusOperator = function(){
	return "numeric type or SET";
};
function Const(factor/*PFactor*/){
	ContextHierarchy.Node.call(this, factor);
	this.factor = factor;
}
Integer.prototype.handleInt = function(n/*INTEGER*/){
	this.factor.handleConst(Types.basic().integer, new ConstValue.Int(n), String.fromInt(n));
};
Real.prototype.handleReal = function(r/*REAL*/){
	this.factor.handleConst(Types.basic().real, new ConstValue.Real(r), String.fromReal(r));
};

function escapeString(s/*STRING*/){
	var doubleQuote = Chars.doubleQuote;
	var ln = Chars.ln;
	var cr = Chars.cr;
	var tab = Chars.tab;
	var backspace = Chars.backspace;
	var feed = Chars.feed;
	var backslash = Chars.backslash;
	var result = '';
	result = doubleQuote;
	var from = 0;
	for (var i = 0; i <= s.length - 1 | 0; ++i){
		var escape = 0;
		var $case1 = s.charCodeAt(i);
		if ($case1 === 92){
			escape = 92;
		}
		else if ($case1 === 34){
			escape = 34;
		}
		else if ($case1 === 10){
			escape = 110;
		}
		else if ($case1 === 13){
			escape = 114;
		}
		else if ($case1 === 9){
			escape = 116;
		}
		else if ($case1 === 8){
			escape = 98;
		}
		else if ($case1 === 12){
			escape = 102;
		}
		if (escape != 0){
			result = result + String.substr(s, from, i - from | 0) + backslash + String.fromChar(escape);
			from = i + 1 | 0;
		}
	}
	return result + String.substr(s, from, s.length - from | 0) + doubleQuote;
}
Str.prototype.handleStr = function(s/*STRING*/){
	this.factor.handleConst(new Types.String(s), new ConstValue.String(s), escapeString(s));
};
IntOpTypeCheck.prototype.expect = function(){
	return Types.intsDescription();
};
IntOpTypeCheck.prototype.check = function(t/*PType*/){
	return Types.isInt(t);
};
NumericOpTypeCheck.prototype.expect = function(){
	return "numeric type";
};
NumericOpTypeCheck.prototype.check = function(t/*PType*/){
	return Types.numeric().indexOf(t) != -1;
};
NumericOrSetOpTypeCheck.prototype.expect = function(){
	return NumericOpTypeCheck.prototype.expect.call(this) + " or SET";
};
NumericOrSetOpTypeCheck.prototype.check = function(t/*PType*/){
	return NumericOpTypeCheck.prototype.check.call(this, t) || t == Types.basic().set;
};
exports.RelationOps = RelationOps;
exports.SimpleExpression = SimpleExpression;
exports.Factor = Factor;
exports.Term = Term;
exports.MulOperator = MulOperator;
exports.AddOperator = AddOperator;
exports.Integer = Integer;
exports.Real = Real;
exports.Str = Str;
exports.throwOperatorTypeMismatch = throwOperatorTypeMismatch;
exports.assertNumericOp = assertNumericOp;
exports.assertNumericOrSetOp = assertNumericOrSetOp;
exports.unwrapTypeId = unwrapTypeId;
exports.unwrapType = unwrapType;
exports.checkImplicitCast = checkImplicitCast;
exports.promoteTypeInExpression = promoteTypeInExpression;
exports.checkTypeCast = checkTypeCast;
exports.castCode = castCode;
