var RTL$ = require("eberon/eberon_rtl.js");
var Chars = require("js/Chars.js");
var Code = require("js/Code.js");
var ConstValue = require("js/ConstValue.js");
var ContextHierarchy = require("js/ContextHierarchy.js");
var Operator = require("js/Operator.js");
var String = require("js/String.js");
var Types = require("js/Types.js");
function ExpressionHandler(){
	ContextHierarchy.Node.apply(this, arguments);
	this.expression = null;
}
RTL$.extend(ExpressionHandler, ContextHierarchy.Node);
function SimpleExpression(){
	ContextHierarchy.Node.apply(this, arguments);
}
RTL$.extend(SimpleExpression, ContextHierarchy.Node);
RTL$.extend(Factor, ExpressionHandler);
RTL$.extend(Term, ExpressionHandler);
RTL$.extend(Const, ContextHierarchy.Node);
function Integer(){
	Const.apply(this, arguments);
}
RTL$.extend(Integer, Const);
function Real(){
	Const.apply(this, arguments);
}
RTL$.extend(Real, Const);
function Str(){
	Const.apply(this, arguments);
}
RTL$.extend(Str, Const);
function Factor(parent/*PFactor*/){
	ExpressionHandler.call(this, parent);
	this.factorParent = parent;
	this.logicalNot = false;
}
Factor.prototype.handleConst = function(type/*PType*/, value/*PType*/, code/*STRING*/){
	this.expression = Code.makeExpression(code, type, null, value);
};
Factor.prototype.handleLiteral = function(s/*STRING*/){
	if (s == "NIL"){
		this.handleConst(Types.nil(), null, "null");
	}
	else if (s == "TRUE"){
		this.handleConst(Types.basic().bool, new ConstValue.Int(1), "true");
	}
	else if (s == "FALSE"){
		this.handleConst(Types.basic().bool, new ConstValue.Int(0), "false");
	}
	else if (s == "~"){
		this.handleLogicalNot();
	}
};
Factor.prototype.handleLogicalNot = function(){
	this.logicalNot = true;
};
Factor.prototype.handleExpression = function(e/*PExpression*/){
	this.expression = e;
};
Factor.prototype.endParse = function(){
	if (this.logicalNot){
		ContextHierarchy.checkTypeMatch(this.expression.type(), Types.basic().bool);
		this.expression = Operator.not(this.expression);
	}
	this.factorParent.handleExpression(this.expression);
};
function Term(parent/*PSimpleExpression*/){
	ExpressionHandler.call(this, parent);
	this.simpleExpression = parent;
	this.operator = null;
}
Term.prototype.type = function(){
	var result = null;
	if (this.expression != null){
		result = this.expression.type();
	}
	else {
		result = this.attributes.designator.type();
	}
	return result;
};
Term.prototype.handleOperator = function(op/*BinaryOperator*/){
	this.operator = op;
};
Term.prototype.handleExpression = function(e/*PExpression*/){
	ContextHierarchy.promoteExpressionType(this.root(), this.expression, e);
	if (this.operator == null){
		this.expression = e;
	}
	else if (this.expression != null){
		this.expression = this.operator(this.expression, e);
	}
	else {
		this.expression = this.operator(e, null);
	}
};
Term.prototype.endParse = function(){
	var const$ = null;
	var e = this.expression;
	if (e == null){
		var d = this.attributes.designator;
		var info = d.info();
		if (info instanceof Types.Const){
			const$ = info.value;
		}
		e = Code.makeExpression(d.code(), d.type(), d, const$);
	}
	this.simpleExpression.handleTerm(e);
};
function Const(factor/*PFactor*/){
	ContextHierarchy.Node.call(this, factor);
	this.factor = factor;
}
Integer.prototype.handleInt = function(n/*INTEGER*/){
	this.factor.handleConst(Types.basic().integer, new ConstValue.Int(n), String.fromInt(n));
};
Real.prototype.handleReal = function(r/*REAL*/){
	this.factor.handleConst(Types.basic().real, new ConstValue.Real(r), String.fromReal(r));
};

function escapeString(s/*STRING*/){
	var doubleQuote = Chars.doubleQuote;
	var ln = Chars.ln;
	var cr = Chars.cr;
	var tab = Chars.tab;
	var backspace = Chars.backspace;
	var feed = Chars.feed;
	var backslash = Chars.backslash;
	var result = '';
	result = doubleQuote;
	var from = 0;
	for (var i = 0; i <= s.length - 1 | 0; ++i){
		var escape = 0;
		var $case1 = s.charCodeAt(i);
		if ($case1 === 92){
			escape = 92;
		}
		else if ($case1 === 34){
			escape = 34;
		}
		else if ($case1 === 10){
			escape = 110;
		}
		else if ($case1 === 13){
			escape = 114;
		}
		else if ($case1 === 9){
			escape = 116;
		}
		else if ($case1 === 8){
			escape = 98;
		}
		else if ($case1 === 12){
			escape = 102;
		}
		if (escape != 0){
			result = result + String.substr(s, from, i - from | 0) + backslash + String.fromChar(escape);
			from = i + 1 | 0;
		}
	}
	return result + String.substr(s, from, s.length - from | 0) + doubleQuote;
}
Str.prototype.handleStr = function(s/*STRING*/){
	this.factor.handleConst(new Types.String(s), new ConstValue.String(s), escapeString(s));
};
exports.Factor = Factor;
exports.Term = Term;
exports.Integer = Integer;
exports.Real = Real;
exports.Str = Str;
