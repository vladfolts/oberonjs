var RTL$ = require("eberon/eberon_rtl.js");
var Cast = require("js/Cast.js");
var Chars = require("js/Chars.js");
var CodeGenerator = require("js/CodeGenerator.js");
var ConstValue = require("js/ConstValue.js");
var Context = require("js/Context.js");
var ContextHierarchy = require("js/ContextHierarchy.js");
var Designator = require("js/Designator.js");
var Errors = require("js/Errors.js");
var Expression = require("js/Expression.js");
var JS = GLOBAL;
var LanguageContext = require("js/LanguageContext.js");
var Operator = require("js/Operator.js");
var Procedure = require("js/Procedure.js");
var Record = require("js/Record.js");
var Scope = require("js/Scope.js");
var String = require("js/String.js");
var TypeId = require("js/TypeId.js");
var Types = require("js/Types.js");
var $scope = "ContextExpression";
function ExpressionHandler(){
	ContextHierarchy.Node.apply(this, arguments);
}
RTL$.extend(ExpressionHandler, ContextHierarchy.Node, $scope);
function RelationOps(){
}
RelationOps.prototype.$scope = $scope;
function SimpleItem(){
	this.expression = null;
	this.next = null;
}
SimpleItem.prototype.$scope = $scope;
RTL$.extend(SimpleItemOp, SimpleItem, $scope);
function SimpleList(){
	SimpleItem.call(this);
	this.unaryOp = '';
}
RTL$.extend(SimpleList, SimpleItem, $scope);
function Item(){
	this.simple = null;
	this.next = null;
}
Item.prototype.$scope = $scope;
RTL$.extend(ItemOp, Item, $scope);
RTL$.extend(SimpleExpression, ExpressionHandler, $scope);
RTL$.extend(ExpressionNode, ContextHierarchy.Node, $scope);
function Factor(){
	ExpressionHandler.apply(this, arguments);
	this.expression = null;
	this.logicalNot = false;
}
RTL$.extend(Factor, ExpressionHandler, $scope);
function Term(){
	ExpressionHandler.apply(this, arguments);
	this.expression = null;
	this.operator = null;
}
RTL$.extend(Term, ExpressionHandler, $scope);
function MulOperator(){
	ContextHierarchy.Node.apply(this, arguments);
}
RTL$.extend(MulOperator, ContextHierarchy.Node, $scope);
function AddOperator(){
	ContextHierarchy.Node.apply(this, arguments);
}
RTL$.extend(AddOperator, ContextHierarchy.Node, $scope);
function Const(){
	ContextHierarchy.Node.apply(this, arguments);
}
RTL$.extend(Const, ContextHierarchy.Node, $scope);
function Integer(){
	Const.apply(this, arguments);
}
RTL$.extend(Integer, Const, $scope);
function Real(){
	Const.apply(this, arguments);
}
RTL$.extend(Real, Const, $scope);
function Str(){
	Const.apply(this, arguments);
}
RTL$.extend(Str, Const, $scope);
RTL$.extend(SetElement, ExpressionHandler, $scope);
function Set(){
	ContextHierarchy.Node.apply(this, arguments);
	this.value = 0;
	this.expression = '';
}
RTL$.extend(Set, ContextHierarchy.Node, $scope);
function OpTypeCheck(){
}
OpTypeCheck.prototype.$scope = $scope;
function IntOpTypeCheck(){
	OpTypeCheck.call(this);
}
RTL$.extend(IntOpTypeCheck, OpTypeCheck, $scope);
function NumericOpTypeCheck(){
	OpTypeCheck.call(this);
}
RTL$.extend(NumericOpTypeCheck, OpTypeCheck, $scope);
function NumericOrSetOpTypeCheck(){
	NumericOpTypeCheck.call(this);
}
RTL$.extend(NumericOrSetOpTypeCheck, NumericOpTypeCheck, $scope);
var intOpTypeCheck = new IntOpTypeCheck();
var numericOpTypeCheck = new NumericOpTypeCheck();
var numericOrSetOpTypeCheck = new NumericOrSetOpTypeCheck();
var relationOps = null;

function throwOperatorTypeMismatch(op/*STRING*/, expect/*STRING*/, type/*PType*/){
	Errors.raise("operator '" + op + "' type mismatch: " + expect + " expected, got '" + type.description() + "'");
}

function assertOpType(type/*PType*/, check/*OpTypeCheck*/, literal/*STRING*/){
	if (!check.check(type)){
		throwOperatorTypeMismatch(literal, check.expect(), type);
	}
}

function assertNumericOp(type/*PType*/, literal/*STRING*/, op/*BinaryOperator*/, intOp/*BinaryOperator*/){
	var result = null;
	assertOpType(type, numericOpTypeCheck, literal);
	if (intOp != null && Types.isInt(type)){
		result = intOp;
	}
	else {
		result = op;
	}
	return result;
}

function assertNumericOrSetOp(type/*PType*/, literal/*STRING*/, op/*BinaryOperator*/, intOp/*BinaryOperator*/, setOp/*BinaryOperator*/){
	var result = null;
	assertOpType(type, numericOrSetOpTypeCheck, literal);
	if (Types.isInt(type)){
		result = intOp;
	}
	else if (type == Types.basic().set){
		result = setOp;
	}
	else {
		result = op;
	}
	return result;
}

function assertIntOp(type/*PType*/, literal/*STRING*/, op/*BinaryOperator*/){
	assertOpType(type, intOpTypeCheck, literal);
	return op;
}

function useIntOrderOp(t/*PType*/){
	return Types.isInt(t) || t == Types.basic().ch;
}

function useIntEqOp(t/*PType*/){
	return Types.isInt(t) || t == Types.basic().bool || t == Types.basic().ch || t instanceof Record.Pointer || t instanceof Types.Procedure || t == Types.nil();
}

function throwTypeNameExpected(){
	Errors.raise("type name expected");
}

function unwrapTypeId(id/*PId*/){
	var result = null;
	if (!(id instanceof TypeId.Type)){
		throwTypeNameExpected();
	}
	else {
		result = id;
	}
	return result;
}

function unwrapType(id/*PId*/){
	return unwrapTypeId(id).type();
}

function throwTypeMismatch(from/*PType*/, to/*PType*/){
	var fromDescription = '';
	if (from != null){
		fromDescription = "'" + from.description() + "'";
	}
	else {
		fromDescription = "no type (proper procedure call)";
	}
	Errors.raise("type mismatch: expected '" + to.description() + "', got " + fromDescription);
}

function checkTypeMatch(from/*PType*/, to/*PType*/){
	if (!Cast.areTypesMatch(from, to)){
		throwTypeMismatch(from, to);
	}
}

function checkImplicitCast(cx/*Root*/, from/*PType*/, to/*PType*/){
	var op = null;
	if (cx.language().types.implicitCast(from, to, false, {set: function($v){op = $v;}, get: function(){return op;}}) != Cast.errNo){
		throwTypeMismatch(from, to);
	}
}

function promoteExpressionType(cx/*Root*/, left/*PType*/, right/*PType*/){
	if (left != null){
		var rightType = right.type();
		var leftType = left.type();
		if (leftType != null && rightType != null){
			checkImplicitCast(cx, rightType, leftType);
		}
	}
}

function promoteTypeInExpression(e/*PType*/, type/*PType*/){
	var v = 0;
	var result = null;
	var fromType = e.type();
	if (type == Types.basic().ch && fromType instanceof Types.String && Types.stringAsChar(fromType, {set: function($v){v = $v;}, get: function(){return v;}})){
		result = Expression.makeSimple(String.fromInt(v), type);
	}
	else {
		result = e;
	}
	return result;
}

function checkTypeCast(fromInfo/*PVariable*/, fromType/*PType*/, toType/*PType*/, msg/*STRING*/){
	
	function checkCommonBase(from/*PType*/, to/*PType*/, prefix/*STRING*/){
		var t = to.base;
		while (true){
			if (t != null && t != from){
				t = t.base;
			} else break;
		}
		if (t == null){
			Errors.raise(prefix + ": '" + to.description() + "' is not an extension of '" + from.description() + "'");
		}
	}
	var prefix = "invalid " + msg;
	var pointerExpected = fromType instanceof Record.Pointer;
	if (!pointerExpected && !(fromType instanceof Record.Type)){
		Errors.raise(prefix + ": POINTER to type or RECORD expected, got '" + fromType.description() + "'");
	}
	if (!pointerExpected){
		if (fromInfo != null && !fromInfo.isReference()){
			Errors.raise(prefix + ": a value variable cannot be used");
		}
		else if (!(toType instanceof Record.Type)){
			Errors.raise(prefix + ": RECORD type expected as an argument of RECORD " + msg + ", got '" + toType.description() + "'");
		}
	}
	else if (!(toType instanceof Record.Pointer)){
		Errors.raise(prefix + ": POINTER type expected as an argument of POINTER " + msg + ", got '" + toType.description() + "'");
	}
	if (pointerExpected){
		checkCommonBase(Record.pointerBase(RTL$.typeGuard(fromType, Record.Pointer)), Record.pointerBase(RTL$.typeGuard(toType, Record.Pointer)), prefix);
	}
	else {
		checkCommonBase(RTL$.typeGuard(fromType, Record.Type), RTL$.typeGuard(toType, Record.Type), prefix);
	}
}
RelationOps.prototype.eq = function(type/*PType*/){
	var result = null;
	if (useIntEqOp(type)){
		result = Operator.equalInt;
	}
	else if (Types.isString(type)){
		result = Operator.equalStr;
	}
	else if (type == Types.basic().real){
		result = Operator.equalReal;
	}
	else if (type == Types.basic().set){
		result = Operator.equalSet;
	}
	return result;
};
RelationOps.prototype.notEq = function(type/*PType*/){
	var result = null;
	if (useIntEqOp(type)){
		result = Operator.notEqualInt;
	}
	else if (Types.isString(type)){
		result = Operator.notEqualStr;
	}
	else if (type == Types.basic().real){
		result = Operator.notEqualReal;
	}
	else if (type == Types.basic().set){
		result = Operator.notEqualSet;
	}
	return result;
};
RelationOps.prototype.less = function(type/*PType*/){
	var result = null;
	if (useIntOrderOp(type)){
		result = Operator.lessInt;
	}
	else if (Types.isString(type)){
		result = Operator.lessStr;
	}
	else if (type == Types.basic().real){
		result = Operator.lessReal;
	}
	return result;
};
RelationOps.prototype.greater = function(type/*PType*/){
	var result = null;
	if (useIntOrderOp(type)){
		result = Operator.greaterInt;
	}
	else if (Types.isString(type)){
		result = Operator.greaterStr;
	}
	else if (type == Types.basic().real){
		result = Operator.greaterReal;
	}
	return result;
};
RelationOps.prototype.lessEq = function(type/*PType*/){
	var result = null;
	if (useIntOrderOp(type)){
		result = Operator.eqLessInt;
	}
	else if (Types.isString(type)){
		result = Operator.eqLessStr;
	}
	else if (type == Types.basic().real){
		result = Operator.eqLessReal;
	}
	else if (type == Types.basic().set){
		result = Operator.setInclL;
	}
	return result;
};
RelationOps.prototype.greaterEq = function(type/*PType*/){
	var result = null;
	if (useIntOrderOp(type)){
		result = Operator.eqGreaterInt;
	}
	else if (Types.isString(type)){
		result = Operator.eqGreaterStr;
	}
	else if (type == Types.basic().real){
		result = Operator.eqGreaterReal;
	}
	else if (type == Types.basic().set){
		result = Operator.setInclR;
	}
	return result;
};

function castCode(type/*PType*/, cx/*Type*/){
	var result = '';
	if (type instanceof Record.Pointer){
		var baseType = Record.pointerBase(type);
		result = Record.constructor$(cx, baseType);
	}
	else {
		result = Record.constructor$(cx, RTL$.typeGuard(type, Record.Type));
	}
	return result;
}

function typeTest(left/*PType*/, right/*PId*/, cx/*Node*/){
	var leftVar = null;
	var d = left.designator();
	if (d != null){
		var info = d.info();
		if (info instanceof Types.Variable){
			leftVar = info;
		}
	}
	var rightType = unwrapType(right);
	checkTypeCast(leftVar, left.type(), rightType, "type test");
	return Operator.is(left, Expression.makeSimple(castCode(rightType, cx), null));
}
RelationOps.prototype.is = function(cx/*Node*/){
	var r = null;
	
	function is(left/*PType*/, right/*PType*/, unused/*PType*/){
		var result = null;
		var rightDesignator = right.designator();
		if (rightDesignator == null){
			throwTypeNameExpected();
		}
		else {
			result = typeTest(left, rightDesignator.info(), cx);
		}
		return result;
	}
	r = is;
	return r;
};
RelationOps.prototype.in$ = function(left/*PType*/, right/*PType*/, cx/*Node*/){
	if (!Types.isInt(left)){
		Errors.raise(Types.intsDescription() + " expected as an element of SET, got '" + left.description() + "'");
	}
	checkImplicitCast(cx.root(), right, Types.basic().set);
	return Operator.setHasBit;
};
RelationOps.prototype.eqExpect = function(){
	return "numeric type or SET or BOOLEAN or CHAR or character array or POINTER or PROCEDURE";
};
RelationOps.prototype.strongRelExpect = function(){
	return "numeric type or CHAR or character array";
};
RelationOps.prototype.relExpect = function(){
	return "numeric type or SET or CHAR or character array";
};
RelationOps.prototype.coalesceType = function(leftType/*PType*/, rightType/*PType*/){
	var result = null;
	if (leftType instanceof Record.Pointer && rightType instanceof Record.Pointer){
		result = Cast.findPointerBaseType(leftType, rightType);
		if (result == null){
			result = Cast.findPointerBaseType(rightType, leftType);
		}
	}
	if (result == null){
		var isStrings = Types.isString(leftType) && Types.isString(rightType);
		if (!isStrings){
			checkTypeMatch(rightType, leftType);
		}
		result = leftType;
	}
	return result;
};
function ItemOp(op/*STRING*/){
	Item.call(this);
	this.op = op;
}
function SimpleItemOp(op/*STRING*/){
	SimpleItem.call(this);
	this.op = op;
}
function ExpressionNode(parent/*PExpressionHandler*/, ops/*PRelationOps*/){
	ContextHierarchy.Node.call(this, parent);
	this.relOps = ops;
	this.list = new Item();
	this.last = null;
	if (ops == null){
		this.relOps = relationOps;
	}
}

function notTypeId(e/*PType*/){
	var d = e.designator();
	if (d != null){
		var info = d.info();
		if (info instanceof TypeId.Type){
			Errors.raise("type name '" + info.type().description() + "' cannot be used as an expression");
		}
	}
}

function relationOp(left/*PType*/, right/*PType*/, literal/*STRING*/, ops/*PRelationOps*/, context/*Node*/){
	var type = null;
	var o = null;
	var mismatch = '';
	notTypeId(left);
	if (literal != "IS"){
		notTypeId(right);
		if (literal != "IN"){
			type = ops.coalesceType(left.type(), right.type());
		}
	}
	if (literal == "="){
		o = ops.eq(type);
		if (o == null){
			mismatch = ops.eqExpect();
		}
	}
	else if (literal == "#"){
		o = ops.notEq(type);
		if (o == null){
			mismatch = ops.eqExpect();
		}
	}
	else if (literal == "<"){
		o = ops.less(type);
		if (o == null){
			mismatch = ops.strongRelExpect();
		}
	}
	else if (literal == ">"){
		o = ops.greater(type);
		if (o == null){
			mismatch = ops.strongRelExpect();
		}
	}
	else if (literal == "<="){
		o = ops.lessEq(type);
		if (o == null){
			mismatch = ops.relExpect();
		}
	}
	else if (literal == ">="){
		o = ops.greaterEq(type);
		if (o == null){
			mismatch = ops.relExpect();
		}
	}
	else if (literal == "IS"){
		o = ops.is(context);
	}
	else if (literal == "IN"){
		o = ops.in$(left.type(), right.type(), context);
	}
	if (mismatch.length != 0){
		throwOperatorTypeMismatch(literal, mismatch, type);
	}
	return o;
}

function makeFirstFromSimpleList(list/*SimpleList*/){
	var o = null;
	var result = list.expression;
	if (list.unaryOp == "-"){
		var type = result.type();
		if (Types.isInt(type)){
			o = Operator.negateInt;
		}
		else if (type == Types.basic().set){
			o = Operator.setComplement;
		}
		else if (type == Types.basic().real){
			o = Operator.negateReal;
		}
		else {
			throwOperatorTypeMismatch(list.unaryOp, numericOrSetOpTypeCheck.expect(), type);
		}
	}
	else if (list.unaryOp == "+"){
		assertOpType(result.type(), numericOpTypeCheck, list.unaryOp);
		o = Operator.unaryPlus;
	}
	if (o != null){
		notTypeId(result);
		result = o(result);
	}
	return result;
}

function matchAddOperator(ops/*RelationOps*/, s/*STRING*/, type/*PType*/){
	var result = null;
	if (s == "+"){
		result = ops.plus(type);
	}
	else if (s == "-"){
		result = assertNumericOrSetOp(type, s, Operator.subReal, Operator.subInt, Operator.setDiff);
	}
	else if (s == "OR"){
		if (type != Types.basic().bool){
			Errors.raise("BOOLEAN expected as operand of 'OR', got '" + type.description() + "'");
		}
		result = Operator.or;
	}
	return result;
}

function makeFromSimpleList(list/*SimpleList*/, ops/*RelationOps*/, cx/*Root*/){
	var result = makeFirstFromSimpleList(list);
	var next = list.next;
	while (true){
		if (next != null){
			notTypeId(result);
			var e = next.expression;
			notTypeId(e);
			var o = matchAddOperator(ops, next.op, result.type());
			checkImplicitCast(cx, e.type(), result.type());
			result = o(result, e);
			next = next.next;
		} else break;
	}
	return result;
}

function makeFromList(list/*Item*/, cx/*PExpressionNode*/){
	var root = cx.root();
	var result = makeFromSimpleList(list.simple, cx.relOps, root);
	var next = list.next;
	while (true){
		if (next != null){
			var leftExpression = result;
			var rightExpression = makeFromSimpleList(next.simple, cx.relOps, root);
			leftExpression = promoteTypeInExpression(leftExpression, rightExpression.type());
			rightExpression = promoteTypeInExpression(rightExpression, leftExpression.type());
			var o = relationOp(leftExpression, rightExpression, next.op, cx.relOps, cx);
			result = o(leftExpression, rightExpression, ContextHierarchy.makeLanguageContext(cx));
			next = next.next;
		} else break;
	}
	notTypeId(result);
	var type = result.type();
	if (type == null){
		Errors.raise("procedure returning no result cannot be used in an expression");
	}
	return result;
}
ExpressionNode.prototype.handleLiteral = function(s/*STRING*/){
	var next = new ItemOp(s);
	if (this.last == null){
		this.list.next = next;
	}
	else {
		this.last.next = next;
	}
	this.last = next;
};
ExpressionNode.prototype.codeGenerator = function(){
	return CodeGenerator.nullGenerator();
};
ExpressionNode.prototype.handleSimple = function(s/*PSimpleList*/){
	if (this.list.simple == null){
		this.list.simple = s;
	}
	else {
		this.last.simple = s;
	}
};
ExpressionNode.prototype.endParse = function(){
	var expression = makeFromList(this.list, this);
	var parent = RTL$.typeGuard(this.parent(), ExpressionHandler);
	parent.codeGenerator().write(expression.code());
	parent.handleExpression(expression);
	return true;
};
function SimpleExpression(parent/*PNode*/){
	ExpressionHandler.call(this, parent);
	this.list = new SimpleList();
	this.last = null;
}
SimpleExpression.prototype.handleExpression = function(e/*PType*/){
	if (this.list.expression == null){
		this.list.expression = e;
	}
	else {
		this.last.expression = e;
	}
};
SimpleExpression.prototype.handleLiteral = function(s/*STRING*/){
	this.list.unaryOp = s;
};
SimpleExpression.prototype.handleOperator = function(op/*STRING*/){
	var next = new SimpleItemOp(op);
	if (this.last == null){
		this.list.next = next;
	}
	else {
		this.last.next = next;
	}
	this.last = next;
};
SimpleExpression.prototype.endParse = function(){
	RTL$.typeGuard(this.parent(), ExpressionNode).handleSimple(this.list);
	return true;
};

function expressionFromConst(type/*PType*/, value/*PType*/, code/*STRING*/){
	return Expression.make(code, type, null, value);
}
Factor.prototype.handleLiteral = function(s/*STRING*/){
	if (s == "NIL"){
		this.handleExpression(expressionFromConst(Types.nil(), null, "null"));
	}
	else if (s == "TRUE"){
		this.handleExpression(expressionFromConst(Types.basic().bool, new ConstValue.Int(1), "true"));
	}
	else if (s == "FALSE"){
		this.handleExpression(expressionFromConst(Types.basic().bool, new ConstValue.Int(0), "false"));
	}
	else if (s == "~"){
		this.handleLogicalNot();
	}
};
Factor.prototype.handleLogicalNot = function(){
	this.logicalNot = true;
};
Factor.prototype.handleExpression = function(e/*PType*/){
	this.expression = e;
};
Factor.prototype.endParse = function(){
	if (this.logicalNot){
		notTypeId(this.expression);
		checkTypeMatch(this.expression.type(), Types.basic().bool);
		this.expression = Operator.not(this.expression);
	}
	RTL$.typeGuard(this.parent(), ExpressionHandler).handleExpression(this.expression);
	return true;
};
Term.prototype.type = function(){
	var result = null;
	if (this.expression != null){
		result = this.expression.type();
	}
	else {
		result = this.attributes.designator.type();
	}
	return result;
};
Term.prototype.handleOperator = function(op/*BinaryOperator*/){
	notTypeId(this.expression);
	this.operator = op;
};
Term.prototype.handleExpression = function(e/*PType*/){
	promoteExpressionType(this.root(), this.expression, e);
	if (this.operator == null){
		this.expression = e;
	}
	else if (this.expression != null){
		notTypeId(e);
		this.expression = this.operator(this.expression, e);
	}
};
Term.prototype.endParse = function(){
	var const$ = null;
	var e = this.expression;
	if (e == null){
		var d = this.attributes.designator;
		var info = d.info();
		if (info instanceof Types.Const){
			const$ = info.value;
		}
		e = Expression.make(d.code(), d.type(), d, const$);
	}
	RTL$.typeGuard(this.parent(), SimpleExpression).handleExpression(e);
	return true;
};
MulOperator.prototype.handleLiteral = function(s/*STRING*/){
	var o = null;
	var parent = RTL$.typeGuard(this.parent(), Term);
	var type = parent.type();
	if (s == "*"){
		o = assertNumericOrSetOp(type, s, Operator.mulReal, Operator.mulInt, Operator.setIntersection);
	}
	else if (s == "/"){
		if (Types.isInt(type)){
			Errors.raise("operator DIV expected for integer division");
		}
		o = assertNumericOrSetOp(type, s, Operator.divReal, null, Operator.setSymmetricDiff);
	}
	else if (s == "DIV"){
		o = assertIntOp(type, s, Operator.divInt);
	}
	else if (s == "MOD"){
		o = assertIntOp(type, s, Operator.mod);
	}
	else if (s == "&"){
		if (type != Types.basic().bool){
			Errors.raise("BOOLEAN expected as operand of '&', got '" + type.description() + "'");
		}
		o = Operator.and;
	}
	else {
		RTL$.assert(false);
	}
	parent.handleOperator(o);
};
AddOperator.prototype.handleLiteral = function(s/*STRING*/){
	var parent = RTL$.typeGuard(this.parent(), SimpleExpression);
	parent.handleOperator(s);
};
RelationOps.prototype.plus = function(type/*PType*/){
	var result = null;
	if (type == Types.basic().set){
		result = Operator.setUnion;
	}
	else if (Types.isInt(type)){
		result = Operator.addInt;
	}
	else if (type == Types.basic().real){
		result = Operator.addReal;
	}
	else {
		throwOperatorTypeMismatch("+", this.plusExpect(), type);
	}
	return result;
};
RelationOps.prototype.plusExpect = function(){
	return "numeric type or SET";
};
Integer.prototype.handleInt = function(n/*INTEGER*/){
	RTL$.typeGuard(this.parent(), ExpressionHandler).handleExpression(expressionFromConst(Types.basic().integer, new ConstValue.Int(n), String.fromInt(n)));
};
Real.prototype.handleReal = function(r/*REAL*/){
	RTL$.typeGuard(this.parent(), ExpressionHandler).handleExpression(expressionFromConst(Types.basic().real, new ConstValue.Real(r), String.fromReal(r)));
};

function escapeString(s/*STRING*/){
	var doubleQuote = Chars.doubleQuote;
	var ln = Chars.ln;
	var cr = Chars.cr;
	var tab = Chars.tab;
	var backspace = Chars.backspace;
	var feed = Chars.feed;
	var backslash = Chars.backslash;
	var result = '';
	result = doubleQuote;
	var from = 0;
	for (var i = 0; i <= s.length - 1 | 0; ++i){
		var escape = 0;
		var $case1 = s.charCodeAt(i);
		if ($case1 === 92){
			escape = 92;
		}
		else if ($case1 === 34){
			escape = 34;
		}
		else if ($case1 === 10){
			escape = 110;
		}
		else if ($case1 === 13){
			escape = 114;
		}
		else if ($case1 === 9){
			escape = 116;
		}
		else if ($case1 === 8){
			escape = 98;
		}
		else if ($case1 === 12){
			escape = 102;
		}
		if (escape != 0){
			result = result + String.substr(s, from, i - from | 0) + backslash + String.fromChar(escape);
			from = i + 1 | 0;
		}
	}
	return result + String.substr(s, from, s.length - from | 0) + doubleQuote;
}
Str.prototype.handleStr = function(s/*STRING*/){
	RTL$.typeGuard(this.parent(), ExpressionHandler).handleExpression(expressionFromConst(new Types.String(s), new ConstValue.String(s), escapeString(s)));
};
function SetElement(parent/*PSet*/){
	ExpressionHandler.call(this, parent);
	this.from = '';
	this.to = '';
	this.fromValue = null;
	this.toValue = null;
	this.code = new CodeGenerator.SimpleGenerator();
}
SetElement.prototype.codeGenerator = function(){
	return this.code;
};
SetElement.prototype.handleExpression = function(e/*PType*/){
	var value = RTL$.typeGuard(e.constValue(), ConstValue.Int);
	if (this.from.length == 0){
		this.from = this.code.result();
		this.fromValue = value;
		this.code = new CodeGenerator.SimpleGenerator();
	}
	else {
		this.to = this.code.result();
		this.toValue = value;
	}
};
SetElement.prototype.endParse = function(){
	RTL$.typeGuard(this.parent(), Set).handleElement(this);
	return true;
};
Set.prototype.handleElement = function(s/*SetElement*/){
	if (s.fromValue != null && (s.to.length == 0 || s.toValue != null)){
		if (s.to.length != 0){
			for (var i = s.fromValue.value; i <= s.toValue.value; ++i){
				this.value |= 1 << i;
			}
		}
		else {
			this.value |= 1 << s.fromValue.value;
		}
	}
	else {
		if (this.expression.length != 0){
			this.expression = this.expression + ", ";
		}
		if (s.to.length != 0){
			this.expression = this.expression + "[" + s.from + ", " + s.to + "]";
		}
		else {
			this.expression = this.expression + s.from;
		}
	}
};
Set.prototype.endParse = function(){
	var parent = RTL$.typeGuard(this.parent(), Factor);
	if (this.expression.length == 0){
		parent.handleExpression(expressionFromConst(Types.basic().set, new ConstValue.Set(this.value), String.fromInt(this.value)));
	}
	else {
		var code = this.root().language().rtl.makeSet(this.expression);
		if (this.value != 0){
			code = code + " | " + String.fromInt(this.value);
		}
		var e = Expression.makeSimple(code, Types.basic().set);
		parent.handleExpression(e);
	}
	return true;
};
IntOpTypeCheck.prototype.expect = function(){
	return Types.intsDescription();
};
IntOpTypeCheck.prototype.check = function(t/*PType*/){
	return Types.isInt(t);
};
NumericOpTypeCheck.prototype.expect = function(){
	return "numeric type";
};
NumericOpTypeCheck.prototype.check = function(t/*PType*/){
	return Types.numeric().indexOf(t) != -1;
};
NumericOrSetOpTypeCheck.prototype.expect = function(){
	return NumericOpTypeCheck.prototype.expect.call(this) + " or SET";
};
NumericOrSetOpTypeCheck.prototype.check = function(t/*PType*/){
	return NumericOpTypeCheck.prototype.check.call(this, t) || t == Types.basic().set;
};

function designatorAsExpression(d/*PType*/){
	var value = null;
	var info = d.info();
	if (info instanceof Types.ProcedureId){
		var proc = info.type;
		if (proc instanceof Procedure.Std){
			Errors.raise(proc.description() + " cannot be referenced");
		}
		var scope = d.scope();
		if (scope instanceof Scope.Procedure){
			Errors.raise("local procedure '" + d.code() + "' cannot be referenced");
		}
	}
	if (info instanceof Types.Const){
		value = info.value;
	}
	return Expression.make(d.code(), d.type(), d, value);
}
relationOps = new RelationOps();
exports.ExpressionHandler = ExpressionHandler;
exports.RelationOps = RelationOps;
exports.SimpleExpression = SimpleExpression;
exports.ExpressionNode = ExpressionNode;
exports.Factor = Factor;
exports.Term = Term;
exports.MulOperator = MulOperator;
exports.AddOperator = AddOperator;
exports.Integer = Integer;
exports.Real = Real;
exports.Str = Str;
exports.SetElement = SetElement;
exports.Set = Set;
exports.assertNumericOp = assertNumericOp;
exports.assertNumericOrSetOp = assertNumericOrSetOp;
exports.unwrapTypeId = unwrapTypeId;
exports.unwrapType = unwrapType;
exports.checkTypeCast = checkTypeCast;
exports.castCode = castCode;
exports.typeTest = typeTest;
exports.designatorAsExpression = designatorAsExpression;
