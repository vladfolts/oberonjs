var RTL$ = require("eberon/eberon_rtl.js");
var Cast = require("js/Cast.js");
var Chars = require("js/Chars.js");
var CodeGenerator = require("js/CodeGenerator.js");
var ConstValue = require("js/ConstValue.js");
var ContextExpression = require("js/ContextExpression.js");
var ContextHierarchy = require("js/ContextHierarchy.js");
var Errors = require("js/Errors.js");
var Expression = require("js/Expression.js");
var String = require("js/String.js");
var Types = require("js/Types.js");
RTL$.extend(Type, ContextExpression.ExpressionHandler);
function Label(){
	ContextHierarchy.Node.apply(this, arguments);
}
RTL$.extend(Label, ContextHierarchy.Node);
function LabelList(){
	ContextHierarchy.Node.apply(this, arguments);
	this.glue = '';
}
RTL$.extend(LabelList, ContextHierarchy.Node);
function Range(){
	ContextExpression.ExpressionHandler.apply(this, arguments);
	this.from = null;
	this.to = null;
}
RTL$.extend(Range, ContextExpression.ExpressionHandler);
function Type(parent/*PNode*/){
	ContextExpression.ExpressionHandler.call(this, parent);
	this.var$ = this.root().currentScope().generateTempVar("case");
	this.type = null;
	this.firstCaseParsed = false;
	this.codeGenerator().write("var " + this.var$ + " = ");
}
Type.prototype.handleExpression = function(e/*PType*/){
	var c = 0;
	var type = e.type();
	var gen = this.codeGenerator();
	if (type instanceof Types.String && Types.stringAsChar(type, {set: function($v){c = $v;}, get: function(){return c;}})){
		gen.write(String.fromChar(c));
		this.type = Types.basic().ch;
	}
	else if (Types.isInt(type) || type == Types.basic().ch){
		this.type = type;
	}
	else {
		Errors.raise(Types.intsDescription() + " or 'CHAR' expected as CASE expression");
	}
	gen.write(";" + Chars.ln);
};
Type.prototype.beginCase = function(){
	if (!this.firstCaseParsed){
		this.firstCaseParsed = true;
	}
	else {
		this.codeGenerator().write("else ");
	}
};
Type.prototype.handleLabelType = function(type/*PType*/){
	if (!Cast.areTypesMatch(type, this.type)){
		Errors.raise("label must be '" + this.type.description() + "' (the same as case expression), got '" + type.description() + "'");
	}
};
LabelList.prototype.handleRange = function(from/*PInt*/, to/*PInt*/){
	var cond = '';
	var parent = RTL$.typeGuard(this.parent(), Label);
	if (this.glue.length == 0){
		parent.caseLabelBegin();
	}
	var v = RTL$.typeGuard(parent.parent(), Type).var$;
	if (to == null){
		cond = v + " === " + String.fromInt(from.value);
	}
	else {
		cond = "(" + v + " >= " + String.fromInt(from.value) + " && " + v + " <= " + String.fromInt(to.value) + ")";
	}
	this.codeGenerator().write(this.glue + cond);
	this.glue = " || ";
};
LabelList.prototype.endParse = function(){
	RTL$.typeGuard(this.parent(), Label).caseLabelEnd();
	return true;
};
Label.prototype.caseLabelBegin = function(){
	RTL$.typeGuard(this.parent(), Type).beginCase();
	this.codeGenerator().write("if (");
};
Label.prototype.caseLabelEnd = function(){
	var gen = this.codeGenerator();
	gen.write(")");
	gen.openScope();
};
Label.prototype.endParse = function(){
	this.codeGenerator().closeScope("");
	return true;
};

function handleLabel(r/*VAR Range*/, type/*PType*/, v/*PInt*/){
	RTL$.typeGuard(r.parent().parent().parent(), Type).handleLabelType(type);
	if (r.from == null){
		r.from = v;
	}
	else {
		r.to = v;
	}
}
Range.prototype.codeGenerator = function(){
	return CodeGenerator.nullGenerator();
};
Range.prototype.handleExpression = function(e/*PType*/){
	var c = 0;
	var type = e.type();
	if (type instanceof Types.String){
		if (!Types.stringAsChar(type, {set: function($v){c = $v;}, get: function(){return c;}})){
			Errors.raise("single-character string expected");
		}
		handleLabel(this, Types.basic().ch, new ConstValue.Int(c));
	}
	else {
		handleLabel(this, type, RTL$.typeGuard(e.constValue(), ConstValue.Int));
	}
};
Range.prototype.handleIdent = function(id/*STRING*/){
	var info = ContextHierarchy.getSymbol(this.root(), id).info();
	if (!(info instanceof Types.Const)){
		Errors.raise("'" + id + "' is not a constant");
	}
	else {
		var type = info.type;
		if (type instanceof Types.String){
			this.handleExpression(Expression.makeSimple("", type));
		}
		else {
			handleLabel(this, type, RTL$.typeGuard(info.value, ConstValue.Int));
		}
	}
};
Range.prototype.endParse = function(){
	RTL$.typeGuard(this.parent(), LabelList).handleRange(this.from, this.to);
	return true;
};
exports.Type = Type;
exports.Label = Label;
exports.LabelList = LabelList;
exports.Range = Range;
