var RTL$ = require("eberon/eberon_rtl.js");
var Errors = require("js/Errors.js");
var JsMap = require("js/JsMap.js");
var Object$ = require("js/Object$.js");
var Procedures = require("js/Procedure.js");
var ScopeBase = require("js/ScopeBase.js");
var String = require("js/String.js");
var Symbols = require("js/Symbols.js");
var Types = require("js/Types.js");
RTL$.extend(Type, ScopeBase.Type);
function Procedure(){
	Type.apply(this, arguments);
	this.tempVarCounter = 0;
}
RTL$.extend(Procedure, Type);
RTL$.extend(CompiledModule, Types.Module);
RTL$.extend(Module, Type);

function addSymbolForType(t/*PBasicType*/, result/*Type*/){
	var name = '';
	name = Types.typeName(t);
	JsMap.put(result, name, new Symbols.Symbol(name, new Types.TypeId(t)));
}

function makeStdSymbols(){
	var result = null;
	
	function addSymbol(t/*PBasicType*/){
		addSymbolForType(t, result);
	}
	result = JsMap.make();
	addSymbol(Types.basic().bool);
	addSymbol(Types.basic().ch);
	addSymbol(Types.basic().integer);
	addSymbol(Types.basic().uint8);
	addSymbol(Types.basic().real);
	addSymbol(Types.basic().set);
	for (var i = 0; i <= Procedures.predefined().length - 1 | 0; ++i){
		var proc = Procedures.predefined()[i];
		JsMap.put(result, proc.id(), proc);
	}
	return result;
}
function Type(stdSymbols/*Type*/){
	ScopeBase.Type.call(this);
	this.stdSymbols = stdSymbols;
	this.symbols = JsMap.make();
	this.unresolved = [];
	this.finalizers = [];
}
function CompiledModule(name/*STRING*/){
	Types.Module.call(this, name);
	this.exports = JsMap.make();
}
function Module(name/*STRING*/, stdSymbols/*Type*/){
	Type.call(this, stdSymbols);
	this.symbol = new Symbols.Symbol(name, new CompiledModule(name));
	this.exports = JsMap.make();
	this.tempVarCounter = 0;
	this.addSymbol(this.symbol, false);
}

function addUnresolved(s/*VAR Type*/, id/*STRING*/){
	if (s.unresolved.indexOf(id) == -1){
		s.unresolved.push(id);
	}
}

function resolve(s/*VAR Type*/, symbol/*PSymbol*/){
	var id = '';
	var i = 0;
	var info = null;
	var type = null;
	id = symbol.id();
	i = s.unresolved.indexOf(id);
	if (i != -1){
		info = symbol.info();
		type = RTL$.typeGuard(info, Types.TypeId).type();
		if (type != null && !(type instanceof Types.Record)){
			Errors.raise("'" + id + "' must be of RECORD type because it was used before in the declation of POINTER");
		}
		s.unresolved.splice(i, 1);
	}
}

function unresolved(s/*Type*/){
	return s.unresolved.slice();
}
Type.prototype.close = function(){
	for (var i = this.finalizers.length - 1 | 0; i >= 0; i -= 1){
		var finalizer = this.finalizers[i];
		finalizer.proc(finalizer.closure);
	}
	this.finalizers.splice(0, Number.MAX_VALUE);
}
function Finalizer(proc/*FinalizerProc*/, closure/*PType*/){
	this.proc = proc;
	this.closure = closure;
}
Type.prototype.addFinalizer = function(proc/*FinalizerProc*/, closure/*PType*/){
	this.finalizers.push(new Finalizer(proc, closure));
}

function close(s/*Type*/){
	return s.unresolved.slice();
}
Type.prototype.addSymbol = function(s/*PSymbol*/, exported/*BOOLEAN*/){
	var id = '';
	id = s.id();
	if (this.findSymbol(id) != null){
		Errors.raise("'" + id + "' already declared");
	}
	JsMap.put(this.symbols, id, s);
}
Type.prototype.findSymbol = function(id/*STRING*/){
	var result = null;
	var found = null;
	if (!JsMap.find(this.symbols, id, {set: function($v){result = $v;}, get: function(){return result;}})){
		var void$ = JsMap.find(this.stdSymbols, id, {set: function($v){result = $v;}, get: function(){return result;}});
	}
	if (result != null){
		found = new Symbols.FoundSymbol(RTL$.typeGuard(result, Symbols.Symbol), this);
	}
	return found;
}
Procedure.prototype.name = function(){
	return "procedure";
}
Procedure.prototype.addSymbol = function(s/*PSymbol*/, exported/*BOOLEAN*/){
	var info = null;
	if (exported){
		info = s.info();
		Errors.raise("cannot export from within procedure: " + info.idType() + " '" + s.id() + "'");
	}
	Type.prototype.addSymbol.call(this, s, exported);
}

function generateTempVar(pattern/*STRING*/, counter/*VAR INTEGER*/){
	counter.set(counter.get() + 1 | 0);
	return "$" + pattern + String.fromInt(counter.get());
}
Procedure.prototype.generateTempVar = function(pattern/*STRING*/){
	return generateTempVar(pattern, RTL$.makeRef(this, "tempVarCounter"));
}
Module.prototype.generateTempVar = function(pattern/*STRING*/){
	return generateTempVar(pattern, RTL$.makeRef(this, "tempVarCounter"));
}

function makeProcedure(stdSymbols/*Type*/){
	return new Procedure(stdSymbols);
}

function addExport(id/*STRING*/, value/*PType*/, closure/*VAR Type*/){
	var symbol = null;
	var info = null;
	symbol = RTL$.typeGuard(value, Symbols.Symbol);
	info = symbol.info();
	if (info instanceof Types.Variable){
		symbol = new Symbols.Symbol(id, Types.makeExportedVariable(RTL$.typeGuard(info, Types.Variable)));
	}
	JsMap.put(RTL$.typeGuard(closure, CompiledModule).exports, id, symbol);
}

function defineExports(m/*VAR CompiledModule*/, exports/*Type*/){
	JsMap.forEach(exports, addExport, m);
}
CompiledModule.prototype.findSymbol = function(id/*STRING*/){
	var s = null;
	var result = null;
	if (JsMap.find(this.exports, id, {set: function($v){s = $v;}, get: function(){return s;}})){
		result = new Symbols.FoundSymbol(RTL$.typeGuard(s, Symbols.Symbol), null);
	}
	return result;
}
Module.prototype.name = function(){
	return "module";
}
Module.prototype.addSymbol = function(s/*PSymbol*/, exported/*BOOLEAN*/){
	Type.prototype.addSymbol.call(this, s, exported);
	if (exported){
		JsMap.put(this.exports, s.id(), s);
	}
}

function moduleSymbol(m/*Module*/){
	return m.symbol;
}

function moduleExports(m/*Module*/){
	return m.exports;
}
exports.Type = Type;
exports.Procedure = Procedure;
exports.Module = Module;
exports.addSymbolForType = addSymbolForType;
exports.makeStdSymbols = makeStdSymbols;
exports.addUnresolved = addUnresolved;
exports.resolve = resolve;
exports.unresolved = unresolved;
exports.close = close;
exports.makeProcedure = makeProcedure;
exports.defineExports = defineExports;
exports.moduleSymbol = moduleSymbol;
exports.moduleExports = moduleExports;
