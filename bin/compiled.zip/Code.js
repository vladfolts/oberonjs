var RTL$ = require("eberon/eberon_rtl.js");
var CodeGenerator = require("js/CodeGenerator.js");
var Errors = require("js/Errors.js");
var Object$ = require("js/Object$.js");
var Stream = require("js/Stream.js");
var ScopeBase = require("js/ScopeBase.js");
var Symbols = require("js/Symbols.js");
var Precedence = require("js/CodePrecedence.js");
var String = require("js/String.js");
var Types = require("js/Types.js");
function Const(){
}
function IntConst(){
	Const.call(this);
	this.value = 0;
}
RTL$.extend(IntConst, Const);
function RealConst(){
	Const.call(this);
	this.value = 0;
}
RTL$.extend(RealConst, Const);
function SetConst(){
	Const.call(this);
	this.value = 0;
}
RTL$.extend(SetConst, Const);
function StringConst(){
	Const.call(this);
	this.value = '';
}
RTL$.extend(StringConst, Const);
RTL$.extend(Expression, Object$.Type);
Expression.prototype.code = function(){
	return this.mCode;
}
Expression.prototype.lval = function(){
	var result = '';
	if (this.mDesignator != null){
		result = this.mDesignator.mLval;
	}
	else {
		result = this.mCode;
	}
	return result;
}
Expression.prototype.type = function(){
	return this.mType;
}
Expression.prototype.designator = function(){
	return this.mDesignator;
}
Expression.prototype.constValue = function(){
	return this.mConstValue;
}
Expression.prototype.maxPrecedence = function(){
	return this.mMaxPrecedence;
}
Expression.prototype.isTerm = function(){
	return this.mDesignator == null && this.mMaxPrecedence == Precedence.none;
}

function makeIntConst(n/*INTEGER*/){
	var result = new IntConst();
	result.value = n;
	return result;
}

function makeRealConst(n/*REAL*/){
	var result = new RealConst();
	result.value = n;
	return result;
}

function makeSetConst(s/*SET*/){
	var result = new SetConst();
	result.value = s;
	return result;
}

function makeStringConst(s/*STRING*/){
	var result = new StringConst();
	result.value = s;
	return result;
}
function Expression(code/*STRING*/, type/*PType*/, designator/*PDesignator*/, constValue/*PConst*/, maxPrecedence/*INTEGER*/){
	Object$.Type.call(this);
	this.mCode = code;
	this.mType = type;
	this.mDesignator = designator;
	this.mConstValue = constValue;
	this.mMaxPrecedence = maxPrecedence;
}

function makeExpression(code/*STRING*/, type/*PType*/, designator/*PDesignator*/, constValue/*PConst*/){
	return new Expression(code, type, designator, constValue, Precedence.none);
}

function makeSimpleExpression(code/*STRING*/, type/*PType*/){
	return makeExpression(code, type, null, null);
}
Designator.prototype.code = function(){
	return this.mCode;
}
Designator.prototype.lval = function(){
	return this.mLval;
}
Designator.prototype.refCode = function(){
	return this.mRefCode;
}
Designator.prototype.type = function(){
	return this.mType;
}
Designator.prototype.info = function(){
	return this.mInfo;
}
Designator.prototype.scope = function(){
	return this.mScope;
}
function Designator(code/*STRING*/, lval/*STRING*/, refCode/*RefCodeProc*/, type/*PType*/, info/*PId*/, scope/*PType*/){
	this.mCode = code;
	this.mLval = lval;
	this.mRefCode = refCode;
	this.mType = type;
	this.mInfo = info;
	this.mScope = scope;
}

function derefExpression(e/*PExpression*/){
	var result = null;
	if (e.mDesignator == null || (e.mType instanceof Types.Array || e.mType instanceof Types.Record) || !(e.mDesignator.mInfo instanceof Types.Variable && RTL$.typeGuard(e.mDesignator.mInfo, Types.Variable).isReference())){
		result = e;
	}
	else {
		result = makeSimpleExpression(e.mCode + ".get()", e.mType);
	}
	return result;
}

function refExpression(e/*PExpression*/){
	var result = null;
	if (e.mDesignator == null || e.mDesignator.mInfo instanceof Types.Variable && RTL$.typeGuard(e.mDesignator.mInfo, Types.Variable).isReference()){
		result = e;
	}
	else {
		result = makeSimpleExpression(e.mDesignator.mRefCode(e.mDesignator.mCode), e.mType);
	}
	return result;
}

function adjustPrecedence(e/*PExpression*/, precedence/*INTEGER*/){
	var result = '';
	result = e.mCode;
	if (precedence != Precedence.none && e.mMaxPrecedence > precedence){
		result = "(" + result + ")";
	}
	return result;
}

function isPointerShouldBeExported(type/*Pointer*/){
	var r = null;
	var result = '';
	r = Types.pointerBase(type);
	if (Types.typeName(r).length == 0){
		result = Types.recordConstructor(r);
	}
	return result;
}

function typeShouldBeExported(typeId/*PId*/, defaultId/*STRING*/){
	var result = '';
	var type = null;
	type = RTL$.typeGuard(typeId, Types.TypeId).type();
	if (type instanceof Types.Record){
		result = defaultId;
	}
	else if (type instanceof Types.Pointer){
		result = isPointerShouldBeExported(RTL$.typeGuard(type, Types.Pointer));
	}
	return result;
}

function genExport(s/*Symbol*/){
	var result = '';
	if (s.isVariable()){
		result = "function(){return " + s.id() + ";}";
	}
	else if (!s.isType()){
		result = s.id();
	}
	else {
		result = typeShouldBeExported(s.info(), s.id());
	}
	return result;
}

function genCommaList(m/*MAP OF STRING*/, import$/*BOOLEAN*/){
	var result = '';
	var $map1 = m;
	for(var name in $map1){
		var alias = $map1[name];
		if (result.length != 0){
			result = result + ", ";
		}
		if (import$){
			result = result + alias;
		}
		else {
			result = result + name;
		}
	}
	return result;
}
ModuleGenerator.prototype.prolog = function(){
	return "var " + this.name + " = function (" + genCommaList(this.imports, true) + "){" + Stream.kCR;
}
ModuleGenerator.prototype.epilog = function(exports/*MAP OF PSymbol*/){
	var result = '';
	var $map1 = exports;
	for(var k in $map1){
		var s = $map1[k];
		var code = genExport(s);
		if (code.length != 0){
			if (result.length != 0){
				result = result + "," + Stream.kCR;
			}
			result = result + CodeGenerator.kTab + s.id() + ": " + code;
		}
	}
	if (result.length != 0){
		result = "return {" + Stream.kCR + result + Stream.kCR + "}" + Stream.kCR;
	}
	result = result + "}(" + genCommaList(this.imports, false) + ");" + Stream.kCR;
	return result;
}
function ModuleGenerator(name/*STRING*/, imports/*MAP OF STRING*/){
	this.name = name;
	this.imports = RTL$.cloneMapOfScalars(imports);
}

function checkIndex(i/*INTEGER*/){
	if (i < 0){
		Errors.raise("index is negative: " + String.fromInt(i));
	}
}
exports.Designator = Designator;
exports.Const = Const;
exports.IntConst = IntConst;
exports.RealConst = RealConst;
exports.SetConst = SetConst;
exports.StringConst = StringConst;
exports.Expression = Expression;
exports.ModuleGenerator = ModuleGenerator;
exports.makeIntConst = makeIntConst;
exports.makeRealConst = makeRealConst;
exports.makeSetConst = makeSetConst;
exports.makeStringConst = makeStringConst;
exports.makeExpression = makeExpression;
exports.makeSimpleExpression = makeSimpleExpression;
exports.derefExpression = derefExpression;
exports.refExpression = refExpression;
exports.adjustPrecedence = adjustPrecedence;
exports.genExport = genExport;
exports.checkIndex = checkIndex;
