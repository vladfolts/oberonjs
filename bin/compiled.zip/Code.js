var RTL$ = require("rtl.js");
var JsMap = require("js/JsMap.js");
var Object = require("js/Object.js");
var Stream = require("js/Stream.js");
var ScopeBase = require("js/ScopeBase.js");
var Symbols = require("js/Symbols.js");
var Precedence = require("js/CodePrecedence.js");
var String = require("js/String.js");
var Types = require("js/Types.js");
var kTab = "\t";
var IGenerator = RTL$.extend({
	init: function IGenerator(){
	}
});
var NullGenerator = IGenerator.extend({
	init: function NullGenerator(){
		IGenerator.prototype.init.call(this);
	}
});
var SimpleGenerator = NullGenerator.extend({
	init: function SimpleGenerator(){
		NullGenerator.prototype.init.call(this);
		this.mResult = '';
	}
});
var Generator = SimpleGenerator.extend({
	init: function Generator(){
		SimpleGenerator.prototype.init.call(this);
		this.indent = 0;
	}
});
var Designator = RTL$.extend({
	init: function Designator(){
		this.mCode = '';
		this.mLval = '';
		this.mRefCode = null;
		this.mType = null;
		this.mInfo = null;
		this.mScope = null;
	}
});
var Const = RTL$.extend({
	init: function Const(){
	}
});
var IntConst = Const.extend({
	init: function IntConst(){
		Const.prototype.init.call(this);
		this.value = 0;
	}
});
var RealConst = Const.extend({
	init: function RealConst(){
		Const.prototype.init.call(this);
		this.value = 0;
	}
});
var SetConst = Const.extend({
	init: function SetConst(){
		Const.prototype.init.call(this);
		this.value = 0;
	}
});
var StringConst = Const.extend({
	init: function StringConst(){
		Const.prototype.init.call(this);
		this.value = '';
	}
});
var Expression = Object.Type.extend({
	init: function Expression(){
		Object.Type.prototype.init.call(this);
		this.mCode = '';
		this.mType = null;
		this.mDesignator = null;
		this.mConstValue = null;
		this.mMaxPrecedence = 0;
	}
});
var ModuleGenerator = RTL$.extend({
	init: function ModuleGenerator(){
		this.name = '';
		this.imports = null;
	}
});
var Closure = Object.Type.extend({
	init: function Closure(){
		Object.Type.prototype.init.call(this);
		this.result = '';
	}
});
var nullGenerator = new NullGenerator();
NullGenerator.prototype.write = function(s/*STRING*/){
}
NullGenerator.prototype.openScope = function(){
}
NullGenerator.prototype.closeScope = function(ending/*STRING*/){
}
NullGenerator.prototype.result = function(){
	return "";
}
SimpleGenerator.prototype.write = function(s/*STRING*/){
	this.mResult = this.mResult + s;
}
SimpleGenerator.prototype.result = function(){
	return this.mResult;
}

function putIndent(s/*STRING*/, indent/*INTEGER*/){
	var i = 0;
	for (i = 0; i <= indent - 1 | 0; ++i){
		s = s + kTab;
	}
	return s;
}
Generator.prototype.write = function(s/*STRING*/){
	var pos = 0;
	var index = 0;
	index = String.indexOf(s, 10);
	while (true){
		if (index != -1){
			++index;
			this.mResult = this.mResult + String.substr(s, pos, index - pos | 0);
			this.mResult = putIndent(this.mResult, this.indent);
			pos = index;
			index = String.indexOfFrom(s, 10, pos);
		} else break;
	}
	this.mResult = this.mResult + String.substr(s, pos, s.length - pos | 0);
}
Generator.prototype.openScope = function(){
	++this.indent;
	this.mResult = this.mResult + "{" + Stream.kCR;
	this.mResult = putIndent(this.mResult, this.indent);
}
Generator.prototype.closeScope = function(ending/*STRING*/){
	--this.indent;
	this.mResult = String.substr(this.mResult, 0, this.mResult.length - 1 | 0) + "}";
	if (ending.length != 0){
		this.write(ending);
	}
	else {
		this.mResult = this.mResult + Stream.kCR;
		this.mResult = putIndent(this.mResult, this.indent);
	}
}
Expression.prototype.code = function(){
	return this.mCode;
}
Expression.prototype.lval = function(){
	var result = '';
	if (this.mDesignator != null){
		result = this.mDesignator.mLval;
	}
	else {
		result = this.mCode;
	}
	return result;
}
Expression.prototype.type = function(){
	return this.mType;
}
Expression.prototype.designator = function(){
	return this.mDesignator;
}
Expression.prototype.constValue = function(){
	return this.mConstValue;
}
Expression.prototype.maxPrecedence = function(){
	return this.mMaxPrecedence;
}
Expression.prototype.isTerm = function(){
	return this.mDesignator == null && this.mMaxPrecedence == Precedence.none;
}

function makeIntConst(n/*INTEGER*/){
	var result = null;
	result = new IntConst();
	result.value = n;
	return result;
}

function makeRealConst(n/*REAL*/){
	var result = null;
	result = new RealConst();
	result.value = n;
	return result;
}

function makeSetConst(s/*SET*/){
	var result = null;
	result = new SetConst();
	result.value = s;
	return result;
}

function makeStringConst(s/*STRING*/){
	var result = null;
	result = new StringConst();
	result.value = s;
	return result;
}

function makeExpressionWithPrecedence(code/*STRING*/, type/*PType*/, designator/*PDesignator*/, constValue/*PConst*/, maxPrecedence/*INTEGER*/){
	var result = null;
	result = new Expression();
	result.mCode = code;
	result.mType = type;
	result.mDesignator = designator;
	result.mConstValue = constValue;
	result.mMaxPrecedence = maxPrecedence;
	return result;
}

function makeExpression(code/*STRING*/, type/*PType*/, designator/*PDesignator*/, constValue/*PConst*/){
	return makeExpressionWithPrecedence(code, type, designator, constValue, Precedence.none);
}

function makeSimpleExpression(code/*STRING*/, type/*PType*/){
	return makeExpression(code, type, null, null);
}
Designator.prototype.code = function(){
	return this.mCode;
}
Designator.prototype.lval = function(){
	return this.mLval;
}
Designator.prototype.refCode = function(){
	return this.mRefCode;
}
Designator.prototype.type = function(){
	return this.mType;
}
Designator.prototype.info = function(){
	return this.mInfo;
}
Designator.prototype.scope = function(){
	return this.mScope;
}

function makeDesignator(code/*STRING*/, lval/*STRING*/, refCode/*RefCodeProc*/, type/*PType*/, info/*PId*/, scope/*PType*/){
	var result = null;
	result = new Designator();
	result.mCode = code;
	result.mLval = lval;
	result.mRefCode = refCode;
	result.mType = type;
	result.mInfo = info;
	result.mScope = scope;
	return result;
}

function derefExpression(e/*PExpression*/){
	var result = null;
	if (e.mDesignator == null || (e.mType instanceof Types.Array || e.mType instanceof Types.Record) || !(e.mDesignator.mInfo instanceof Types.VariableRef)){
		result = e;
	}
	else {
		result = makeSimpleExpression(e.mCode + ".get()", e.mType);
	}
	return result;
}

function refExpression(e/*PExpression*/){
	var result = null;
	if (e.mDesignator == null || e.mDesignator.mInfo instanceof Types.VariableRef){
		result = e;
	}
	else {
		result = makeSimpleExpression(e.mDesignator.mRefCode(e.mDesignator.mCode), e.mType);
	}
	return result;
}

function adjustPrecedence(e/*PExpression*/, precedence/*INTEGER*/){
	var result = '';
	result = e.mCode;
	if (precedence != Precedence.none && e.mMaxPrecedence > precedence){
		result = "(" + result + ")";
	}
	return result;
}

function isPointerShouldBeExported(type/*Pointer*/){
	var r = null;
	var result = '';
	r = Types.pointerBase(type);
	if (Types.typeName(r).length == 0){
		result = Types.recordConstructor(r);
	}
	return result;
}

function typeShouldBeExported(typeId/*PId*/, defaultId/*STRING*/){
	var result = '';
	var type = null;
	type = RTL$.typeGuard(typeId, Types.TypeId).type();
	if (type instanceof Types.Record){
		result = defaultId;
	}
	else if (type instanceof Types.Pointer){
		result = isPointerShouldBeExported(RTL$.typeGuard(type, Types.Pointer));
	}
	return result;
}

function genExport(s/*Symbol*/){
	var result = '';
	if (s.isVariable()){
		result = "function(){return " + s.id() + ";}";
	}
	else if (!s.isType()){
		result = s.id();
	}
	else {
		result = typeShouldBeExported(s.info(), s.id());
	}
	return result;
}

function genCommaList(name/*STRING*/, closure/*VAR Closure*/){
	if (closure.result.length != 0){
		closure.result = closure.result + ", ";
	}
	closure.result = closure.result + name;
}

function genAliasesAdaptor(key/*STRING*/, value/*STRING*/, closure/*VAR Type*/){
	genCommaList(value, RTL$.typeGuard(closure, Closure));
}
ModuleGenerator.prototype.prolog = function(){
	var closure = new Closure();
	JsMap.forEachString(this.imports, genAliasesAdaptor, closure);
	return "var " + this.name + " = function (" + closure.result + "){" + Stream.kCR;
}

function genExports(s/*Symbol*/, closure/*VAR Closure*/){
	var code = '';
	code = genExport(s);
	if (code.length != 0){
		if (closure.result.length != 0){
			closure.result = closure.result + "," + Stream.kCR;
		}
		closure.result = closure.result + kTab + s.id() + ": " + code;
	}
}

function genExportsAdaptor(key/*STRING*/, value/*PType*/, closure/*VAR Type*/){
	genExports(RTL$.typeGuard(value, Symbols.Symbol), RTL$.typeGuard(closure, Closure));
}

function genImportListAdaptor(key/*STRING*/, value/*STRING*/, closure/*VAR Type*/){
	genCommaList(key, RTL$.typeGuard(closure, Closure));
}
ModuleGenerator.prototype.epilog = function(exports/*Type*/){
	var result = '';
	var closure = new Closure();
	JsMap.forEach(exports, genExportsAdaptor, closure);
	result = closure.result;
	if (result.length != 0){
		result = "return {" + Stream.kCR + result + Stream.kCR + "}" + Stream.kCR;
	}
	result = result + "}(";
	closure.result = "";
	JsMap.forEachString(this.imports, genImportListAdaptor, closure);
	result = result + closure.result + ");" + Stream.kCR;
	return result;
}

function makeSimpleGenerator(){
	var result = null;
	result = new SimpleGenerator();
	return result;
}

function makeGenerator(){
	var result = null;
	result = new Generator();
	return result;
}

function makeModuleGenerator(name/*STRING*/, imports/*Strings*/){
	var result = null;
	result = new ModuleGenerator();
	result.name = name;
	result.imports = imports;
	return result;
}
exports.Designator = Designator;
exports.Const = Const;
exports.IntConst = IntConst;
exports.RealConst = RealConst;
exports.SetConst = SetConst;
exports.StringConst = StringConst;
exports.Expression = Expression;
exports.nullGenerator = function(){return nullGenerator;};
exports.makeIntConst = makeIntConst;
exports.makeRealConst = makeRealConst;
exports.makeSetConst = makeSetConst;
exports.makeStringConst = makeStringConst;
exports.makeExpressionWithPrecedence = makeExpressionWithPrecedence;
exports.makeExpression = makeExpression;
exports.makeSimpleExpression = makeSimpleExpression;
exports.makeDesignator = makeDesignator;
exports.derefExpression = derefExpression;
exports.refExpression = refExpression;
exports.adjustPrecedence = adjustPrecedence;
exports.genExport = genExport;
exports.makeSimpleGenerator = makeSimpleGenerator;
exports.makeGenerator = makeGenerator;
exports.makeModuleGenerator = makeModuleGenerator;
