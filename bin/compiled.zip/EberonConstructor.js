var RTL$ = require("rtl.js");
var Code = require("js/Code.js");
var EberonRecord = require("js/EberonRecord.js");
var LanguageContext = require("js/LanguageContext.js");
var Procedure = require("js/Procedure.js");
var Stream = require("js/Stream.js");
var Types = require("js/Types.js");
function ConstructorCall(){
	Procedure.StdCall.call(this);
	this.recordType = null;
}
RTL$.extend(ConstructorCall, Procedure.StdCall);
function BaseConstructorCall(){
	ConstructorCall.call(this);
}
RTL$.extend(BaseConstructorCall, ConstructorCall);

function checkArgs(call/*ConstructorCall*/, args/*ARRAY OF PExpression*/, cx/*PType*/){
	var argCode = Procedure.makeArgumentsCode(cx);
	Procedure.processArguments(args, call.args, argCode, cx.types);
	return argCode.result();
}
ConstructorCall.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
	var argCode = checkArgs(this, args, cx);
	return Code.makeSimpleExpression(this.recordType.initializer(cx, false, argCode), this.recordType);
}
BaseConstructorCall.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
	var argCode = checkArgs(this, args, cx);
	var code = cx.qualifyScope(this.recordType.scope) + this.recordType.cons + ".call(this, " + argCode + ");" + Stream.kCR;
	return Code.makeSimpleExpression(code, null);
}

function makeCallGenerator(type/*PRecord*/, cx/*PType*/, call/*PConstructorCall*/){
	Procedure.initStdCall(call);
	call.recordType = type;
	if (type.customConstructor != null){
		Array.prototype.splice.apply(call.args, [0, Number.MAX_VALUE].concat(type.customConstructor.args()));
	}
	return Procedure.makeCallGenerator(call, cx);
}

function makeConstructorCall(type/*PRecord*/, cx/*PType*/){
	var call = null;
	call = new ConstructorCall();
	return makeCallGenerator(type, cx, call);
}

function makeBaseConstructorCall(type/*PRecord*/, cx/*PType*/){
	var call = null;
	call = new BaseConstructorCall();
	return makeCallGenerator(type, cx, call);
}
exports.makeConstructorCall = makeConstructorCall;
exports.makeBaseConstructorCall = makeBaseConstructorCall;
