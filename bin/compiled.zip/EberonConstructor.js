var RTL$ = require("rtl.js");
var Code = require("js/Code.js");
var EberonRecord = require("js/EberonRecord.js");
var Errors = require("js/Errors.js");
var LanguageContext = require("js/LanguageContext.js");
var Operator = require("js/Operator.js");
var Procedure = require("js/Procedure.js");
var Stream = require("js/Stream.js");
var Types = require("js/Types.js");
function ConstructorCall(){
	Procedure.StdCall.call(this);
	this.recordType = null;
}
RTL$.extend(ConstructorCall, Procedure.StdCall);
function BaseConstructorCall(){
	ConstructorCall.call(this);
}
RTL$.extend(BaseConstructorCall, ConstructorCall);
function NonRecordInitCall(){
	Procedure.CallGenerator.call(this);
	this.cx = null;
	this.type = null;
	this.field = '';
	this.code = '';
}
RTL$.extend(NonRecordInitCall, Procedure.CallGenerator);

function checkArgs(call/*ConstructorCall*/, args/*ARRAY OF PExpression*/, cx/*PType*/){
	var argCode = Procedure.makeArgumentsCode(cx);
	Procedure.processArguments(args, call.args, argCode, cx.types);
	return argCode.result();
}
ConstructorCall.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
	var argCode = checkArgs(this, args, cx);
	return Code.makeSimpleExpression(this.recordType.initializer(cx, false, argCode), this.recordType);
}
BaseConstructorCall.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
	var argCode = checkArgs(this, args, cx);
	var code = cx.qualifyScope(this.recordType.scope) + this.recordType.cons + ".call(this, " + argCode + ");" + Stream.kCR;
	return Code.makeSimpleExpression(code, null);
}

function makeCallGenerator(type/*PRecord*/, cx/*PType*/, call/*PConstructorCall*/){
	Procedure.initStdCall(call);
	call.recordType = type;
	if (type.customConstructor != null){
		Array.prototype.splice.apply(call.args, [0, Number.MAX_VALUE].concat(type.customConstructor.args()));
	}
	return Procedure.makeCallGenerator(call, cx);
}

function raiseSingleArgumentException(c/*NonRecordInitCall*/){
	Errors.raise("single argument expected to initialize field '" + c.field + "'");
}
NonRecordInitCall.prototype.handleArgument = function(e/*PExpression*/){
	if (this.code.length != 0){
		raiseSingleArgumentException(this);
	}
	var variable = Types.makeVariable(this.type, false);
	var designator = Code.makeDesignator(this.field, this.field, null, this.type, variable, null);
	var left = Code.makeExpression(this.field, this.type, designator, null);
	this.code = Operator.assign(left, e, this.cx);
}
NonRecordInitCall.prototype.end = function(){
	if (this.code.length == 0){
		raiseSingleArgumentException(this);
	}
	return Code.makeSimpleExpression(this.code, null);
}

function makeConstructorCall(type/*PRecord*/, cx/*PType*/){
	var call = null;
	call = new ConstructorCall();
	return makeCallGenerator(type, cx, call);
}

function makeFieldInitCall(type/*PType*/, cx/*PType*/, field/*STRING*/){
	var result = null;
	
	function initNonRecord(){
		var result = null;
		result = new NonRecordInitCall();
		result.cx = cx;
		result.field = field;
		result.type = type;
		return result;
	}
	if (type instanceof EberonRecord.Record){
		result = makeConstructorCall(type, cx);
	}
	else {
		result = initNonRecord();
	}
	return result;
}

function makeBaseConstructorCall(type/*PRecord*/, cx/*PType*/){
	var call = null;
	call = new BaseConstructorCall();
	return makeCallGenerator(type, cx, call);
}
exports.makeConstructorCall = makeConstructorCall;
exports.makeFieldInitCall = makeFieldInitCall;
exports.makeBaseConstructorCall = makeBaseConstructorCall;
