var RTL$ = require("rtl.js");
var Code = require("js/Code.js");
var EberonRecord = require("js/EberonRecord.js");
var LanguageContext = require("js/LanguageContext.js");
var Procedure = require("js/Procedure.js");
var Types = require("js/Types.js");
function ConstructorCall(){
	Procedure.StdCall.call(this);
	this.recordType = null;
}
RTL$.extend(ConstructorCall, Procedure.StdCall);
ConstructorCall.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
	var argCode = Procedure.makeArgumentsCode(cx);
	Procedure.processArguments(args, this.args, argCode, cx.types);
	return Code.makeSimpleExpression(this.recordType.initializer(cx, false, argCode.result()), this.recordType);
}

function makeConstructorCall(type/*PRecord*/, cx/*PType*/){
	var call = null;
	call = new ConstructorCall();
	Procedure.initStdCall(call);
	call.recordType = type;
	if (type.customConstructor != null){
		Array.prototype.splice.apply(call.args, [0, Number.MAX_VALUE].concat(type.customConstructor.args()));
	}
	return Procedure.makeCallGenerator(call, cx);
}
exports.makeConstructorCall = makeConstructorCall;
