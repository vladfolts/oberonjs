var RTL$ = require("rtl.js");
var Code = require("js/Code.js");
var LanguageContext = require("js/LanguageContext.js");
var Procedure = require("js/Procedure.js");
var Types = require("js/Types.js");
function ConstructorCall(){
	Procedure.StdCall.call(this);
	this.recordType = null;
}
RTL$.extend(ConstructorCall, Procedure.StdCall);
ConstructorCall.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
	Procedure.processArguments(args, this.args, null, null);
	return Code.makeSimpleExpression(this.recordType.initializer(cx, false), this.recordType);
}

function makeConstructorCall(type/*PRecord*/, cx/*PType*/){
	var call = null;
	call = new ConstructorCall();
	Procedure.initStdCall(call);
	call.recordType = type;
	return Procedure.makeCallGenerator(call, cx);
}
exports.makeConstructorCall = makeConstructorCall;
