var RTL$ = require("eberon/eberon_rtl.js");
var Context = require("js/Context.js");
var Errors = require("js/Errors.js");
var Expression = require("js/Expression.js");
var LanguageContext = require("js/LanguageContext.js");
var Procedure = require("js/Procedure.js");
var Symbols = require("js/Symbols.js");
var TypeId = require("js/TypeId.js");
var Types = require("js/Types.js");
var Variable = require("js/Variable.js");
var $scope = "Module";
var doProcId = "do";
var varTypeId = "var";
function Type(){
	Types.Module.apply(this, arguments);
}
RTL$.extend(Type, Types.Module, $scope);
function JS(){
	Type.apply(this, arguments);
}
RTL$.extend(JS, Type, $scope);
var doProcSymbol = null;var varTypeSymbol = null;
JS.prototype.findSymbol = function(id/*STRING*/){
	var result = null;
	if (id == doProcId){
		result = doProcSymbol;
	}
	else if (id == varTypeId){
		result = varTypeSymbol;
	}
	else {
		result = new Symbols.Symbol(id, Types.anyVar());
	}
	return new Symbols.FoundSymbol(result, null);
};

function makeDoProcSymbol(){
	var $scope1 = $scope + ".makeDoProcSymbol";
	function Call(){
		Procedure.StdCall.call(this);
	}
	RTL$.extend(Call, Procedure.StdCall, $scope1);
	function Proc(){
		Procedure.Std.apply(this, arguments);
	}
	RTL$.extend(Proc, Procedure.Std, $scope1);
	var description = '';
	Call.prototype.make = function(args/*ARRAY OF PType*/, cx/*PType*/){
		var arg = null;
		var type = null;
		arg = Procedure.checkSingleArgument(args, this, cx.language.types, null);
		type = arg.type();
		if (!(type instanceof Types.String)){
			Errors.raise("string is expected as an argument of " + description + ", got " + type.description());
		}
		return Expression.makeSimple(Types.stringValue(RTL$.typeGuard(type, Types.String)), null);
	};
	Proc.prototype.description = function(){
		return description;
	};
	description = "JS predefined procedure 'do'";
	var call = new Call();
	Procedure.hasArgumentWithCustomType(call);
	return Procedure.makeStdSymbol(new Procedure.Std("", call));
}

function makeJS(){
	return new JS("JS");
}

function assertProcStatementResult(type/*PType*/){
	if (type != null && !(type instanceof Types.Any)){
		Errors.raise("procedure returning a result cannot be used as a statement");
	}
}
doProcSymbol = makeDoProcSymbol();
varTypeSymbol = new Symbols.Symbol(varTypeId, new TypeId.Type(Types.any()));
exports.Type = Type;
exports.makeJS = makeJS;
exports.assertProcStatementResult = assertProcStatementResult;
