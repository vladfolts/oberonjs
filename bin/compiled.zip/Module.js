var RTL$ = require("rtl.js");
var Code = require("js/Code.js");
var Context = require("js/Context.js");
var Errors = require("js/Errors.js");
var LanguageContext = require("js/LanguageContext.js");
var Procedure = require("js/Procedure.js");
var Symbols = require("js/Symbols.js");
var Types = require("js/Types.js");
function Type(){
	Types.Module.call(this);
}
RTL$.extend(Type, Types.Module);
function AnyType(){
	Types.StorageType.call(this);
	this.asField = null;
	this.asVar = null;
}
RTL$.extend(AnyType, Types.StorageType);
function AnyField(){
	Types.Field.call(this);
}
RTL$.extend(AnyField, Types.Field);
function AnyTypeProc(){
	Procedure.Std.call(this);
}
RTL$.extend(AnyTypeProc, Procedure.Std);
function AnyProcCall(){
	Procedure.Call.call(this);
}
RTL$.extend(AnyProcCall, Procedure.Call);
function JS(){
	Type.call(this);
}
RTL$.extend(JS, Type);
var doProcId = '';var varTypeId = '';
var any = null;
var anyProc = new AnyTypeProc();
var doProcSymbol = null;var varTypeSymbol = null;
AnyType.prototype.description = function(){
	return "JS.var";
}
AnyType.prototype.initializer = function(cx/*Type*/, forNew/*BOOLEAN*/, code/*STRING*/){
	return "undefined";
}

function makeCallGenerator(cx/*PType*/){
	var call = null;
	call = new AnyProcCall();
	return Procedure.makeCallGenerator(call, cx);
}
AnyType.prototype.callGenerator = function(cx/*PType*/){
	return makeCallGenerator(cx);
}
AnyType.prototype.denote = function(id/*STRING*/){
	return any.asField;
}
AnyType.prototype.designatorCode = function(id/*STRING*/){
	return id;
}
AnyField.prototype.id = function(){
	return "any field";
}
AnyField.prototype.exported = function(){
	return false;
}
AnyField.prototype.type = function(){
	return any;
}
AnyField.prototype.asVar = function(isReadOnly/*BOOLEAN*/, cx/*Type*/){
	return any.asVar;
}
AnyTypeProc.prototype.callGenerator = function(cx/*PType*/){
	return makeCallGenerator(cx);
}
AnyProcCall.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
	var argCode = Procedure.makeArgumentsCode(cx);
	for (var i = 0; i <= args.length - 1 | 0; ++i){
		argCode.write(args[i], null, null);
	}
	return Code.makeSimpleExpression("(" + argCode.result() + ")", any);
}
JS.prototype.findSymbol = function(id/*STRING*/){
	var result = null;
	if (id == doProcId){
		result = doProcSymbol;
	}
	else if (id == varTypeId){
		result = varTypeSymbol;
	}
	else {
		result = Symbols.makeSymbol(id, Types.makeProcedure(any));
	}
	return Symbols.makeFound(result, null);
}

function makeVarTypeSymbol(){
	return Symbols.makeSymbol(varTypeId, Types.makeTypeId(any));
}

function makeDoProcSymbol(){
	function Call(){
		Procedure.StdCall.call(this);
	}
	RTL$.extend(Call, Procedure.StdCall);
	function Proc(){
		Procedure.Std.call(this);
	}
	RTL$.extend(Proc, Procedure.Std);
	var description = '';
	var call = null;
	var proc = null;
	Call.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
		var arg = null;
		var type = null;
		arg = Procedure.checkSingleArgument(args, this, cx.types, null);
		type = arg.type();
		if (!(type instanceof Types.String)){
			Errors.raise("string is expected as an argument of " + description + ", got " + type.description());
		}
		return Code.makeSimpleExpression(Types.stringValue(RTL$.typeGuard(type, Types.String)), null);
	}
	Proc.prototype.description = function(){
		return description;
	}
	description = "JS predefined procedure 'do'";
	call = new Call();
	Procedure.initStdCall(call);
	Procedure.hasArgumentWithCustomType(call);
	proc = new Proc();
	Procedure.initStd("", call, proc);
	return Procedure.makeSymbol(proc);
}

function makeJS(){
	var result = null;
	result = new JS();
	Types.initModule(result, "this");
	return result;
}
doProcId = "do$";
varTypeId = "var$";
any = new AnyType();
any.asField = new AnyField();
any.asVar = Types.makeTypeId(any);
doProcSymbol = makeDoProcSymbol();
varTypeSymbol = makeVarTypeSymbol();
exports.Type = Type;
exports.AnyType = AnyType;
exports.AnyTypeProc = AnyTypeProc;
exports.makeJS = makeJS;
