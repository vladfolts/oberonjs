var RTL$ = require("eberon/eberon_rtl.js");
var Context = require("js/Context.js");
var Errors = require("js/Errors.js");
var Expression = require("js/Expression.js");
var LanguageContext = require("js/LanguageContext.js");
var Procedure = require("js/Procedure.js");
var Symbols = require("js/Symbols.js");
var TypeId = require("js/TypeId.js");
var Types = require("js/Types.js");
function Type(){
	Types.Module.apply(this, arguments);
}
RTL$.extend(Type, Types.Module);
RTL$.extend(AnyType, Types.Procedure);
RTL$.extend(AnyField, Types.Field);
function AnyTypeProc(){
	Procedure.Std.apply(this, arguments);
}
RTL$.extend(AnyTypeProc, Procedure.Std);
function AnyProcCall(){
	Procedure.Call.call(this);
}
RTL$.extend(AnyProcCall, Procedure.Call);
function JS(){
	Type.apply(this, arguments);
}
RTL$.extend(JS, Type);
var doProcId = '';var varTypeId = '';
var any = null;
var anyProc = new AnyTypeProc();
var doProcSymbol = null;var varTypeSymbol = null;
AnyType.prototype.description = function(){
	return "JS.var";
};
AnyType.prototype.initializer = function(cx/*Type*/){
	return "undefined";
};

function makeCallGenerator(cx/*PType*/){
	return Procedure.makeCallGenerator(new AnyProcCall(), cx);
}
AnyType.prototype.callGenerator = function(cx/*PType*/){
	return makeCallGenerator(cx);
};
AnyType.prototype.denote = function(id/*STRING*/, isReadObly/*BOOLEAN*/){
	return new AnyField(id);
};
AnyType.prototype.designatorCode = function(id/*STRING*/){
	return id;
};
AnyType.prototype.isScalar = function(){
	return false;
};
AnyField.prototype.id = function(){
	return "any field";
};
AnyField.prototype.exported = function(){
	return false;
};
AnyField.prototype.type = function(){
	return any;
};
AnyField.prototype.asVar = function(leadCode/*STRING*/, isReadOnly/*BOOLEAN*/, cx/*Type*/){
	return any.asVar;
};
AnyField.prototype.designatorCode = function(leadCode/*STRING*/, cx/*Type*/){
	return new Types.FieldCode(leadCode + "." + this.mId, "", "");
};
AnyTypeProc.prototype.callGenerator = function(cx/*PType*/){
	return makeCallGenerator(cx);
};
AnyProcCall.prototype.make = function(args/*ARRAY OF PType*/, cx/*PType*/){
	var argCode = Procedure.makeArgumentsCode(cx);
	for (var i = 0; i <= args.length - 1 | 0; ++i){
		argCode.write(args[i], null, null);
	}
	return Expression.makeSimple("(" + argCode.result() + ")", any);
};
JS.prototype.findSymbol = function(id/*STRING*/){
	var result = null;
	if (id == doProcId){
		result = doProcSymbol;
	}
	else if (id == varTypeId){
		result = varTypeSymbol;
	}
	else {
		result = new Symbols.Symbol(id, new Types.ProcedureId(any));
	}
	return new Symbols.FoundSymbol(result, null);
};

function makeVarTypeSymbol(){
	return new Symbols.Symbol(varTypeId, new TypeId.Type(any));
}

function makeDoProcSymbol(){
	function Call(){
		Procedure.StdCall.call(this);
	}
	RTL$.extend(Call, Procedure.StdCall);
	function Proc(){
		Procedure.Std.apply(this, arguments);
	}
	RTL$.extend(Proc, Procedure.Std);
	var description = '';
	Call.prototype.make = function(args/*ARRAY OF PType*/, cx/*PType*/){
		var arg = null;
		var type = null;
		arg = Procedure.checkSingleArgument(args, this, cx.types, null);
		type = arg.type();
		if (!(type instanceof Types.String)){
			Errors.raise("string is expected as an argument of " + description + ", got " + type.description());
		}
		return Expression.makeSimple(Types.stringValue(RTL$.typeGuard(type, Types.String)), null);
	};
	Proc.prototype.description = function(){
		return description;
	};
	description = "JS predefined procedure 'do'";
	var call = new Call();
	Procedure.hasArgumentWithCustomType(call);
	return Procedure.makeSymbol(new Procedure.Std("", call));
}

function makeJS(){
	return new JS("this");
}
function AnyType(){
	Types.Procedure.call(this, "any type");
	this.asVar = new TypeId.Type(this);
}
function AnyField(id/*STRING*/){
	Types.Field.call(this);
	this.mId = id;
}
doProcId = "do$";
varTypeId = "var$";
any = new AnyType();
doProcSymbol = makeDoProcSymbol();
varTypeSymbol = makeVarTypeSymbol();
exports.Type = Type;
exports.AnyType = AnyType;
exports.AnyTypeProc = AnyTypeProc;
exports.makeJS = makeJS;
