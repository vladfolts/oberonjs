var RTL$ = require("eberon/eberon_rtl.js");
var ContextExpression = require("js/ContextExpression.js");
var ContextHierarchy = require("js/ContextHierarchy.js");
var EberonContextDesignator = require("js/EberonContextDesignator.js");
var EberonContextProcedure = require("js/EberonContextProcedure.js");
var EberonTypePromotion = require("js/EberonTypePromotion.js");
var Object$ = require("js/Object$.js");
function Term(){
	ContextExpression.Term.apply(this, arguments);
	this.typePromotion = null;
	this.currentPromotion = null;
	this.andHandled = false;
}
RTL$.extend(Term, ContextExpression.Term);
function Factor(){
	ContextExpression.Factor.apply(this, arguments);
}
RTL$.extend(Factor, ContextExpression.Factor);
function BeginTypePromotionAndMsg(){
	ContextHierarchy.Message.call(this);
	this.result = null;
}
RTL$.extend(BeginTypePromotionAndMsg, ContextHierarchy.Message);
function CurrentTypePromotionMsg(){
	ContextHierarchy.Message.call(this);
	this.result = null;
}
RTL$.extend(CurrentTypePromotionMsg, ContextHierarchy.Message);
Term.prototype.handleMessage = function(msg/*VAR Message*/){
	var result = null;
	if (msg instanceof EberonContextDesignator.PromoteTypeMsg){
		var promoted = msg.info;
		var p = this.getCurrentPromotion();
		if (p != null){
			p.promote(promoted, msg.type);
		}
	}
	else if (msg instanceof EberonContextProcedure.BeginTypePromotionOrMsg){
		var p = this.getCurrentPromotion();
		if (p != null){
			msg.result = p.makeOr();
		}
	}
	else if (msg instanceof CurrentTypePromotionMsg){
		msg.result = this.getCurrentPromotion();
	}
	else {
		result = ContextExpression.Term.prototype.handleMessage.call(this, msg);
	}
	return result;
};
Term.prototype.handleLogicalAnd = function(){
	if (this.typePromotion != null){
		this.currentPromotion = this.typePromotion.next();
	}
	else {
		this.andHandled = true;
	}
};
Term.prototype.getCurrentPromotion = function(){
	if (this.currentPromotion == null){
		var msg = new BeginTypePromotionAndMsg();
		var void$ = this.parent().handleMessage(msg);
		this.typePromotion = msg.result;
		if (this.typePromotion != null){
			if (this.andHandled){
				var unused = this.typePromotion.next();
			}
			this.currentPromotion = this.typePromotion.next();
		}
	}
	return this.currentPromotion;
};
Factor.prototype.handleLogicalNot = function(){
	ContextExpression.Factor.prototype.handleLogicalNot.call(this);
	var msg = new CurrentTypePromotionMsg();
	var void$ = this.handleMessage(msg);
	var p = msg.result;
	if (p != null){
		p.invert();
	}
};
exports.Term = Term;
exports.Factor = Factor;
exports.BeginTypePromotionAndMsg = BeginTypePromotionAndMsg;
