var RTL$ = require("eberon/eberon_rtl.js");
var Context = require("js/Context.js");
var ContextExpression = require("js/ContextExpression.js");
var ContextHierarchy = require("js/ContextHierarchy.js");
var EberonContextDesignator = require("js/EberonContextDesignator.js");
var EberonContextProcedure = require("js/EberonContextProcedure.js");
var EberonMap = require("js/EberonMap.js");
var EberonOperator = require("js/EberonOperator.js");
var EberonString = require("js/EberonString.js");
var EberonTypePromotion = require("js/EberonTypePromotion.js");
var Expression = require("js/Expression.js");
var LanguageContext = require("js/LanguageContext.js");
var JS = GLOBAL;
var Object$ = require("js/Object$.js");
var Types = require("js/Types.js");
var $scope = "EberonContextExpression";
RTL$.extend(ExpressionNode, ContextExpression.ExpressionNode, $scope);
RTL$.extend(SimpleExpression, ContextExpression.SimpleExpression, $scope);
function Term(){
	ContextExpression.Term.apply(this, arguments);
	this.typePromotion = null;
	this.currentPromotion = null;
	this.andHandled = false;
}
RTL$.extend(Term, ContextExpression.Term, $scope);
function Factor(){
	ContextExpression.Factor.apply(this, arguments);
}
RTL$.extend(Factor, ContextExpression.Factor, $scope);
function AddOperator(){
	ContextExpression.AddOperator.apply(this, arguments);
}
RTL$.extend(AddOperator, ContextExpression.AddOperator, $scope);
function MulOperator(){
	ContextExpression.MulOperator.apply(this, arguments);
}
RTL$.extend(MulOperator, ContextExpression.MulOperator, $scope);
function RelationOps(){
	ContextExpression.RelationOps.call(this);
}
RTL$.extend(RelationOps, ContextExpression.RelationOps, $scope);
function BeginTypePromotionAndMsg(){
	ContextHierarchy.Message.call(this);
	this.result = null;
}
RTL$.extend(BeginTypePromotionAndMsg, ContextHierarchy.Message, $scope);
function CurrentTypePromotionMsg(){
	ContextHierarchy.Message.call(this);
	this.result = null;
}
RTL$.extend(CurrentTypePromotionMsg, ContextHierarchy.Message, $scope);
var relationOps = null;
function ExpressionNode(parent/*PExpressionHandler*/){
	ContextExpression.ExpressionNode.call(this, parent, relationOps);
	this.currentTypePromotion = null;
}
ExpressionNode.prototype.handleMessage = function(msg/*VAR Message*/){
	var result = null;
	if (msg instanceof EberonContextDesignator.TransferPromotedTypesMsg){
	}
	else {
		result = ContextExpression.ExpressionNode.prototype.handleMessage.call(this, msg);
	}
	return result;
};
ExpressionNode.prototype.handleTypePromotion = function(promotion/*PCombined*/){
	this.currentTypePromotion = promotion;
};
ExpressionNode.prototype.handleLiteral = function(s/*STRING*/){
	if (this.currentTypePromotion != null){
		this.currentTypePromotion.clear();
	}
	ContextExpression.ExpressionNode.prototype.handleLiteral.call(this, s);
};
ExpressionNode.prototype.doRelationOperation = function(left/*PType*/, right/*PType*/, relation/*STRING*/){
	var result = null;
	if (relation == "IN" && right.type() instanceof EberonMap.Type){
		EberonContextDesignator.checkMapKeyType(left.type());
		result = EberonOperator.inMap;
	}
	else {
		result = ContextExpression.ExpressionNode.prototype.doRelationOperation.call(this, left, right, relation);
	}
	return result;
};
ExpressionNode.prototype.endParse = function(){
	if (this.currentTypePromotion != null){
		var void$ = this.parent().handleMessage(new EberonContextDesignator.TransferPromotedTypesMsg(this.currentTypePromotion));
	}
	return ContextExpression.ExpressionNode.prototype.endParse.call(this);
};
function SimpleExpression(parent/*PExpressionNode*/){
	ContextExpression.SimpleExpression.call(this, parent);
	this.parentExppression = parent;
	this.typePromotion = null;
	this.currentPromotion = null;
	this.orHandled = false;
}
SimpleExpression.prototype.handleLogicalOr = function(){
	if (this.typePromotion != null){
		this.currentPromotion = this.typePromotion.next();
	}
	else {
		this.orHandled = true;
	}
};

function getCurrentPromotion(e/*VAR SimpleExpression*/){
	if (e.currentPromotion == null){
		var msg = new EberonContextProcedure.BeginTypePromotionOrMsg();
		var void$ = e.parent().handleMessage(msg);
		e.typePromotion = msg.result;
		if (e.typePromotion != null){
			if (e.orHandled){
				var unused = e.typePromotion.next();
			}
			e.currentPromotion = e.typePromotion.next();
		}
	}
	return e.currentPromotion;
}
SimpleExpression.prototype.handleMessage = function(msg/*VAR Message*/){
	var result = null;
	if (msg instanceof BeginTypePromotionAndMsg){
		var p = getCurrentPromotion(this);
		if (p != null){
			msg.result = p.makeAnd();
		}
	}
	else {
		result = ContextExpression.SimpleExpression.prototype.handleMessage.call(this, msg);
	}
	return result;
};
SimpleExpression.prototype.endParse = function(){
	if (this.typePromotion != null){
		this.parentExppression.handleTypePromotion(this.typePromotion);
	}
	return ContextExpression.SimpleExpression.prototype.endParse.call(this);
};
Term.prototype.handleMessage = function(msg/*VAR Message*/){
	var result = null;
	if (msg instanceof EberonContextDesignator.PromoteTypeMsg){
		var promoted = msg.info;
		var p = this.getCurrentPromotion();
		if (p != null){
			p.promote(promoted, msg.type);
		}
	}
	else if (msg instanceof EberonContextProcedure.BeginTypePromotionOrMsg){
		var p = this.getCurrentPromotion();
		if (p != null){
			msg.result = p.makeOr();
		}
	}
	else if (msg instanceof CurrentTypePromotionMsg){
		msg.result = this.getCurrentPromotion();
	}
	else {
		result = ContextExpression.Term.prototype.handleMessage.call(this, msg);
	}
	return result;
};
Term.prototype.handleLogicalAnd = function(){
	if (this.typePromotion != null){
		this.currentPromotion = this.typePromotion.next();
	}
	else {
		this.andHandled = true;
	}
};
Term.prototype.getCurrentPromotion = function(){
	if (this.currentPromotion == null){
		var msg = new BeginTypePromotionAndMsg();
		var void$ = this.parent().handleMessage(msg);
		this.typePromotion = msg.result;
		if (this.typePromotion != null){
			if (this.andHandled){
				var unused = this.typePromotion.next();
			}
			this.currentPromotion = this.typePromotion.next();
		}
	}
	return this.currentPromotion;
};
Factor.prototype.handleLogicalNot = function(){
	ContextExpression.Factor.prototype.handleLogicalNot.call(this);
	var msg = new CurrentTypePromotionMsg();
	var void$ = this.handleMessage(msg);
	var p = msg.result;
	if (p != null){
		p.invert();
	}
};
AddOperator.prototype.doMatchPlusOperator = function(type/*PType*/){
	var result = null;
	if (type == EberonString.string() || type instanceof Types.String){
		result = EberonOperator.addStr;
	}
	else {
		result = ContextExpression.AddOperator.prototype.doMatchPlusOperator.call(this, type);
	}
	return result;
};
AddOperator.prototype.doExpectPlusOperator = function(){
	return "numeric type or SET or STRING";
};
AddOperator.prototype.endParse = function(){
	RTL$.typeGuard(this.parent(), SimpleExpression).handleLogicalOr();
	return true;
};
MulOperator.prototype.endParse = function(){
	RTL$.typeGuard(this.parent(), Term).handleLogicalAnd();
	return true;
};
RelationOps.prototype.eq = function(type/*PType*/){
	var result = null;
	if (type == EberonString.string()){
		result = EberonOperator.equalStr;
	}
	else {
		result = ContextExpression.RelationOps.prototype.eq.call(this, type);
	}
	return result;
};
RelationOps.prototype.notEq = function(type/*PType*/){
	var result = null;
	if (type == EberonString.string()){
		result = EberonOperator.notEqualStr;
	}
	else {
		result = ContextExpression.RelationOps.prototype.notEq.call(this, type);
	}
	return result;
};
RelationOps.prototype.less = function(type/*PType*/){
	var result = null;
	if (type == EberonString.string()){
		result = EberonOperator.lessStr;
	}
	else {
		result = ContextExpression.RelationOps.prototype.less.call(this, type);
	}
	return result;
};
RelationOps.prototype.greater = function(type/*PType*/){
	var result = null;
	if (type == EberonString.string()){
		result = EberonOperator.greaterStr;
	}
	else {
		result = ContextExpression.RelationOps.prototype.greater.call(this, type);
	}
	return result;
};
RelationOps.prototype.lessEq = function(type/*PType*/){
	var result = null;
	if (type == EberonString.string()){
		result = EberonOperator.lessEqualStr;
	}
	else {
		result = ContextExpression.RelationOps.prototype.lessEq.call(this, type);
	}
	return result;
};
RelationOps.prototype.greaterEq = function(type/*PType*/){
	var result = null;
	if (type == EberonString.string()){
		result = EberonOperator.greaterEqualStr;
	}
	else {
		result = ContextExpression.RelationOps.prototype.greaterEq.call(this, type);
	}
	return result;
};
RelationOps.prototype.is = function(cx/*Node*/){
	var impl = null;
	var r = null;
	
	function is(left/*PType*/, right/*PType*/, lcx/*PType*/){
		var d = left.designator();
		if (d != null){
			var v = d.info();
			if (v instanceof EberonTypePromotion.Variable){
				var void$ = cx.handleMessage(new EberonContextDesignator.PromoteTypeMsg(v, ContextExpression.unwrapType(right.designator().info())));
			}
		}
		return impl(left, right, lcx);
	}
	impl = ContextExpression.RelationOps.prototype.is.call(this, cx);
	r = is;
	return r;
};
RelationOps.prototype.coalesceType = function(leftType/*PType*/, rightType/*PType*/){
	var result = null;
	if (leftType == EberonString.string() && rightType instanceof Types.String || rightType == EberonString.string() && leftType instanceof Types.String){
		result = EberonString.string();
	}
	else {
		result = ContextExpression.RelationOps.prototype.coalesceType.call(this, leftType, rightType);
	}
	return result;
};
relationOps = new RelationOps();
exports.ExpressionNode = ExpressionNode;
exports.SimpleExpression = SimpleExpression;
exports.Term = Term;
exports.Factor = Factor;
exports.AddOperator = AddOperator;
exports.MulOperator = MulOperator;
