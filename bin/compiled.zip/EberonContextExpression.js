var RTL$ = require("eberon/eberon_rtl.js");
var Cast = require("js/Cast.js");
var Context = require("js/Context.js");
var ContextExpression = require("js/ContextExpression.js");
var ContextHierarchy = require("js/ContextHierarchy.js");
var EberonContextDesignator = require("js/EberonContextDesignator.js");
var EberonContextProcedure = require("js/EberonContextProcedure.js");
var EberonMap = require("js/EberonMap.js");
var EberonOperator = require("js/EberonOperator.js");
var EberonString = require("js/EberonString.js");
var EberonTypePromotion = require("js/EberonTypePromotion.js");
var Errors = require("js/Errors.js");
var Expression = require("js/Expression.js");
var LanguageContext = require("js/LanguageContext.js");
var JS = GLOBAL;
var Object$ = require("js/Object$.js");
var Record = require("js/Record.js");
var Types = require("js/Types.js");
var $scope = "EberonContextExpression";
function ExpressionNode(){
	ContextExpression.ExpressionHandler.apply(this, arguments);
	this.condition = null;
	this.first = null;
	this.second = null;
}
RTL$.extend(ExpressionNode, ContextExpression.ExpressionHandler, $scope);
RTL$.extend(RelationExpression, ContextExpression.ExpressionNode, $scope);
function SimpleExpression(){
	ContextExpression.SimpleExpression.apply(this, arguments);
	this.typePromotion = null;
	this.currentPromotion = null;
	this.orHandled = false;
}
RTL$.extend(SimpleExpression, ContextExpression.SimpleExpression, $scope);
function Term(){
	ContextExpression.Term.apply(this, arguments);
	this.typePromotion = null;
	this.currentPromotion = null;
	this.andHandled = false;
}
RTL$.extend(Term, ContextExpression.Term, $scope);
function Factor(){
	ContextExpression.Factor.apply(this, arguments);
}
RTL$.extend(Factor, ContextExpression.Factor, $scope);
function AddOperator(){
	ContextExpression.AddOperator.apply(this, arguments);
}
RTL$.extend(AddOperator, ContextExpression.AddOperator, $scope);
function MulOperator(){
	ContextExpression.MulOperator.apply(this, arguments);
}
RTL$.extend(MulOperator, ContextExpression.MulOperator, $scope);
function RelationOps(){
	ContextExpression.RelationOps.call(this);
}
RTL$.extend(RelationOps, ContextExpression.RelationOps, $scope);
function BeginTypePromotionAndMsg(){
	ContextHierarchy.Message.call(this);
	this.result = null;
}
RTL$.extend(BeginTypePromotionAndMsg, ContextHierarchy.Message, $scope);
function CurrentTypePromotionMsg(){
	ContextHierarchy.Message.call(this);
	this.result = null;
}
RTL$.extend(CurrentTypePromotionMsg, ContextHierarchy.Message, $scope);
var relationOps = null;

function hierarchyDepth(t/*Type*/){
	var result = 0;
	var base = t.base;
	while (true){
		if (base != null){
			++result;
			base = base.base;
		} else break;
	}
	return result;
}

function getNthBase(t/*PType*/, n/*INTEGER*/){
	var result = t;
	var i = n;
	while (true){
		if (i != 0){
			result = result.base;
			--i;
		} else break;
	}
	return result;
}

function findCommonBase(t1/*PType*/, t2/*PType*/){
	var result = null;
	var depth1 = hierarchyDepth(t1);
	var depth2 = hierarchyDepth(t2);
	var commonBase1 = t1;
	var commonBase2 = t2;
	if (depth1 > depth2){
		commonBase1 = getNthBase(commonBase1, depth1 - depth2 | 0);
	}
	else {
		commonBase2 = getNthBase(commonBase2, depth2 - depth1 | 0);
	}
	while (true){
		if (commonBase1 != commonBase2){
			commonBase1 = commonBase1.base;
			commonBase2 = commonBase2.base;
		} else break;
	}
	return commonBase1;
}
ExpressionNode.prototype.handleExpression = function(e/*PType*/){
	if (this.condition == null){
		this.condition = e;
	}
	else if (this.first == null){
		this.first = e;
	}
	else {
		this.second = e;
	}
};
ExpressionNode.prototype.endParse = function(){
	var resultType = null;
	var op = null;
	var result = this.first;
	if (result == null){
		result = this.condition;
	}
	else {
		var firstType = this.first.type();
		var secondType = this.second.type();
		if (firstType instanceof Record.Type && secondType instanceof Record.Type){
			resultType = findCommonBase(firstType, secondType);
		}
		else if (firstType instanceof Record.Pointer && secondType instanceof Record.Pointer){
			resultType = findCommonBase(Record.pointerBase(firstType), Record.pointerBase(secondType));
		}
		if (resultType == null){
			if (this.root().language().types.implicitCast(firstType, secondType, false, {set: function($v){op = $v;}, get: function(){return op;}}) != Cast.errNo){
				Errors.raise("incompatible types in ternary operator: '" + firstType.description() + "' and '" + secondType.description() + "'");
			}
			resultType = firstType;
		}
		result = Expression.makeSimple(this.condition.code() + " ? " + this.first.code() + " : " + this.second.code(), resultType);
	}
	RTL$.typeGuard(this.parent(), ContextExpression.ExpressionHandler).handleExpression(result);
	return true;
};
function RelationExpression(parent/*PExpressionHandler*/){
	ContextExpression.ExpressionNode.call(this, parent, relationOps);
	this.currentTypePromotion = null;
}
RelationExpression.prototype.handleMessage = function(msg/*VAR Message*/){
	var result = null;
	if (msg instanceof EberonContextDesignator.TransferPromotedTypesMsg){
	}
	else {
		result = ContextExpression.ExpressionNode.prototype.handleMessage.call(this, msg);
	}
	return result;
};
RelationExpression.prototype.handleTypePromotion = function(promotion/*PCombined*/){
	this.currentTypePromotion = promotion;
};
RelationExpression.prototype.handleLiteral = function(s/*STRING*/){
	if (this.currentTypePromotion != null){
		this.currentTypePromotion.clear();
	}
	ContextExpression.ExpressionNode.prototype.handleLiteral.call(this, s);
};
RelationOps.prototype.in$ = function(left/*PType*/, right/*PType*/, cx/*Node*/){
	var result = null;
	if (right instanceof EberonMap.Type){
		EberonContextDesignator.checkMapKeyType(left);
		result = EberonOperator.inMap;
	}
	else {
		result = ContextExpression.RelationOps.prototype.in$.call(this, left, right, cx);
	}
	return result;
};
RelationExpression.prototype.endParse = function(){
	if (this.currentTypePromotion != null){
		var void$ = this.parent().handleMessage(new EberonContextDesignator.TransferPromotedTypesMsg(this.currentTypePromotion));
	}
	return ContextExpression.ExpressionNode.prototype.endParse.call(this);
};
SimpleExpression.prototype.handleLogicalOr = function(){
	if (this.typePromotion != null){
		this.currentPromotion = this.typePromotion.next();
	}
	else {
		this.orHandled = true;
	}
};

function setSimpleExpressionTypePromotion(e/*VAR SimpleExpression*/){
	if (e.currentPromotion == null){
		var msg = new EberonContextProcedure.BeginTypePromotionOrMsg();
		var void$ = e.parent().handleMessage(msg);
		e.typePromotion = msg.result;
		if (e.typePromotion != null){
			if (e.orHandled){
				var unused = e.typePromotion.next();
			}
			e.currentPromotion = e.typePromotion.next();
		}
	}
	return e.currentPromotion;
}
SimpleExpression.prototype.handleMessage = function(msg/*VAR Message*/){
	var result = null;
	if (msg instanceof BeginTypePromotionAndMsg){
		var p = setSimpleExpressionTypePromotion(this);
		if (p != null){
			msg.result = p.makeAnd();
		}
	}
	else {
		result = ContextExpression.SimpleExpression.prototype.handleMessage.call(this, msg);
	}
	return result;
};
SimpleExpression.prototype.endParse = function(){
	if (this.typePromotion != null){
		RTL$.typeGuard(this.parent(), RelationExpression).handleTypePromotion(this.typePromotion);
	}
	return ContextExpression.SimpleExpression.prototype.endParse.call(this);
};

function setTermTypePromotion(term/*VAR Term*/){
	if (term.currentPromotion == null){
		var msg = new BeginTypePromotionAndMsg();
		var void$ = term.parent().handleMessage(msg);
		term.typePromotion = msg.result;
		if (term.typePromotion != null){
			if (term.andHandled){
				var unused = term.typePromotion.next();
			}
			term.currentPromotion = term.typePromotion.next();
		}
	}
	return term.currentPromotion;
}
Term.prototype.handleMessage = function(msg/*VAR Message*/){
	var result = null;
	if (msg instanceof EberonContextDesignator.PromoteTypeMsg){
		var promoted = msg.info;
		var p = setTermTypePromotion(this);
		if (p != null){
			p.promote(promoted, msg.type);
		}
	}
	else if (msg instanceof EberonContextProcedure.BeginTypePromotionOrMsg){
		var p = setTermTypePromotion(this);
		if (p != null){
			msg.result = p.makeOr();
		}
	}
	else if (msg instanceof CurrentTypePromotionMsg){
		msg.result = setTermTypePromotion(this);
	}
	else {
		result = ContextExpression.Term.prototype.handleMessage.call(this, msg);
	}
	return result;
};
Term.prototype.handleLogicalAnd = function(){
	if (this.typePromotion != null){
		this.currentPromotion = this.typePromotion.next();
	}
	else {
		this.andHandled = true;
	}
};
Factor.prototype.handleLogicalNot = function(){
	ContextExpression.Factor.prototype.handleLogicalNot.call(this);
	var msg = new CurrentTypePromotionMsg();
	var void$ = this.handleMessage(msg);
	var p = msg.result;
	if (p != null){
		p.invert();
	}
};
AddOperator.prototype.doMatchPlusOperator = function(type/*PType*/){
	var result = null;
	if (type == EberonString.string() || type instanceof Types.String){
		result = EberonOperator.addStr;
	}
	else {
		result = ContextExpression.AddOperator.prototype.doMatchPlusOperator.call(this, type);
	}
	return result;
};
AddOperator.prototype.doExpectPlusOperator = function(){
	return "numeric type or SET or STRING";
};
AddOperator.prototype.endParse = function(){
	RTL$.typeGuard(this.parent(), SimpleExpression).handleLogicalOr();
	return true;
};
MulOperator.prototype.endParse = function(){
	RTL$.typeGuard(this.parent(), Term).handleLogicalAnd();
	return true;
};
RelationOps.prototype.eq = function(type/*PType*/){
	var result = null;
	if (type == EberonString.string()){
		result = EberonOperator.equalStr;
	}
	else {
		result = ContextExpression.RelationOps.prototype.eq.call(this, type);
	}
	return result;
};
RelationOps.prototype.notEq = function(type/*PType*/){
	var result = null;
	if (type == EberonString.string()){
		result = EberonOperator.notEqualStr;
	}
	else {
		result = ContextExpression.RelationOps.prototype.notEq.call(this, type);
	}
	return result;
};
RelationOps.prototype.less = function(type/*PType*/){
	var result = null;
	if (type == EberonString.string()){
		result = EberonOperator.lessStr;
	}
	else {
		result = ContextExpression.RelationOps.prototype.less.call(this, type);
	}
	return result;
};
RelationOps.prototype.greater = function(type/*PType*/){
	var result = null;
	if (type == EberonString.string()){
		result = EberonOperator.greaterStr;
	}
	else {
		result = ContextExpression.RelationOps.prototype.greater.call(this, type);
	}
	return result;
};
RelationOps.prototype.lessEq = function(type/*PType*/){
	var result = null;
	if (type == EberonString.string()){
		result = EberonOperator.lessEqualStr;
	}
	else {
		result = ContextExpression.RelationOps.prototype.lessEq.call(this, type);
	}
	return result;
};
RelationOps.prototype.greaterEq = function(type/*PType*/){
	var result = null;
	if (type == EberonString.string()){
		result = EberonOperator.greaterEqualStr;
	}
	else {
		result = ContextExpression.RelationOps.prototype.greaterEq.call(this, type);
	}
	return result;
};
RelationOps.prototype.is = function(cx/*Node*/){
	var impl = null;
	var r = null;
	
	function is(left/*PType*/, right/*PType*/, lcx/*PType*/){
		var d = left.designator();
		if (d != null){
			var v = d.info();
			if (v instanceof EberonTypePromotion.Variable){
				var msg = new EberonContextDesignator.PromoteTypeMsg(v, ContextExpression.unwrapType(right.designator().info()));
				var void$ = cx.handleMessage(msg);
			}
		}
		return impl(left, right, lcx);
	}
	impl = ContextExpression.RelationOps.prototype.is.call(this, cx);
	r = is;
	return r;
};
RelationOps.prototype.coalesceType = function(leftType/*PType*/, rightType/*PType*/){
	var result = null;
	if (leftType == EberonString.string() && rightType instanceof Types.String || rightType == EberonString.string() && leftType instanceof Types.String){
		result = EberonString.string();
	}
	else {
		result = ContextExpression.RelationOps.prototype.coalesceType.call(this, leftType, rightType);
	}
	return result;
};
relationOps = new RelationOps();
exports.ExpressionNode = ExpressionNode;
exports.RelationExpression = RelationExpression;
exports.SimpleExpression = SimpleExpression;
exports.Term = Term;
exports.Factor = Factor;
exports.AddOperator = AddOperator;
exports.MulOperator = MulOperator;
