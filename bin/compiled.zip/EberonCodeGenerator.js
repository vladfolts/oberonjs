var RTL$ = require("rtl.js");
var CodeGenerator = require("js/CodeGenerator.js");
var String = require("js/String.js");
function IGenerator(){
	CodeGenerator.IGenerator.call(this);
}
RTL$.extend(IGenerator, CodeGenerator.IGenerator);
function NullGenerator(){
	IGenerator.call(this);
}
RTL$.extend(NullGenerator, IGenerator);
function Insertion(){
	this.pos = 0;
	this.indent = 0;
	this.code = '';
}
function Generator(){
	IGenerator.call(this);
	this.$indent = new CodeGenerator.Indent();
	this.$insertions = [];
}
RTL$.extend(Generator, IGenerator);
var nullGenerator = new NullGenerator();
NullGenerator.prototype.write = function(s/*STRING*/){
}
NullGenerator.prototype.openScope = function(){
}
NullGenerator.prototype.closeScope = function(ending/*STRING*/){
}
NullGenerator.prototype.result = function(){
	return "";
}
NullGenerator.prototype.makeInsertion = function(){
	return 0;
}
NullGenerator.prototype.insert = function(insertion/*INTEGER*/, code/*STRING*/){
}
Generator.prototype.makeInsertion = function(){
	var insertion = new Insertion();
	insertion.pos = this.$indent.result.length;
	insertion.indent = this.$indent.indent;
	var result = this.$insertions.length;
	this.$insertions.push(RTL$.cloneRecord(insertion));
	return result;
}
Generator.prototype.insert = function(insertion/*INTEGER*/, code/*STRING*/){
	this.$insertions[insertion].code = code;
}
Generator.prototype.write = function(s/*STRING*/){
	CodeGenerator.addIndentedText(s, this.$indent);
}
Generator.prototype.openScope = function(){
	CodeGenerator.openScope(this.$indent);
}
Generator.prototype.closeScope = function(ending/*STRING*/){
	CodeGenerator.closeScope(ending, this.$indent);
}
Generator.prototype.result = function(){
	var result = '';
	var pos = 0;
	for (var i = 0; i <= this.$insertions.length - 1 | 0; ++i){
		var nextPos = this.$insertions[i].pos;
		result = result + String.substr(this.$indent.result, pos, nextPos - pos | 0) + CodeGenerator.indentText(this.$insertions[i].code, this.$insertions[i].indent);
		pos = nextPos;
	}
	result = result + String.substr(this.$indent.result, pos, this.$indent.result.length - pos | 0);
	return result;
}

function makeGenerator(){
	var result = null;
	result = new Generator();
	return result;
}
exports.nullGenerator = function(){return nullGenerator;};
exports.makeGenerator = makeGenerator;
