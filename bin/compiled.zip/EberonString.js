var Types = require("js/Types.js");
var string = null;
string = Types.makeBasic("STRING", "''");
exports.string = function(){return string;};
