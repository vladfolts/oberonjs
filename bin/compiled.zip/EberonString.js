var Types = require("js/Types.js");
var ElementVariable = Types.Variable.extend({
	init: function ElementVariable(){
		Types.Variable.prototype.init.call(this);
	}
});
var string = null;
ElementVariable.prototype.idType = function(){
	return "string element";
}
ElementVariable.prototype.isReadOnly = function(){
	return true;
}
ElementVariable.prototype.type = function(){
	return Types.basic().ch;
}
ElementVariable.prototype.isReference = function(){
	return false;
}

function makeElementVariable(){
	var result = null;
	result = new ElementVariable();
	return result;
}
string = Types.makeBasic("STRING", "''");
exports.string = function(){return string;};
exports.makeElementVariable = makeElementVariable;
