var RTL$ = require("eberon/eberon_rtl.js");
var Chars = require("js/Chars.js");
var CodeGenerator = require("js/CodeGenerator.js");
var ConstValue = require("js/ConstValue.js");
var Context = require("js/Context.js");
var ContextExpression = require("js/ContextExpression.js");
var ContextHierarchy = require("js/ContextHierarchy.js");
var Errors = require("js/Errors.js");
var Expression = require("js/Expression.js");
var R = require("js/Record.js");
var ScopeBase = require("js/ScopeBase.js");
var String = require("js/String.js");
var Types = require("js/Types.js");
function HandleSymbolAsType(){
	ContextHierarchy.Node.apply(this, arguments);
}
RTL$.extend(HandleSymbolAsType, ContextHierarchy.Node);
RTL$.extend(FormalType, HandleSymbolAsType);
RTL$.extend(Array, HandleSymbolAsType);
function ArrayDimensions(){
	ContextExpression.ExpressionHandler.apply(this, arguments);
	this.dimensions = [];
}
RTL$.extend(ArrayDimensions, ContextExpression.ExpressionHandler);
function Declaration(){
	HandleSymbolAsType.apply(this, arguments);
}
RTL$.extend(Declaration, HandleSymbolAsType);
RTL$.extend(Record, ContextHierarchy.Node);
function FieldList(){
	Declaration.apply(this, arguments);
	this.idents = [];
	this.type = null;
}
RTL$.extend(FieldList, Declaration);
HandleSymbolAsType.prototype.handleQIdent = function(q/*QIdent*/){
	var s = ContextHierarchy.getQIdSymbolAndScope(this.root(), q);
	this.setType(ContextExpression.unwrapType(s.symbol().info()));
};
function FormalType(parent/*PHandleSymbolAsType*/){
	HandleSymbolAsType.call(this, parent);
	this.handleType = parent;
	this.dimensionCount = 0;
}
FormalType.prototype.setType = function(type/*PStorageType*/){
	var result = type;
	var types = this.root().language().types;
	for (var i = 0; i <= this.dimensionCount - 1 | 0; ++i){
		result = types.makeOpenArray(result);
	}
	this.handleType.setType(result);
};
FormalType.prototype.handleLiteral = function(s/*STRING*/){
	if (s == "ARRAY"){
		++this.dimensionCount;
	}
};
function Array(parent/*PHandleSymbolAsType*/){
	HandleSymbolAsType.call(this, parent);
	this.handleType = parent;
	this.dimensions = null;
	this.type = null;
}
Array.prototype.setType = function(elementsType/*PStorageType*/){
	var dimensions = '';
	var arrayInit = '';
	var type = elementsType;
	for (var i = this.dimensions.dimensions.length - 1 | 0; i >= 0; i -= 1){
		if (dimensions.length != 0){
			dimensions = ", " + dimensions;
		}
		var length = this.dimensions.dimensions[i];
		dimensions = String.fromInt(length) + dimensions;
		if (i == 0){
			arrayInit = this.doMakeInit(elementsType, dimensions, length);
		}
		type = this.doMakeType(type, arrayInit, length);
	}
	this.type = type;
};
Array.prototype.isAnonymousDeclaration = function(){
	return true;
};
Array.prototype.doMakeInit = function(type/*PStorageType*/, dimensions/*STRING*/, length/*INTEGER*/){
	var result = '';
	var initializer = '';
	var rtl = this.root().language().rtl();
	if (type == Types.basic().ch){
		result = rtl.makeCharArray(dimensions);
	}
	else {
		if (type instanceof Types.Array || type instanceof Types.Record){
			initializer = "function(){return " + type.initializer(this) + ";}";
		}
		else {
			initializer = type.initializer(this);
		}
		result = rtl.makeArray(dimensions + ", " + initializer);
	}
	return result;
};
Array.prototype.doMakeType = function(elementsType/*PType*/, init/*STRING*/, length/*INTEGER*/){
	return this.root().language().types.makeStaticArray(elementsType, init, length);
};
Array.prototype.endParse = function(){
	this.handleType.setType(this.type);
};
ArrayDimensions.prototype.handleExpression = function(e/*PType*/){
	var type = e.type();
	if (type != Types.basic().integer){
		Errors.raise("'INTEGER' constant expression expected, got '" + type.description() + "'");
	}
	var value = e.constValue();
	if (value == null){
		Errors.raise("constant expression expected as ARRAY size");
	}
	var dimension = RTL$.typeGuard(value, ConstValue.Int).value;
	if (dimension <= 0){
		Errors.raise("array size must be greater than 0, got " + String.fromInt(dimension));
	}
	this.doAddDimension(dimension);
};
ArrayDimensions.prototype.doAddDimension = function(size/*INTEGER*/){
	this.dimensions.push(size);
};
ArrayDimensions.prototype.codeGenerator = function(){
	return CodeGenerator.nullGenerator();
};
ArrayDimensions.prototype.endParse = function(){
	RTL$.typeGuard(this.parent(), Array).dimensions = this;
};

function isTypeRecursive(type/*PType*/, base/*PType*/){
	var result = false;
	if (type == base){
		result = true;
	}
	else if (type instanceof R.Type){
		if (isTypeRecursive(type.base, base)){
			result = true;
		}
		else {
			var $map1 = type.fields;
			for(var name in $map1){
				var field = $map1[name];
				if (!result && isTypeRecursive(field.type(), base)){
					result = true;
				}
			}
		}
	}
	else if (type instanceof Types.Array){
		result = isTypeRecursive(type.elementsType, base);
	}
	return result;
}
function Record(parent/*PDeclaration*/, factory/*RecordTypeFactory*/){
	ContextHierarchy.Node.call(this, parent);
	this.declaration = parent;
	this.cons = '';
	this.type = null;
	var name = '';
	this.cons = parent.genTypeName();
	if (!parent.isAnonymousDeclaration()){
		name = this.cons;
	}
	this.type = factory(name, this.cons, parent.root().currentScope());
	parent.setType(this.type);
}
Record.prototype.addField = function(field/*PIdentdefInfo*/, type/*PStorageType*/){
	if (isTypeRecursive(type, this.type)){
		Errors.raise("recursive field definition: '" + field.id() + "'");
	}
	this.type.addField(this.doMakeField(field, type));
	if (field.exported()){
		this.declaration.exportField(field.id());
	}
};
Record.prototype.setBaseType = function(type/*PType*/){
	if (!(type instanceof R.Type)){
		Errors.raise("RECORD type is expected as a base type, got '" + type.description() + "'");
	}
	else {
		if (isTypeRecursive(type, this.type)){
			Errors.raise("recursive inheritance: '" + this.type.description() + "'");
		}
		this.type.setBase(type);
	}
};
Record.prototype.doMakeField = function(field/*PIdentdefInfo*/, type/*PStorageType*/){
	return new R.Field(field, type);
};

function generateFieldsInitializationCode(r/*Record*/){
	var result = '';
	var $map1 = r.type.fields;
	for(var f in $map1){
		var t = $map1[f];
		result = result + "this." + R.mangleField(f) + " = " + t.type().initializer(r) + ";" + Chars.ln;
	}
	return result;
}
Record.prototype.doGenerateConstructor = function(){
	var gen = CodeGenerator.makeGenerator();
	gen.write("function " + this.cons + "()");
	gen.openScope();
	gen.write(this.doGenerateBaseConstructorCallCode() + generateFieldsInitializationCode(this));
	gen.closeScope("");
	return gen.result();
};
Record.prototype.generateInheritance = function(){
	var result = '';
	var base = this.type.base;
	if (base != null){
		var qualifiedBase = this.qualifyScope(base.scope) + base.name;
		result = this.root().language().rtl().extend(this.cons, qualifiedBase) + ";" + Chars.ln;
	}
	return result;
};
Record.prototype.doGenerateBaseConstructorCallCode = function(){
	var result = this.qualifiedBaseConstructor();
	if (result.length != 0){
		result = result + ".call(this);" + Chars.ln;
	}
	return result;
};
Record.prototype.qualifiedBaseConstructor = function(){
	var result = '';
	var baseType = this.type.base;
	if (baseType != null){
		result = this.qualifyScope(baseType.scope) + baseType.name;
	}
	return result;
};
Record.prototype.endParse = function(){
	this.codeGenerator().write(this.doGenerateConstructor() + this.generateInheritance());
};

function checkIfFieldCanBeExported(name/*STRING*/, idents/*ARRAY OF PIdentdefInfo*/, hint/*STRING*/){
	for (var i = 0; i <= idents.length - 1 | 0; ++i){
		var id = idents[i];
		if (!id.exported()){
			Errors.raise("field '" + name + "' can be exported only if " + hint + " '" + id.id() + "' itself is exported too");
		}
	}
}
FieldList.prototype.isAnonymousDeclaration = function(){
	return true;
};
FieldList.prototype.exportField = function(name/*STRING*/){
	checkIfFieldCanBeExported(name, this.idents, "field");
};
FieldList.prototype.setType = function(type/*PStorageType*/){
	this.type = type;
};
FieldList.prototype.handleIdentdef = function(id/*PIdentdefInfo*/){
	this.idents.push(id);
};
FieldList.prototype.typeName = function(){
	return "";
};
FieldList.prototype.endParse = function(){
	var parent = RTL$.typeGuard(this.parent(), Record);
	for (var i = 0; i <= this.idents.length - 1 | 0; ++i){
		parent.addField(this.idents[i], this.type);
	}
};
exports.HandleSymbolAsType = HandleSymbolAsType;
exports.FormalType = FormalType;
exports.Array = Array;
exports.ArrayDimensions = ArrayDimensions;
exports.Record = Record;
exports.FieldList = FieldList;
exports.checkIfFieldCanBeExported = checkIfFieldCanBeExported;
