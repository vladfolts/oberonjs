var RTL$ = require("eberon/eberon_rtl.js");
var CodeGenerator = require("js/CodeGenerator.js");
var ConstValue = require("js/ConstValue.js");
var ContextExpression = require("js/ContextExpression.js");
var ContextHierarchy = require("js/ContextHierarchy.js");
var Errors = require("js/Errors.js");
var Expression = require("js/Expression.js");
var String = require("js/String.js");
var Types = require("js/Types.js");
function HandleSymbolAsType(){
	ContextHierarchy.Node.apply(this, arguments);
}
RTL$.extend(HandleSymbolAsType, ContextHierarchy.Node);
RTL$.extend(FormalType, HandleSymbolAsType);
RTL$.extend(Array, HandleSymbolAsType);
function ArrayDimensions(){
	ContextExpression.ExpressionHandler.apply(this, arguments);
	this.dimensions = [];
}
RTL$.extend(ArrayDimensions, ContextExpression.ExpressionHandler);
HandleSymbolAsType.prototype.handleQIdent = function(q/*QIdent*/){
	var s = ContextHierarchy.getQIdSymbolAndScope(this.root(), q);
	this.setType(ContextExpression.unwrapType(s.symbol().info()));
};
function FormalType(parent/*PHandleSymbolAsType*/){
	HandleSymbolAsType.call(this, parent);
	this.handleType = parent;
	this.dimensionCount = 0;
}
FormalType.prototype.setType = function(type/*PStorageType*/){
	var result = type;
	var types = this.root().language().types;
	for (var i = 0; i <= this.dimensionCount - 1 | 0; ++i){
		result = types.makeOpenArray(result);
	}
	this.handleType.setType(result);
};
FormalType.prototype.handleLiteral = function(s/*STRING*/){
	if (s == "ARRAY"){
		++this.dimensionCount;
	}
};
function Array(parent/*PHandleSymbolAsType*/){
	HandleSymbolAsType.call(this, parent);
	this.handleType = parent;
	this.dimensions = null;
	this.type = null;
}
Array.prototype.setType = function(elementsType/*PStorageType*/){
	var dimensions = '';
	var arrayInit = '';
	var type = elementsType;
	for (var i = this.dimensions.dimensions.length - 1 | 0; i >= 0; i -= 1){
		if (dimensions.length != 0){
			dimensions = ", " + dimensions;
		}
		var length = this.dimensions.dimensions[i];
		dimensions = String.fromInt(length) + dimensions;
		if (i == 0){
			arrayInit = this.doMakeInit(elementsType, dimensions, length);
		}
		type = this.doMakeType(type, arrayInit, length);
	}
	this.type = type;
};
Array.prototype.isAnonymousDeclaration = function(){
	return true;
};
Array.prototype.doMakeInit = function(type/*PStorageType*/, dimensions/*STRING*/, length/*INTEGER*/){
	var result = '';
	var initializer = '';
	var rtl = this.root().language().rtl();
	if (type == Types.basic().ch){
		result = rtl.makeCharArray(dimensions);
	}
	else {
		if (type instanceof Types.Array || type instanceof Types.Record){
			initializer = "function(){return " + type.initializer(this) + ";}";
		}
		else {
			initializer = type.initializer(this);
		}
		result = rtl.makeArray(dimensions + ", " + initializer);
	}
	return result;
};
Array.prototype.doMakeType = function(elementsType/*PType*/, init/*STRING*/, length/*INTEGER*/){
	return this.root().language().types.makeStaticArray(elementsType, init, length);
};
Array.prototype.endParse = function(){
	this.handleType.setType(this.type);
};
ArrayDimensions.prototype.handleExpression = function(e/*PType*/){
	var type = e.type();
	if (type != Types.basic().integer){
		Errors.raise("'INTEGER' constant expression expected, got '" + type.description() + "'");
	}
	var value = e.constValue();
	if (value == null){
		Errors.raise("constant expression expected as ARRAY size");
	}
	var dimension = RTL$.typeGuard(value, ConstValue.Int).value;
	if (dimension <= 0){
		Errors.raise("array size must be greater than 0, got " + String.fromInt(dimension));
	}
	this.doAddDimension(dimension);
};
ArrayDimensions.prototype.doAddDimension = function(size/*INTEGER*/){
	this.dimensions.push(size);
};
ArrayDimensions.prototype.codeGenerator = function(){
	return CodeGenerator.nullGenerator();
};
ArrayDimensions.prototype.endParse = function(){
	RTL$.typeGuard(this.parent(), Array).dimensions = this;
};
exports.HandleSymbolAsType = HandleSymbolAsType;
exports.FormalType = FormalType;
exports.Array = Array;
exports.ArrayDimensions = ArrayDimensions;
