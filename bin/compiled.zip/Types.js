var RTL$ = require("eberon/eberon_rtl.js");
var Chars = require("js/Chars.js");
var Context = require("js/Context.js");
var Errors = require("js/Errors.js");
var JS = GLOBAL;
var OberonRtl = require("js/OberonRtl.js");
var Object$ = require("js/Object$.js");
var ScopeBase = require("js/ScopeBase.js");
var Str = require("js/String.js");
function Id(){
	Object$.Type.call(this);
}
RTL$.extend(Id, Object$.Type);
function Type(){
	Object$.Type.call(this);
}
RTL$.extend(Type, Object$.Type);
RTL$.extend(TypeId, Id);
RTL$.extend(ForwardTypeId, TypeId);
RTL$.extend(LazyTypeId, TypeId);
RTL$.extend(Const, Id);
function Variable(){
	Id.call(this);
}
RTL$.extend(Variable, Id);
RTL$.extend(TypedVariable, Variable);
RTL$.extend(DeclaredVariable, TypedVariable);
RTL$.extend(ArgumentVariable, DeclaredVariable);
RTL$.extend(FieldVariable, Variable);
RTL$.extend(PropertyVariable, TypedVariable);
RTL$.extend(DerefVariable, TypedVariable);
function ExportedVariable(){
	TypedVariable.apply(this, arguments);
}
RTL$.extend(ExportedVariable, TypedVariable);
RTL$.extend(ProcedureId, Id);
RTL$.extend(String, Type);
function Field(){
	Object$.Type.call(this);
}
RTL$.extend(Field, Object$.Type);
RTL$.extend(RecordField, Field);
function StorageType(){
	Type.call(this);
}
RTL$.extend(StorageType, Type);
RTL$.extend(NamedType, StorageType);
RTL$.extend(Array, NamedType);
function OpenArray(){
	Array.apply(this, arguments);
}
RTL$.extend(OpenArray, Array);
RTL$.extend(StaticArray, Array);
RTL$.extend(Pointer, NamedType);
function Procedure(){
	NamedType.apply(this, arguments);
}
RTL$.extend(Procedure, NamedType);
RTL$.extend(ProcedureArgument, Object$.Type);
function DefinedProcedure(){
	Procedure.apply(this, arguments);
}
RTL$.extend(DefinedProcedure, Procedure);
RTL$.extend(BasicType, NamedType);
RTL$.extend(Record, NamedType);
RTL$.extend(NonExportedRecord, Record);
function Nil(){
	Type.call(this);
}
RTL$.extend(Nil, Type);
RTL$.extend(Module, Id);
function anonymous$1(){
	this.bool = null;
	this.ch = null;
	this.integer = null;
	this.uint8 = null;
	this.real = null;
	this.set = null;
}
var basic = new anonymous$1();
var numeric = [];
var nil = null;
var pGenerateTypeInfo = null;
TypeId.prototype.description = function(){
	var t = null;
	t = this.type();
	return "type " + t.description();
};
TypeId.prototype.type = function(){
	return this.mType;
};

function finalizeRecord(closure/*PType*/){
	RTL$.typeGuard(closure, Record).finalize();
}
Record.prototype.codeForNew = function(cx/*Type*/){
	return this.initializer(cx);
};
Record.prototype.finalize = function(){
	for (var i = 0; i <= this.notExported.length - 1 | 0; ++i){
		delete this.fields[this.notExported[i]];
	}
	this.notExported.splice(0, Number.MAX_VALUE);
};
Record.prototype.isScalar = function(){
	return false;
};

function recordOwnFields(r/*Record*/){
	return RTL$.clone(r.fields, {map: null}, undefined);
}
function Record(name/*STRING*/, cons/*STRING*/, scope/*PType*/){
	NamedType.call(this, name);
	this.fields = {};
	this.base = null;
	this.cons = cons;
	this.scope = scope;
	this.notExported = [];
	scope.addFinalizer(finalizeRecord, this);
}
function NonExportedRecord(cons/*STRING*/, scope/*PType*/, base/*PRecord*/){
	Record.call(this, "", cons, scope);
	this.base = base;
}
TypeId.prototype.strip = function(){
	var r = null;
	if (this.mType instanceof Record){
		r = RTL$.typeGuard(this.mType, Record);
		this.mType = new NonExportedRecord(r.cons, r.scope, r.base);
	}
	else {
		this.mType = null;
	}
};
function ForwardTypeId(resolve/*ResolveTypeCallback*/){
	TypeId.call(this, null);
	this.resolve = resolve;
}
ForwardTypeId.prototype.type = function(){
	if (this.mType == null){
		this.mType = this.resolve();
	}
	return this.mType;
};

function defineTypeId(tId/*VAR LazyTypeId*/, t/*PType*/){
	tId.mType = t;
}

function typeName(type/*NamedType*/){
	return type.name;
}
ProcedureId.prototype.idType = function(){
	return "procedure";
};
String.prototype.description = function(){
	var prefix = '';
	if (this.s.length == 1){
		prefix = "single-";
	}
	else {
		prefix = "multi-";
	}
	return prefix + "character string";
};

function stringValue(s/*String*/){
	return s.s;
}

function stringLen(s/*String*/){
	return s.s.length;
}

function stringAsChar(s/*String*/, c/*VAR CHAR*/){
	var result = false;
	result = stringLen(s) == 1;
	if (result){
		c.set(s.s.charCodeAt(0));
	}
	return result;
}
Const.prototype.idType = function(){
	return "constant";
};

function constType(c/*Const*/){
	return c.type;
}

function constValue(c/*Const*/){
	return c.value;
}
Variable.prototype.idType = function(){
	return "variable";
};
TypedVariable.prototype.type = function(){
	return this.mType;
};
DeclaredVariable.prototype.referenceCode = function(){
	var result = this.id;
	if (this.mType.isScalar()){
		result = "{set: function($v){" + result + " = $v;}, get: function(){return " + result + ";}}";
	}
	return result;
};
DeclaredVariable.prototype.isReference = function(){
	return false;
};
DeclaredVariable.prototype.isReadOnly = function(){
	return false;
};
ArgumentVariable.prototype.idType = function(){
	var result = '';
	result = "formal parameter";
	if (!this.var$){
		result = "non-VAR " + result;
	}
	return result;
};
ArgumentVariable.prototype.isReference = function(){
	return this.var$;
};
ArgumentVariable.prototype.isReadOnly = function(){
	return !this.var$ && (this.mType instanceof Array || this.mType instanceof Record);
};
ArgumentVariable.prototype.referenceCode = function(){
	var result = '';
	if (this.var$){
		result = this.id;
	}
	else {
		result = DeclaredVariable.prototype.referenceCode.call(this);
	}
	return result;
};

function mangleJSProperty(id/*STRING*/){
	var result = id;
	if (id == "constructor" || id == "prototype"){
		result = result + "$";
	}
	return result;
}

function mangleField(id/*STRING*/){
	return mangleJSProperty(id);
}
FieldVariable.prototype.idType = function(){
	var result = '';
	result = "record's field";
	if (this.readOnly){
		result = "read-only " + result;
	}
	return result;
};
FieldVariable.prototype.type = function(){
	return this.field.mType;
};
FieldVariable.prototype.referenceCode = function(){
	var result = '';
	var codeId = mangleField(this.field.mIdentdef.id());
	if (this.type().isScalar()){
		result = this.rtl.makeRef(this.leadCode, Chars.doubleQuote + codeId + Chars.doubleQuote);
	}
	else {
		result = this.leadCode + "." + codeId;
	}
	return result;
};
FieldVariable.prototype.isReference = function(){
	return false;
};
FieldVariable.prototype.isReadOnly = function(){
	return this.readOnly;
};
PropertyVariable.prototype.idType = function(){
	var result = '';
	result = "array's element";
	if (this.readOnly){
		result = "read-only " + result;
	}
	return result;
};
PropertyVariable.prototype.referenceCode = function(){
	var result = '';
	if (this.type().isScalar()){
		result = this.rtl.makeRef(this.leadCode, this.propCode);
	}
	else {
		result = this.leadCode + "[" + this.propCode + "]";
	}
	return result;
};
PropertyVariable.prototype.isReference = function(){
	return false;
};
PropertyVariable.prototype.isReadOnly = function(){
	return this.readOnly;
};
DerefVariable.prototype.referenceCode = function(){
	return this.code;
};
DerefVariable.prototype.isReference = function(){
	return true;
};
DerefVariable.prototype.isReadOnly = function(){
	return false;
};

function procedureType(p/*ProcedureId*/){
	return p.type;
}
ExportedVariable.prototype.idType = function(){
	return "imported variable";
};
ExportedVariable.prototype.isReference = function(){
	return false;
};
ExportedVariable.prototype.isReadOnly = function(){
	return true;
};
ExportedVariable.prototype.referenceCode = function(){
	return "";
};
TypeId.prototype.idType = function(){
	return "type";
};
BasicType.prototype.description = function(){
	return this.name;
};
BasicType.prototype.initializer = function(cx/*Type*/){
	return this.mInitializer;
};
BasicType.prototype.isScalar = function(){
	return true;
};
Nil.prototype.description = function(){
	return "NIL";
};

function isInt(t/*PType*/){
	return t == basic.integer || t == basic.uint8;
}

function intsDescription(){
	return "'INTEGER' or 'BYTE'";
}

function isString(t/*PType*/){
	return t instanceof Array && t.elementsType == basic.ch || t instanceof String;
}

function moduleName(m/*Module*/){
	return m.name;
}
function BasicType(name/*STRING*/, initializer/*STRING*/){
	NamedType.call(this, name);
	this.mInitializer = initializer;
}
Record.prototype.description = function(){
	var result = '';
	if (this.name.length != 0){
		result = this.name;
	}
	else {
		result = "anonymous RECORD";
	}
	return result;
};

function recordConstructor(cx/*Type*/, r/*Record*/){
	return cx.qualifyScope(r.scope) + r.cons;
}

function recordInitializer(cx/*Type*/, r/*Record*/, args/*STRING*/){
	return "new " + recordConstructor(cx, r) + "(" + args + ")";
}
Record.prototype.initializer = function(cx/*Type*/){
	return recordInitializer(cx, this, "");
};
Record.prototype.addField = function(f/*PField*/){
	if (Object.prototype.hasOwnProperty.call(this.fields, f.id())){
		Errors.raise("duplicated field: '" + f.id() + "'");
	}
	if (this.base != null && this.base.findSymbol(f.id()) != null){
		Errors.raise("base record already has field: '" + f.id() + "'");
	}
	this.fields[f.id()] = f;
	if (!f.exported()){
		this.notExported.push(f.id());
	}
};
Record.prototype.findSymbol = function(id/*STRING*/){
	var result = null;
	if (Object.prototype.hasOwnProperty.call(this.fields, id)){
		result = RTL$.getMappedValue(this.fields, id);
	}
	else if (this.base != null){
		result = this.base.findSymbol(id);
	}
	return result;
};

function existingField(r/*Record*/, id/*STRING*/, d/*NamedType*/){
	var result = r.findSymbol(id);
	if (result == null){
		Errors.raise("type '" + d.description() + "' has no '" + id + "' field");
	}
	return result;
}
Record.prototype.denote = function(id/*STRING*/, isReadObly/*BOOLEAN*/){
	return existingField(this, id, this);
};

function recordBase(r/*Record*/){
	return r.base;
}
Record.prototype.setBase = function(type/*PRecord*/){
	this.base = type;
};

function recordScope(r/*Record*/){
	return r.scope;
}

function pointerBase(p/*Pointer*/){
	var result = null;
	result = p.base.type();
	return RTL$.typeGuard(result, Record);
}
Pointer.prototype.description = function(){
	var base = null;
	var result = '';
	if (this.name.length != 0){
		result = this.name;
	}
	else {
		base = pointerBase(this);
		result = "POINTER TO " + base.description();
	}
	return result;
};
Pointer.prototype.initializer = function(cx/*Type*/){
	return "null";
};
Pointer.prototype.denote = function(id/*STRING*/, isReadObly/*BOOLEAN*/){
	var d = null;
	var base = pointerBase(this);
	if (this.name.length == 0 || base.name.length != 0){
		d = base;
	}
	else {
		d = this;
	}
	return existingField(base, id, d);
};
Pointer.prototype.isScalar = function(){
	return true;
};

function foldArrayDimensions(a/*VAR Array*/, dimToStr/*ArrayDimensionDescriptionCallback*/, sizes/*VAR STRING*/, of/*VAR STRING*/){
	var elementsType = a.elementsType;
	if (!(a instanceof OpenArray) && elementsType instanceof Array){
		foldArrayDimensions(elementsType, dimToStr, sizes, of);
		sizes.set(dimToStr(a) + ", " + sizes.get());
	}
	else {
		sizes.set(dimToStr(a));
		of.set(a.elementsType.description());
	}
}

function arrayDimensionDescription(a/*VAR Array*/){
	var result = '';
	if (a instanceof StaticArray){
		result = Str.fromInt(a.length());
	}
	return result;
}

function arrayDescription(a/*VAR Array*/, dimToStr/*ArrayDimensionDescriptionCallback*/){
	var result = '';
	var sizes = '';var of = '';
	if (a.elementsType == null){
		result = a.name;
	}
	else {
		foldArrayDimensions(a, dimToStr, {set: function($v){sizes = $v;}, get: function(){return sizes;}}, {set: function($v){of = $v;}, get: function(){return of;}});
		if (sizes.length != 0){
			sizes = " " + sizes;
		}
		result = "ARRAY" + sizes + " OF " + of;
	}
	return result;
}
Array.prototype.description = function(){
	return arrayDescription(this, arrayDimensionDescription);
};
Array.prototype.isScalar = function(){
	return false;
};
StorageType.prototype.denote = function(id/*STRING*/, isReadObly/*BOOLEAN*/){
	Errors.raise("selector '." + id + "' cannot be applied to '" + this.description() + "'");
	return null;
};
OpenArray.prototype.initializer = function(cx/*Type*/){
	return "";
};
StaticArray.prototype.initializer = function(cx/*Type*/){
	return this.mInitializer;
};

function arrayElementsType(a/*Array*/){
	return a.elementsType;
}
StaticArray.prototype.length = function(){
	return this.len;
};
Procedure.prototype.initializer = function(cx/*Type*/){
	return "null";
};
Procedure.prototype.description = function(){
	return this.name;
};
Procedure.prototype.isScalar = function(){
	return true;
};
DefinedProcedure.prototype.designatorCode = function(id/*STRING*/){
	return id;
};
ProcedureArgument.prototype.description = function(){
	var result = '';
	if (this.isVar){
		result = "VAR ";
	}
	return result + this.type.description();
};
function ProcedureArgument(type/*PType*/, isVar/*BOOLEAN*/){
	Object$.Type.call(this);
	this.type = type;
	this.isVar = isVar;
}
Module.prototype.idType = function(){
	return "MODULE";
};
function TypeId(type/*PType*/){
	Id.call(this);
	this.mType = type;
}
function LazyTypeId(){
	TypeId.call(this, null);
}
function String(s/*STRING*/){
	Type.call(this);
	this.s = s;
}
function NamedType(name/*STRING*/){
	StorageType.call(this);
	this.name = name;
}
function Array(elementsType/*PStorageType*/){
	NamedType.call(this, "");
	this.elementsType = elementsType;
}
function StaticArray(initializer/*STRING*/, elementsType/*PStorageType*/, len/*INTEGER*/){
	Array.call(this, elementsType);
	this.mInitializer = initializer;
	this.len = len;
}
function Pointer(name/*STRING*/, base/*PTypeId*/){
	NamedType.call(this, name);
	this.base = base;
}
function Const(type/*PType*/, value/*JS.var*/){
	Id.call(this);
	this.type = type;
	this.value = value;
}
function TypedVariable(type/*PStorageType*/){
	Variable.call(this);
	this.mType = type;
}
function DeclaredVariable(id/*STRING*/, type/*PStorageType*/){
	TypedVariable.call(this, type);
	this.id = id;
}
function ArgumentVariable(id/*STRING*/, type/*PStorageType*/, var$/*BOOLEAN*/){
	DeclaredVariable.call(this, id, type);
	this.var$ = var$;
}
function FieldVariable(f/*PRecordField*/, leadCode/*STRING*/, isReadOnly/*BOOLEAN*/, rtl/*PType*/){
	Variable.call(this);
	this.field = f;
	this.leadCode = leadCode;
	this.readOnly = isReadOnly;
	this.rtl = rtl;
}
function PropertyVariable(type/*PStorageType*/, leadCode/*STRING*/, propCode/*STRING*/, isReadOnly/*BOOLEAN*/, rtl/*PType*/){
	TypedVariable.call(this, type);
	this.leadCode = leadCode;
	this.propCode = propCode;
	this.readOnly = isReadOnly;
	this.rtl = rtl;
}
function DerefVariable(type/*PStorageType*/, code/*STRING*/){
	TypedVariable.call(this, type);
	this.code = code;
}

function makeExportedVariable(v/*Variable*/){
	return new ExportedVariable(v.type());
}
function ProcedureId(type/*PType*/){
	Id.call(this);
	this.type = type;
}
function Module(name/*STRING*/){
	Id.call(this);
	this.name = name;
}
function FieldCode(code/*STRING*/, derefCode/*STRING*/, propCode/*STRING*/){
	this.code = code;
	this.derefCode = derefCode;
	this.propCode = propCode;
}
RecordField.prototype.id = function(){
	return this.mIdentdef.id();
};
RecordField.prototype.exported = function(){
	return this.mIdentdef.exported();
};
RecordField.prototype.identdef = function(){
	return this.mIdentdef;
};
RecordField.prototype.designatorCode = function(leadCode/*STRING*/, cx/*Type*/){
	var codeId = mangleField(this.mIdentdef.id());
	return new FieldCode(leadCode + "." + codeId, leadCode, Chars.doubleQuote + codeId + Chars.doubleQuote);
};
RecordField.prototype.type = function(){
	return this.mType;
};
RecordField.prototype.asVar = function(leadCode/*STRING*/, isReadOnly/*BOOLEAN*/, cx/*Type*/){
	return new FieldVariable(this, leadCode, isReadOnly, cx.rtl);
};
function RecordField(identdef/*PIdentdefInfo*/, type/*PStorageType*/){
	Field.call(this);
	this.mIdentdef = identdef;
	this.mType = type;
}

function dumpRecordFields(type/*PRecord*/){
	var result = '';
	if (type.base != null){
		result = dumpRecordFields(type.base);
	}
	var $map1 = type.fields;
	for(var k in $map1){
		var v = $map1[k];
		if (result.length != 0){
			result = result + ", ";
		}
		result = result + mangleField(k) + ": " + pGenerateTypeInfo(v.type());
	}
	return result;
}

function generateTypeInfo(type/*PType*/){
	var result = '';
	if (type instanceof Record){
		result = "{record: {" + dumpRecordFields(type) + "}}";
	}
	else if (type instanceof Array){
		result = "{array: " + generateTypeInfo(type.elementsType) + "}";
	}
	else {
		result = "null";
	}
	return result;
}
basic.bool = new BasicType("BOOLEAN", "false");
basic.ch = new BasicType("CHAR", "0");
basic.integer = new BasicType("INTEGER", "0");
basic.uint8 = new BasicType("BYTE", "0");
basic.real = new BasicType("REAL", "0");
basic.set = new BasicType("SET", "0");
numeric.push(basic.integer);
numeric.push(basic.uint8);
numeric.push(basic.real);
nil = new Nil();
pGenerateTypeInfo = generateTypeInfo;
exports.Id = Id;
exports.Type = Type;
exports.TypeId = TypeId;
exports.ForwardTypeId = ForwardTypeId;
exports.LazyTypeId = LazyTypeId;
exports.Const = Const;
exports.Variable = Variable;
exports.DeclaredVariable = DeclaredVariable;
exports.ArgumentVariable = ArgumentVariable;
exports.FieldVariable = FieldVariable;
exports.PropertyVariable = PropertyVariable;
exports.DerefVariable = DerefVariable;
exports.ProcedureId = ProcedureId;
exports.String = String;
exports.FieldCode = FieldCode;
exports.Field = Field;
exports.RecordField = RecordField;
exports.StorageType = StorageType;
exports.NamedType = NamedType;
exports.Array = Array;
exports.OpenArray = OpenArray;
exports.StaticArray = StaticArray;
exports.Pointer = Pointer;
exports.Procedure = Procedure;
exports.ProcedureArgument = ProcedureArgument;
exports.DefinedProcedure = DefinedProcedure;
exports.BasicType = BasicType;
exports.Record = Record;
exports.NonExportedRecord = NonExportedRecord;
exports.Module = Module;
exports.basic = function(){return basic;};
exports.numeric = function(){return numeric;};
exports.nil = function(){return nil;};
exports.recordOwnFields = recordOwnFields;
exports.defineTypeId = defineTypeId;
exports.typeName = typeName;
exports.stringValue = stringValue;
exports.stringLen = stringLen;
exports.stringAsChar = stringAsChar;
exports.constType = constType;
exports.constValue = constValue;
exports.mangleJSProperty = mangleJSProperty;
exports.mangleField = mangleField;
exports.procedureType = procedureType;
exports.isInt = isInt;
exports.intsDescription = intsDescription;
exports.isString = isString;
exports.moduleName = moduleName;
exports.recordConstructor = recordConstructor;
exports.recordInitializer = recordInitializer;
exports.recordBase = recordBase;
exports.recordScope = recordScope;
exports.pointerBase = pointerBase;
exports.arrayDimensionDescription = arrayDimensionDescription;
exports.arrayDescription = arrayDescription;
exports.arrayElementsType = arrayElementsType;
exports.makeExportedVariable = makeExportedVariable;
exports.dumpRecordFields = dumpRecordFields;
exports.generateTypeInfo = generateTypeInfo;
