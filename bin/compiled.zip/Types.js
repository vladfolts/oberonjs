var RTL$ = require("rtl.js");
var Context = require("js/Context.js");
var Errors = require("js/Errors.js");
var JS = GLOBAL;
var JsMap = require("js/JsMap.js");
var Object = require("js/Object.js");
var ScopeBase = require("js/ScopeBase.js");
var Str = require("js/String.js");
RTL$.extend(Id, Object.Type);
function Id(){
	Object.Type.call(this);
}
RTL$.extend(Type, Object.Type);
function Type(){
	Object.Type.call(this);
}
RTL$.extend(StorageType, Type);
function StorageType(){
	Type.call(this);
}
RTL$.extend(TypeId, Id);
function TypeId(){
	Id.call(this);
	this.mType = null;
}
RTL$.extend(ForwardTypeId, TypeId);
function ForwardTypeId(){
	TypeId.call(this);
	this.resolve = null;
}
RTL$.extend(LazyTypeId, TypeId);
function LazyTypeId(){
	TypeId.call(this);
}
RTL$.extend(Const, Id);
function Const(){
	Id.call(this);
	this.type = null;
	this.value = undefined;
}
RTL$.extend(Variable, Id);
function Variable(){
	Id.call(this);
}
RTL$.extend(VariableImpl, Variable);
function VariableImpl(){
	Variable.call(this);
	this.mType = null;
	this.mRef = false;
}
RTL$.extend(ReadOnlyVariable, VariableImpl);
function ReadOnlyVariable(){
	VariableImpl.call(this);
}
RTL$.extend(ExportedVariable, ReadOnlyVariable);
function ExportedVariable(){
	ReadOnlyVariable.call(this);
}
RTL$.extend(ProcedureId, Id);
function ProcedureId(){
	Id.call(this);
	this.type = null;
}
RTL$.extend(String, Type);
function String(){
	Type.call(this);
	this.s = '';
}
RTL$.extend(Field, Object.Type);
function Field(){
	Object.Type.call(this);
}
RTL$.extend(NamedType, StorageType);
function NamedType(){
	StorageType.call(this);
	this.name = '';
}
RTL$.extend(Array, NamedType);
function Array(){
	NamedType.call(this);
	this.elementsType = null;
}
RTL$.extend(OpenArray, Array);
function OpenArray(){
	Array.call(this);
}
RTL$.extend(StaticArray, Array);
function StaticArray(){
	Array.call(this);
	this.mInitializer = '';
	this.len = 0;
}
RTL$.extend(Pointer, NamedType);
function Pointer(){
	NamedType.call(this);
	this.base = null;
}
RTL$.extend(Procedure, NamedType);
function Procedure(){
	NamedType.call(this);
}
RTL$.extend(ProcedureArgument, Object.Type);
function ProcedureArgument(){
	Object.Type.call(this);
	this.type = null;
	this.isVar = false;
}
RTL$.extend(DefinedProcedure, Procedure);
function DefinedProcedure(){
	Procedure.call(this);
}
RTL$.extend(BasicType, NamedType);
function BasicType(){
	NamedType.call(this);
	this.mInitializer = '';
}
RTL$.extend(Record, NamedType);
function Record(){
	NamedType.call(this);
	this.fields = null;
	this.base = null;
	this.cons = '';
	this.scope = null;
	this.notExported = [];
}
RTL$.extend(NonExportedRecord, Record);
function NonExportedRecord(){
	Record.call(this);
}
RTL$.extend(Nil, Type);
function Nil(){
	Type.call(this);
}
RTL$.extend(Module, Id);
function Module(){
	Id.call(this);
	this.name = '';
}
function anonymous$1(){
	this.bool = null;
	this.ch = null;
	this.integer = null;
	this.uint8 = null;
	this.real = null;
	this.set = null;
}
var basic = new anonymous$1();
var numeric = [];
var nil = null;
TypeId.prototype.description = function(){
	var t = null;
	t = this.type();
	return "type " + t.description();
}
TypeId.prototype.type = function(){
	return this.mType;
}

function finalizeRecord(closure/*PType*/){
	RTL$.typeGuard(closure, Record).finalize();
}
Record.prototype.finalize = function(){
	for (var i = 0; i <= this.notExported.length - 1 | 0; ++i){
		JsMap.erase(this.fields, this.notExported[i]);
	}
	this.notExported.splice(0, Number.MAX_VALUE);
}

function initRecord(r/*PRecord*/, name/*STRING*/, cons/*STRING*/, scope/*PType*/){
	r.name = name;
	r.cons = cons;
	r.scope = scope;
	r.fields = JsMap.make();
	scope.addFinalizer(finalizeRecord, r);
}

function makeNonExportedRecord(cons/*STRING*/, scope/*PType*/, base/*PRecord*/){
	var result = null;
	result = new NonExportedRecord();
	initRecord(result, "", cons, scope);
	result.base = base;
	return result;
}
TypeId.prototype.strip = function(){
	var r = null;
	if (this.mType instanceof Record){
		r = RTL$.typeGuard(this.mType, Record);
		this.mType = makeNonExportedRecord(r.cons, r.scope, r.base);
	}
	else {
		this.mType = null;
	}
}

function makeForwardTypeId(resolve/*ResolveTypeCallback*/){
	var result = null;
	result = new ForwardTypeId();
	result.resolve = resolve;
	return result;
}
ForwardTypeId.prototype.type = function(){
	if (this.mType == null){
		this.mType = this.resolve();
	}
	return this.mType;
}

function defineTypeId(tId/*VAR LazyTypeId*/, t/*PType*/){
	tId.mType = t;
}

function typeName(type/*NamedType*/){
	return type.name;
}
ProcedureId.prototype.idType = function(){
	return "procedure";
}
String.prototype.description = function(){
	var prefix = '';
	if (this.s.length == 1){
		prefix = "single-";
	}
	else {
		prefix = "multi-";
	}
	return prefix + "character string";
}

function stringValue(s/*String*/){
	return s.s;
}

function stringLen(s/*String*/){
	return s.s.length;
}

function stringAsChar(s/*String*/, c/*VAR CHAR*/){
	var result = false;
	result = stringLen(s) == 1;
	if (result){
		c.set(s.s.charCodeAt(0));
	}
	return result;
}
Const.prototype.idType = function(){
	return "constant";
}

function constType(c/*Const*/){
	return c.type;
}

function constValue(c/*Const*/){
	return c.value;
}
Variable.prototype.idType = function(){
	return "variable";
}
ReadOnlyVariable.prototype.idType = function(){
	return "read-only variable";
}
VariableImpl.prototype.type = function(){
	return this.mType;
}
VariableImpl.prototype.isReference = function(){
	return this.mRef;
}

function procedureType(p/*ProcedureId*/){
	return p.type;
}
Variable.prototype.isReadOnly = function(){
	return false;
}
ReadOnlyVariable.prototype.isReadOnly = function(){
	return true;
}
ExportedVariable.prototype.idType = function(){
	return "imported variable";
}
TypeId.prototype.idType = function(){
	return "type";
}
BasicType.prototype.description = function(){
	return this.name;
}
BasicType.prototype.initializer = function(cx/*Type*/, forNew/*BOOLEAN*/){
	return this.mInitializer;
}
Nil.prototype.description = function(){
	return "NIL";
}

function isInt(t/*PType*/){
	return t == basic.integer || t == basic.uint8;
}

function intsDescription(){
	return "'INTEGER' or 'BYTE'";
}

function isString(t/*PType*/){
	return t instanceof Array && t.elementsType == basic.ch || t instanceof String;
}

function moduleName(m/*Module*/){
	return m.name;
}

function makeBasic(name/*STRING*/, initializer/*STRING*/){
	var result = null;
	result = new BasicType();
	result.name = name;
	result.mInitializer = initializer;
	return result;
}
Record.prototype.description = function(){
	var result = '';
	if (this.name.length != 0){
		result = this.name;
	}
	else {
		result = "anonymous RECORD";
	}
	return result;
}
Record.prototype.initializer = function(cx/*Type*/, forNew/*BOOLEAN*/){
	return "new " + cx.qualifyScope(this.scope) + this.cons + "()";
}
Record.prototype.addField = function(f/*PField*/){
	if (JsMap.has(this.fields, f.id())){
		Errors.raise("duplicated field: '" + f.id() + "'");
	}
	if (this.base != null && this.base.findSymbol(f.id()) != null){
		Errors.raise("base record already has field: '" + f.id() + "'");
	}
	JsMap.put(this.fields, f.id(), f);
	if (!f.exported()){
		this.notExported.push(f.id());
	}
}
Record.prototype.findSymbol = function(id/*STRING*/){
	var result = null;
	if (!JsMap.find(this.fields, id, {set: function($v){result = $v;}, get: function(){return result;}}) && this.base != null){
		result = this.base.findSymbol(id);
	}
	return RTL$.typeGuard(result, Field);
}

function existingField(r/*Record*/, id/*STRING*/, d/*NamedType*/){
	var result = r.findSymbol(id);
	if (result == null){
		Errors.raise("type '" + d.description() + "' has no '" + id + "' field");
	}
	return result;
}
Record.prototype.denote = function(id/*STRING*/){
	return existingField(this, id, this);
}

function recordBase(r/*Record*/){
	return r.base;
}

function setRecordBase(r/*VAR Record*/, type/*PRecord*/){
	r.base = type;
}

function recordScope(r/*Record*/){
	return r.scope;
}

function recordConstructor(r/*Record*/){
	return r.cons;
}

function recordOwnFields(r/*Record*/){
	return r.fields;
}

function pointerBase(p/*Pointer*/){
	var result = null;
	result = p.base.type();
	return RTL$.typeGuard(result, Record);
}
Pointer.prototype.description = function(){
	var base = null;
	var result = '';
	if (this.name.length != 0){
		result = this.name;
	}
	else {
		base = pointerBase(this);
		result = "POINTER TO " + base.description();
	}
	return result;
}
Pointer.prototype.initializer = function(cx/*Type*/, forNew/*BOOLEAN*/){
	return "null";
}
Pointer.prototype.denote = function(id/*STRING*/){
	var d = null;
	var base = pointerBase(this);
	if (this.name.length == 0 || base.name.length != 0){
		d = base;
	}
	else {
		d = this;
	}
	return existingField(base, id, d);
}

function foldArrayDimensions(a/*VAR Array*/, dimToStr/*ArrayDimensionDescriptionCallback*/, sizes/*VAR STRING*/, of/*VAR STRING*/){
	var elementsType = a.elementsType;
	if (!(a instanceof OpenArray) && elementsType instanceof Array){
		foldArrayDimensions(elementsType, dimToStr, sizes, of);
		sizes.set(dimToStr(a) + ", " + sizes.get());
	}
	else {
		sizes.set(dimToStr(a));
		of.set(a.elementsType.description());
	}
}

function arrayDimensionDescription(a/*VAR Array*/){
	var result = '';
	if (a instanceof StaticArray){
		result = Str.fromInt(a.length());
	}
	return result;
}

function arrayDescription(a/*VAR Array*/, dimToStr/*ArrayDimensionDescriptionCallback*/){
	var result = '';
	var sizes = '';var of = '';
	if (a.elementsType == null){
		result = a.name;
	}
	else {
		foldArrayDimensions(a, dimToStr, {set: function($v){sizes = $v;}, get: function(){return sizes;}}, {set: function($v){of = $v;}, get: function(){return of;}});
		if (sizes.length != 0){
			sizes = " " + sizes;
		}
		result = "ARRAY" + sizes + " OF " + of;
	}
	return result;
}
Array.prototype.description = function(){
	return arrayDescription(this, arrayDimensionDescription);
}
NamedType.prototype.denote = function(id/*STRING*/){
	Errors.raise("selector '." + id + "' cannot be applied to '" + this.description() + "'");
	return null;
}
OpenArray.prototype.initializer = function(cx/*Type*/, forNew/*BOOLEAN*/){
	return "";
}
StaticArray.prototype.initializer = function(cx/*Type*/, forNew/*BOOLEAN*/){
	return this.mInitializer;
}

function arrayElementsType(a/*Array*/){
	return a.elementsType;
}

function arrayBaseElementsType(a/*Array*/){
	var result = null;
	result = a.elementsType;
	while (true){
		if (result instanceof Array){
			result = RTL$.typeGuard(result, Array).elementsType;
		} else break;
	}
	return result;
}

function isScalar(t/*VAR Type*/){
	return !(t instanceof Array) && !(t instanceof Record);
}
StaticArray.prototype.length = function(){
	return this.len;
}
Procedure.prototype.initializer = function(cx/*Type*/, forNew/*BOOLEAN*/){
	return "null";
}
Procedure.prototype.description = function(){
	return this.name;
}
DefinedProcedure.prototype.designatorCode = function(id/*STRING*/){
	return id;
}
ProcedureArgument.prototype.description = function(){
	var result = '';
	if (this.isVar){
		result = "VAR ";
	}
	return result + this.type.description();
}

function makeProcedureArgument(type/*PType*/, isVar/*BOOLEAN*/){
	var result = null;
	result = new ProcedureArgument();
	result.type = type;
	result.isVar = isVar;
	return result;
}
Module.prototype.idType = function(){
	return "MODULE";
}

function makeTypeId(type/*PType*/){
	var result = null;
	result = new TypeId();
	result.mType = type;
	return result;
}

function makeLazyTypeId(){
	var result = null;
	result = new LazyTypeId();
	return result;
}

function makeString(s/*STRING*/){
	var result = null;
	result = new String();
	result.s = s;
	return result;
}

function initArray(elementsType/*PType*/, result/*VAR Array*/){
	result.elementsType = elementsType;
}

function makeOpenArray(elementsType/*PType*/){
	var result = null;
	result = new OpenArray();
	initArray(elementsType, result);
	return result;
}

function initStaticArray(initializer/*STRING*/, elementsType/*PType*/, len/*INTEGER*/, result/*VAR StaticArray*/){
	initArray(elementsType, result);
	result.mInitializer = initializer;
	result.len = len;
}

function makeStaticArray(initializer/*STRING*/, elementsType/*PType*/, len/*INTEGER*/){
	var result = null;
	result = new StaticArray();
	initStaticArray(initializer, elementsType, len, result);
	return result;
}

function makePointer(name/*STRING*/, base/*PTypeId*/){
	var result = null;
	result = new Pointer();
	result.name = name;
	result.base = base;
	return result;
}

function makeRecord(name/*STRING*/, cons/*STRING*/, scope/*PType*/){
	var result = null;
	result = new Record();
	initRecord(result, name, cons, scope);
	return result;
}

function makeConst(type/*PType*/, value/*JS.var*/){
	var result = null;
	result = new Const();
	result.type = type;
	result.value = value;
	return result;
}

function makeVariable(type/*PType*/, readOnly/*BOOLEAN*/){
	var result = null;
	
	function make(){
		var result = null;
		result = new VariableImpl();
		return result;
	}
	
	function makeRO(){
		var result = null;
		result = new ReadOnlyVariable();
		return result;
	}
	if (readOnly){
		result = makeRO();
	}
	else {
		result = make();
	}
	result.mType = type;
	return result;
}

function makeVariableRef(type/*PType*/){
	var result = null;
	result = new VariableImpl();
	result.mType = type;
	result.mRef = true;
	return result;
}

function makeExportedVariable(v/*Variable*/){
	var result = null;
	result = new ExportedVariable();
	result.mType = v.type();
	return result;
}

function makeProcedure(type/*PType*/){
	var result = null;
	result = new ProcedureId();
	result.type = type;
	return result;
}

function initProcedure(p/*VAR Procedure*/, name/*STRING*/){
	p.name = name;
}

function initModule(m/*VAR Module*/, name/*STRING*/){
	m.name = name;
}
basic.bool = makeBasic("BOOLEAN", "false");
basic.ch = makeBasic("CHAR", "0");
basic.integer = makeBasic("INTEGER", "0");
basic.uint8 = makeBasic("BYTE", "0");
basic.real = makeBasic("REAL", "0");
basic.set = makeBasic("SET", "0");
numeric.push(basic.integer);
numeric.push(basic.uint8);
numeric.push(basic.real);
nil = new Nil();
exports.Id = Id;
exports.Type = Type;
exports.StorageType = StorageType;
exports.TypeId = TypeId;
exports.ForwardTypeId = ForwardTypeId;
exports.Const = Const;
exports.Variable = Variable;
exports.ProcedureId = ProcedureId;
exports.String = String;
exports.Field = Field;
exports.NamedType = NamedType;
exports.Array = Array;
exports.OpenArray = OpenArray;
exports.StaticArray = StaticArray;
exports.Pointer = Pointer;
exports.Procedure = Procedure;
exports.ProcedureArgument = ProcedureArgument;
exports.DefinedProcedure = DefinedProcedure;
exports.BasicType = BasicType;
exports.Record = Record;
exports.NonExportedRecord = NonExportedRecord;
exports.Module = Module;
exports.basic = function(){return basic;};
exports.numeric = function(){return numeric;};
exports.nil = function(){return nil;};
exports.initRecord = initRecord;
exports.makeForwardTypeId = makeForwardTypeId;
exports.defineTypeId = defineTypeId;
exports.typeName = typeName;
exports.stringValue = stringValue;
exports.stringLen = stringLen;
exports.stringAsChar = stringAsChar;
exports.constType = constType;
exports.constValue = constValue;
exports.procedureType = procedureType;
exports.isInt = isInt;
exports.intsDescription = intsDescription;
exports.isString = isString;
exports.moduleName = moduleName;
exports.makeBasic = makeBasic;
exports.recordBase = recordBase;
exports.setRecordBase = setRecordBase;
exports.recordScope = recordScope;
exports.recordConstructor = recordConstructor;
exports.recordOwnFields = recordOwnFields;
exports.pointerBase = pointerBase;
exports.arrayDimensionDescription = arrayDimensionDescription;
exports.arrayDescription = arrayDescription;
exports.arrayElementsType = arrayElementsType;
exports.arrayBaseElementsType = arrayBaseElementsType;
exports.isScalar = isScalar;
exports.makeProcedureArgument = makeProcedureArgument;
exports.makeTypeId = makeTypeId;
exports.makeLazyTypeId = makeLazyTypeId;
exports.makeString = makeString;
exports.initArray = initArray;
exports.makeOpenArray = makeOpenArray;
exports.initStaticArray = initStaticArray;
exports.makeStaticArray = makeStaticArray;
exports.makePointer = makePointer;
exports.makeRecord = makeRecord;
exports.makeConst = makeConst;
exports.makeVariable = makeVariable;
exports.makeVariableRef = makeVariableRef;
exports.makeExportedVariable = makeExportedVariable;
exports.makeProcedure = makeProcedure;
exports.initProcedure = initProcedure;
exports.initModule = initModule;
