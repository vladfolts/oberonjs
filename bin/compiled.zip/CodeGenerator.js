var RTL$ = require("rtl.js");
var Stream = require("js/Stream.js");
var String = require("js/String.js");
var kTab = "\t";
function IGenerator(){
}
function NullGenerator(){
	IGenerator.call(this);
}
RTL$.extend(NullGenerator, IGenerator);
function SimpleGenerator(){
	NullGenerator.call(this);
	this.mResult = '';
}
RTL$.extend(SimpleGenerator, NullGenerator);
function Insertion(){
	this.pos = 0;
	this.indent = 0;
	this.code = '';
}
function Generator(){
	SimpleGenerator.call(this);
	this.indent = 0;
	this.$insertions = [];
}
RTL$.extend(Generator, SimpleGenerator);
var nullGenerator = new NullGenerator();
NullGenerator.prototype.write = function(s/*STRING*/){
}
NullGenerator.prototype.openScope = function(){
}
NullGenerator.prototype.closeScope = function(ending/*STRING*/){
}
NullGenerator.prototype.makeInsertion = function(){
	return 0;
}
NullGenerator.prototype.insert = function(insertion/*INTEGER*/, code/*STRING*/){
}
NullGenerator.prototype.result = function(){
	return "";
}
SimpleGenerator.prototype.write = function(s/*STRING*/){
	this.mResult = this.mResult + s;
}
SimpleGenerator.prototype.result = function(){
	return this.mResult;
}

function makeIndent(count/*INTEGER*/){
	var result = '';
	for (var i = 0; i <= count - 1 | 0; ++i){
		result = result + kTab;
	}
	return result;
}

function indentText(s/*STRING*/, indent/*INTEGER*/){
	var result = '';
	var index = String.indexOf(s, 10);
	var pos = 0;
	while (true){
		if (index != -1){
			++index;
			result = result + String.substr(s, pos, index - pos | 0) + makeIndent(indent);
			pos = index;
			index = String.indexOfFrom(s, 10, pos);
		} else break;
	}
	return result + String.substr(s, pos, s.length - pos | 0);
}
Generator.prototype.write = function(s/*STRING*/){
	this.mResult = this.mResult + indentText(s, this.indent);
}
Generator.prototype.openScope = function(){
	++this.indent;
	this.mResult = this.mResult + "{" + Stream.kCR + makeIndent(this.indent);
}
Generator.prototype.closeScope = function(ending/*STRING*/){
	--this.indent;
	this.mResult = String.substr(this.mResult, 0, this.mResult.length - 1 | 0) + "}";
	if (ending.length != 0){
		this.write(ending);
	}
	else {
		this.mResult = this.mResult + Stream.kCR + makeIndent(this.indent);
	}
}
Generator.prototype.makeInsertion = function(){
	var insertion = new Insertion();
	insertion.pos = this.mResult.length;
	insertion.indent = this.indent;
	var result = this.$insertions.length;
	this.$insertions.push(RTL$.cloneRecord(insertion));
	return result;
}
Generator.prototype.insert = function(insertion/*INTEGER*/, code/*STRING*/){
	this.$insertions[insertion].code = code;
}
Generator.prototype.result = function(){
	var result = '';
	var pos = 0;
	for (var i = 0; i <= this.$insertions.length - 1 | 0; ++i){
		var nextPos = this.$insertions[i].pos;
		result = result + String.substr(this.mResult, pos, nextPos - pos | 0) + indentText(this.$insertions[i].code, this.$insertions[i].indent);
		pos = nextPos;
	}
	result = result + String.substr(this.mResult, pos, this.mResult.length - pos | 0);
	return result;
}

function makeSimpleGenerator(){
	var result = null;
	result = new SimpleGenerator();
	return result;
}

function makeGenerator(){
	var result = null;
	result = new Generator();
	return result;
}
exports.kTab = kTab;
exports.nullGenerator = function(){return nullGenerator;};
exports.makeSimpleGenerator = makeSimpleGenerator;
exports.makeGenerator = makeGenerator;
