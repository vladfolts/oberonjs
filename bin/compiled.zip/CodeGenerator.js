var RTL$ = require("eberon/eberon_rtl.js");
var Stream = require("js/Stream.js");
var String = require("js/String.js");
var kTab = "\t";
function IGenerator(){
}
function NullGenerator(){
	IGenerator.call(this);
}
RTL$.extend(NullGenerator, IGenerator);
function SimpleGenerator(){
	NullGenerator.call(this);
	this.mResult = '';
}
RTL$.extend(SimpleGenerator, NullGenerator);
function Indent(){
	this.indent = 0;
	this.result = '';
}
function Generator(){
	IGenerator.call(this);
	this.indent = new Indent();
}
RTL$.extend(Generator, IGenerator);
var nullGenerator = new NullGenerator();
NullGenerator.prototype.write = function(s/*STRING*/){
}
NullGenerator.prototype.openScope = function(){
}
NullGenerator.prototype.closeScope = function(ending/*STRING*/){
}
NullGenerator.prototype.result = function(){
	return "";
}
SimpleGenerator.prototype.write = function(s/*STRING*/){
	this.mResult = this.mResult + s;
}
SimpleGenerator.prototype.result = function(){
	return this.mResult;
}

function makeIndent(count/*INTEGER*/){
	var result = '';
	for (var i = 0; i <= count - 1 | 0; ++i){
		result = result + kTab;
	}
	return result;
}

function indentText(s/*STRING*/, indent/*INTEGER*/){
	var result = '';
	var index = String.indexOf(s, 10);
	var pos = 0;
	while (true){
		if (index != -1){
			++index;
			result = result + String.substr(s, pos, index - pos | 0) + makeIndent(indent);
			pos = index;
			index = String.indexOfFrom(s, 10, pos);
		} else break;
	}
	return result + String.substr(s, pos, s.length - pos | 0);
}

function addIndentedText(s/*STRING*/, indent/*VAR Indent*/){
	indent.result = indent.result + indentText(s, indent.indent);
}

function openScope(indent/*VAR Indent*/){
	++indent.indent;
	indent.result = indent.result + "{" + Stream.kCR + makeIndent(indent.indent);
}

function closeScope(ending/*STRING*/, indent/*VAR Indent*/){
	--indent.indent;
	indent.result = String.substr(indent.result, 0, indent.result.length - 1 | 0) + "}";
	if (ending.length != 0){
		addIndentedText(ending, indent);
	}
	else {
		indent.result = indent.result + Stream.kCR + makeIndent(indent.indent);
	}
}
Generator.prototype.write = function(s/*STRING*/){
	addIndentedText(s, this.indent);
}
Generator.prototype.openScope = function(){
	openScope(this.indent);
}
Generator.prototype.closeScope = function(ending/*STRING*/){
	closeScope(ending, this.indent);
}
Generator.prototype.result = function(){
	return this.indent.result;
}

function makeSimpleGenerator(){
	return new SimpleGenerator();
}

function makeGenerator(){
	return new Generator();
}
exports.kTab = kTab;
exports.IGenerator = IGenerator;
exports.Indent = Indent;
exports.nullGenerator = function(){return nullGenerator;};
exports.indentText = indentText;
exports.addIndentedText = addIndentedText;
exports.openScope = openScope;
exports.closeScope = closeScope;
exports.makeSimpleGenerator = makeSimpleGenerator;
exports.makeGenerator = makeGenerator;
