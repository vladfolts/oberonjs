var RTL$ = require("eberon/eberon_rtl.js");
var CodeGenerator = require("js/CodeGenerator.js");
var ContextExpression = require("js/ContextExpression.js");
var ContextHierarchy = require("js/ContextHierarchy.js");
var EberonContextDesignator = require("js/EberonContextDesignator.js");
var EberonRecord = require("js/EberonRecord.js");
var Errors = require("js/Errors.js");
var Expression = require("js/Expression.js");
var LanguageContext = require("js/LanguageContext.js");
var Symbols = require("js/Symbols.js");
var Types = require("js/Types.js");
function VariableInit(){
	ContextExpression.ExpressionHandler.apply(this, arguments);
	this.id = '';
	this.code = '';
	this.symbol = null;
}
RTL$.extend(VariableInit, ContextExpression.ExpressionHandler);
function For(){
	ContextHierarchy.Node.apply(this, arguments);
}
RTL$.extend(For, ContextHierarchy.Node);
RTL$.extend(VariableInitFor, VariableInit);
VariableInit.prototype.codeGenerator = function(){
	return CodeGenerator.nullGenerator();
};
VariableInit.prototype.handleIdent = function(id/*STRING*/){
	this.id = id;
};
VariableInit.prototype.handleLiteral = function(s/*STRING*/){
	this.code = "var " + this.id + " = ";
};
VariableInit.prototype.handleExpression = function(e/*PType*/){
	var cloneOp = null;
	var type = e.type();
	if (!(type instanceof Types.StorageType)){
		Errors.raise("cannot use " + type.description() + " to initialize variable");
	}
	else if (type instanceof Types.OpenArray){
		Errors.raise("cannot initialize variable '" + this.id + "' with open array");
	}
	else {
		var v = new EberonContextDesignator.TypeNarrowVariable(type, false, false, this.id);
		this.symbol = new Symbols.Symbol(this.id, v);
		if (type instanceof EberonRecord.Record){
			EberonRecord.ensureCanBeInstantiated(this, type, EberonRecord.instantiateForCopy);
			if (e.designator() != null){
				var l = this.root().language();
				this.code = this.code + l.rtl.clone(e.code(), l.types.typeInfo(type), "undefined");
			}
			else {
				this.code = this.code + e.code();
			}
		}
		else {
			var l = this.root().language();
			var void$ = l.types.implicitCast(type, type, false, {set: function($v){cloneOp = $v;}, get: function(){return cloneOp;}});
			this.code = this.code + cloneOp.clone(ContextHierarchy.makeLanguageContext(this), e);
		}
	}
};
VariableInit.prototype.onParsed = function(){
	this.parent().codeGenerator().write(this.code);
};
VariableInit.prototype.endParse = function(){
	var result = false;
	if (this.symbol != null){
		this.root().currentScope().addSymbol(this.symbol, false);
		this.onParsed();
		result = true;
	}
	return result;
};
function VariableInitFor(cx/*PFor*/){
	VariableInit.call(this, cx);
	this.parentFor = cx;
}
VariableInitFor.prototype.onParsed = function(){
	this.parentFor.handleInPlaceInit(this.symbol, this.code);
};
exports.VariableInit = VariableInit;
exports.VariableInitFor = VariableInitFor;
