var Errors = require("js/Errors.js");
var JsMap = require("js/JsMap.js");
var Scope = require("js/Scope.js");
var Symbols = require("js/Symbols.js");
var Operator = Scope.Type.extend({
	init: function Operator(){
		Scope.Type.prototype.init.call(this);
		this.parent = null;
	}
});
Operator.prototype.addSymbol = function(s/*PSymbol*/, exported/*BOOLEAN*/){
	var id = '';
	id = s.id();
	if (this.parent.findSymbol(id) != null){
		Errors.raise("'" + id + "' already declared in procedure scope");
	}
	Scope.Type.prototype.addSymbol.call(this, s, exported);
}

function makeOperator(parent/*PType*/, stdSymbols/*Type*/){
	var result = null;
	result = new Operator();
	Scope.init(result, stdSymbols);
	result.parent = parent;
	return result;
}
exports.makeOperator = makeOperator;
