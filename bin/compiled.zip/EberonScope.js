var RTL$ = require("eberon/eberon_rtl.js");
var Errors = require("js/Errors.js");
var Scope = require("js/Scope.js");
var Symbols = require("js/Symbols.js");
function Operator(){
	Scope.Type.apply(this, arguments);
	this.parent = null;
}
RTL$.extend(Operator, Scope.Type);
Operator.prototype.name = function(){
	return "operator";
}
Operator.prototype.addSymbol = function(s/*PSymbol*/, exported/*BOOLEAN*/){
	var id = s.id();
	var parent = this.parent;
	while (true){
		if (parent != null){
			var found = parent.findSymbol(id);
			if (found != null){
				Errors.raise("'" + id + "' already declared in " + found.scope().name() + " scope");
			}
			var next = parent;
			if (next instanceof Operator){
				parent = next.parent;
			}
			else {
				parent = null;
			}
		} else break;
	}
	Scope.Type.prototype.addSymbol.call(this, s, exported);
}
Operator.prototype.generateTempVar = function(pattern/*STRING*/){
	return this.parent.generateTempVar(pattern);
}

function makeOperator(parent/*PType*/, stdSymbols/*MAP OF PSymbol*/){
	var result = new Operator(stdSymbols);
	result.parent = parent;
	return result;
}
exports.makeOperator = makeOperator;
