var RTL$ = require("eberon/eberon_rtl.js");
var Types = require("js/Types.js");
RTL$.extend(Type, Types.Id);
RTL$.extend(Forward, Type);
RTL$.extend(Lazy, Type);
Type.prototype.description = function(){
	return "type " + this.type().description();
};
Type.prototype.type = function(){
	return this.mType;
};
Type.prototype.reset = function(type/*PType*/){
	this.mType = type;
};
function Forward(resolve/*ResolveTypeCallback*/){
	Type.call(this, null);
	this.resolve = resolve;
}
Forward.prototype.type = function(){
	if (this.mType == null){
		this.mType = this.resolve();
	}
	return this.mType;
};

function define(tId/*VAR Lazy*/, t/*PType*/){
	tId.mType = t;
}
Type.prototype.idType = function(){
	return "type";
};
function Type(type/*PType*/){
	Types.Id.call(this);
	this.mType = type;
}
function Lazy(){
	Type.call(this, null);
}
exports.Type = Type;
exports.Forward = Forward;
exports.Lazy = Lazy;
exports.define = define;
