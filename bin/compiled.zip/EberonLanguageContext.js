var RTL$ = require("eberon/eberon_rtl.js");
var EberonContextDesignator = require("js/EberonContextDesignator.js");
var EberonTypePromotion = require("js/EberonTypePromotion.js");
var Expression = require("js/Expression.js");
var LanguageContext = require("js/LanguageContext.js");
var Types = require("js/Types.js");
var $scope = "EberonLanguageContext";
function CodeTraits(){
	LanguageContext.CodeTraits.apply(this, arguments);
}
RTL$.extend(CodeTraits, LanguageContext.CodeTraits, $scope);
CodeTraits.prototype.referenceCode = function(info/*VAR Id*/){
	var result = '';
	if (info instanceof EberonTypePromotion.Variable){
		result = info.id();
	}
	else if (info instanceof EberonContextDesignator.MapElementVariable && !info.elementType.isScalar()){
		result = info.rval;
	}
	else {
		result = LanguageContext.CodeTraits.prototype.referenceCode.call(this, info);
	}
	return result;
};
CodeTraits.prototype.assign = function(info/*VAR Id*/, right/*PType*/){
	var result = '';
	if (info instanceof EberonContextDesignator.MapElementVariable){
		result = info.lval + " = " + Expression.deref(right).code();
	}
	else {
		result = LanguageContext.CodeTraits.prototype.assign.call(this, info, right);
	}
	return result;
};
exports.CodeTraits = CodeTraits;
