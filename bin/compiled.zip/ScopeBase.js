var Object = require("js/Object.js");
function Type(){
}
exports.Type = Type;
