var RTL$ = require("rtl.js");
var Object = require("js/Object.js");
var Type = RTL$.extend({
	init: function Type(){
	}
});
exports.Type = Type;
