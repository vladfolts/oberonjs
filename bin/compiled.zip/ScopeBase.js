var Object$ = require("js/Object$.js");
var $scope = "ScopeBase";
function Type(){
}
Type.prototype.$scope = $scope;
exports.Type = Type;
