var RTL$ = require("rtl.js");
var Cast = require("js/Cast.js");
var Context = require("js/Context.js");
var EberonContext = require("js/EberonContext.js");
var EberonTypes = require("js/EberonTypes.js");
var Errors = require("js/Errors.js");
var JS = GLOBAL;
var JsMap = require("js/JsMap.js");
var ScopeBase = require("js/ScopeBase.js");
var Object = require("js/Object.js");
var Stream = require("js/Stream.js");
var String = require("js/String.js");
var Types = require("js/Types.js");
function Record(){
	Types.Record.call(this);
	this.customConstructor = null;
	this.customConstructorDefined = false;
	this.customInitedfields = [];
	this.finalized = false;
	this.declaredMethods = null;
	this.definedMethods = [];
	this.abstractMethods = [];
	this.instantiated = false;
	this.createByNewOnly = false;
	this.declaredAsVariable = false;
	this.lazyDefinitions = null;
	this.nonExportedMethods = [];
	this.inheritanceCode = '';
	this.baseConstructorCallCode = '';
	this.fieldsInit = null;
	this.fieldsInitOrder = [];
	this.lastFieldInit = 0;
}
RTL$.extend(Record, Types.Record);
function RecordField(){
	Types.RecordField.call(this);
	this.record = null;
}
RTL$.extend(RecordField, Types.RecordField);
function RecordFieldAsMethod(){
	Types.RecordField.call(this);
}
RTL$.extend(RecordFieldAsMethod, Types.RecordField);
function MethodIds(){
	Object.Type.call(this);
	this.ids = [];
}
RTL$.extend(MethodIds, Object.Type);
function EnsureMethodDefinitionsClosure(){
	Object.Type.call(this);
	this.record = null;
	this.result = [];
}
RTL$.extend(EnsureMethodDefinitionsClosure, Object.Type);
function RequireMethodDefinitionClosure(){
	Object.Type.call(this);
	this.record = null;
	this.base = null;
}
RTL$.extend(RequireMethodDefinitionClosure, Object.Type);
function GenFieldInitCodeClosure(){
	Object.Type.call(this);
	this.cx = null;
	this.record = null;
	this.code = '';
}
RTL$.extend(GenFieldInitCodeClosure, Object.Type);

function cannotInstantiateErrMsg(r/*Record*/){
	return "cannot instantiate '" + r.name + "' because it has abstract method(s)";
}

function hasMethodDefinition(r/*PRecord*/, id/*STRING*/){
	var type = r;
	while (true){
		if (type != null && type.definedMethods.indexOf(id) == -1){
			type = RTL$.typeGuard(type.base, Record);
		} else break;
	}
	return type != null;
}

function findMethodDeclaration(r/*PRecord*/, id/*STRING*/){
	var result = null;
	var type = r;
	while (true){
		if (type != null && !JsMap.find(type.declaredMethods, id, {set: function($v){result = $v;}, get: function(){return result;}})){
			type = RTL$.typeGuard(type.base, Record);
		} else break;
	}
	return RTL$.typeGuard(result, Types.Field);
}

function ensureMethodDefinitionsForEach(key/*STRING*/, value/*PType*/, closure/*VAR Type*/){
	
	function do$(ids/*ARRAY OF STRING*/, closure/*EnsureMethodDefinitionsClosure*/){
		var report = [];
		for (var i = 0; i <= ids.length - 1 | 0; ++i){
			var m = ids[i];
			if (!hasMethodDefinition(closure.record, m)){
				report.push(m);
			}
		}
		if (report.length != 0){
			closure.result.push(key + ": " + String.join(report, ", "));
		}
	}
	do$(RTL$.typeGuard(value, MethodIds).ids, RTL$.typeGuard(closure, EnsureMethodDefinitionsClosure));
}

function ensureMethodDefinitions(r/*PRecord*/, reasons/*Type*/){
	var closure = new EnsureMethodDefinitionsClosure();
	closure.record = r;
	JsMap.forEach(reasons, ensureMethodDefinitionsForEach, closure);
	if (closure.result.length != 0){
		Errors.raise(String.join(closure.result, "; "));
	}
}

function makeMethodIds(){
	var result = null;
	result = new MethodIds();
	return result;
}

function requireMethodDefinition(r/*PRecord*/, id/*STRING*/, reason/*STRING*/){
	var existingIds = null;
	
	function makeIds(){
		var result = makeMethodIds();
		result.ids.push(id);
		return result;
	}
	
	function addIfNotThere(ids/*VAR ARRAY * OF STRING*/){
		if (ids.indexOf(id) == -1){
			ids.push(id);
		}
	}
	if (findMethodDeclaration(r, id) == null){
		Errors.raise("there is no method '" + id + "' in base type(s)");
	}
	if (r.finalized){
		var reasons = JsMap.make();
		JsMap.put(reasons, reason, makeIds());
		ensureMethodDefinitions(r, reasons);
	}
	else {
		if (!JsMap.find(r.lazyDefinitions, reason, {set: function($v){existingIds = $v;}, get: function(){return existingIds;}})){
			JsMap.put(r.lazyDefinitions, reason, makeIds());
		}
		else {
			addIfNotThere(RTL$.typeGuard(existingIds, MethodIds).ids);
		}
	}
}

function requireMethodDefinitionForEach(key/*STRING*/, value/*PType*/, closure/*VAR Type*/){
	
	function do$(closure/*RequireMethodDefinitionClosure*/){
		if (!hasMethodDefinition(closure.record, key)){
			requireMethodDefinition(closure.base, key, cannotInstantiateErrMsg(closure.record));
		}
	}
	do$(RTL$.typeGuard(closure, RequireMethodDefinitionClosure));
}

function ensureNonAbstract(r/*PRecord*/){
	var closure = new RequireMethodDefinitionClosure();
	if (r.abstractMethods.length != 0){
		Errors.raise(cannotInstantiateErrMsg(r) + ": " + String.join(r.abstractMethods, ", "));
	}
	var baseType = RTL$.typeGuard(r.base, Record);
	closure.record = r;
	while (true){
		if (baseType != null){
			if (!baseType.finalized){
				closure.base = baseType;
				JsMap.forEach(baseType.declaredMethods, requireMethodDefinitionForEach, closure);
			}
			baseType = RTL$.typeGuard(baseType.base, Record);
		} else break;
	}
}

function ensureVariableCanBeDeclared(r/*PRecord*/){
	var type = r;
	while (true){
		if (type != null){
			if (type.createByNewOnly){
				Errors.raise("cannot declare a variable of type '" + type.name + "' (and derived types) " + "because SELF(POINTER) was used in its method(s)");
			}
			type = RTL$.typeGuard(type.base, Record);
		} else break;
	}
}
RecordFieldAsMethod.prototype.asVar = function(isReadOnly/*BOOLEAN*/, cx/*Type*/){
	return EberonTypes.makeMethod(this.type());
}

function makeRecordFieldAsMethod(identdef/*PIdentdefInfo*/, type/*PType*/){
	var result = null;
	result = new RecordFieldAsMethod();
	Types.initRecordField(identdef, type, result);
	return result;
}
Record.prototype.initializer = function(cx/*Type*/, forNew/*BOOLEAN*/, code/*STRING*/){
	if (this.finalized){
		ensureNonAbstract(this);
		if (!forNew){
			ensureVariableCanBeDeclared(this);
		}
	}
	else {
		this.instantiated = true;
		if (!forNew){
			this.declaredAsVariable = true;
		}
	}
	return Types.Record.prototype.initializer.call(this, cx, forNew, code);
}
Record.prototype.findSymbol = function(id/*STRING*/){
	var result = findMethodDeclaration(this, id);
	if (result == null){
		result = Types.Record.prototype.findSymbol.call(this, id);
	}
	return result;
}
Record.prototype.addField = function(f/*PField*/){
	var id = f.id();
	if (findMethodDeclaration(this, id) != null){
		Errors.raise("cannot declare field, record already has method '" + id + "'");
	}
	var type = f.type();
	if (type instanceof Record && type.customConstructor != null && type.customConstructor.args().length != 0){
		this.customInitedfields.push(id);
	}
	this.fieldsInitOrder.push(id);
	Types.Record.prototype.addField.call(this, f);
}
Record.prototype.addMethod = function(methodId/*PIdentdefInfo*/, type/*PProcedure*/){
	var msg = '';
	var id = methodId.id();
	var existingField = this.findSymbol(id);
	if (existingField != null){
		if (existingField.type() instanceof EberonTypes.MethodType){
			msg = "cannot declare a new method '" + id + "': method already was declared";
		}
		else {
			msg = "cannot declare method, record already has field '" + id + "'";
		}
		Errors.raise(msg);
	}
	JsMap.put(this.declaredMethods, id, makeRecordFieldAsMethod(methodId, type));
	if (!methodId.exported()){
		this.nonExportedMethods.push(id);
	}
}
Record.prototype.defineMethod = function(methodId/*PIdentdefInfo*/, type/*PMethodType*/){
	var existingType = null;
	var id = methodId.id();
	if (this.definedMethods.indexOf(id) != -1){
		Errors.raise("method '" + this.name + "." + id + "' already defined");
	}
	var existingField = this.findSymbol(id);
	if (existingField != null){
		var t = existingField.type();
		if (t instanceof EberonTypes.MethodType){
			existingType = t.procType();
		}
	}
	if (existingType == null){
		Errors.raise("'" + this.name + "' has no declaration for method '" + id + "'");
	}
	var addType = type.procType();
	if (!Cast.areProceduresMatch(existingType, addType)){
		Errors.raise("overridden method '" + id + "' signature mismatch: should be '" + existingType.description() + "', got '" + addType.description() + "'");
	}
	this.definedMethods.push(id);
}
Record.prototype.requireNewOnly = function(){
	this.createByNewOnly = true;
}
Record.prototype.setBaseConstructorCallCode = function(code/*STRING*/){
	this.baseConstructorCallCode = code;
}
Record.prototype.setFieldInitializationCode = function(field/*STRING*/, code/*STRING*/){
	var index = this.fieldsInitOrder.indexOf(field);
	if (index < this.lastFieldInit){
		Errors.raise("field '" + field + "' must be initialized before '" + this.fieldsInitOrder[this.lastFieldInit] + "'");
	}
	else {
		this.lastFieldInit = index;
	}
	JsMap.putString(this.fieldsInit, field, code);
}
Record.prototype.setRecordInitializationCode = function(baseConstructorCallCode/*STRING*/, inheritanceCode/*STRING*/){
	this.baseConstructorCallCode = baseConstructorCallCode;
	this.inheritanceCode = inheritanceCode;
}
Record.prototype.declareConstructor = function(type/*PDefinedProcedure*/){
	if (this.customConstructor != null){
		Errors.raise("constructor '" + this.name + "' already declared");
	}
	if (type.result() != null){
		Errors.raise("constructor '" + this.name + "' cannot have result type specified");
	}
	this.customConstructor = type;
}
Record.prototype.defineConstructor = function(type/*PDefinedProcedure*/){
	if (this.customConstructor == null){
		Errors.raise("constructor was not declared for '" + this.name + "'");
	}
	if (this.customConstructorDefined){
		Errors.raise("constructor already defined for '" + this.name + "'");
	}
	if (!Cast.areProceduresMatch(this.customConstructor, type)){
		Errors.raise("constructor '" + this.name + "' signature mismatch: declared as '" + this.customConstructor.description() + "' but defined as '" + type.description() + "'");
	}
	this.customConstructorDefined = true;
}

function collectAbstractMethods(r/*Record*/){
	var methods = [];
	var selfMethods = JsMap.keys(r.declaredMethods).slice();
	var baseType = RTL$.typeGuard(r.base, Record);
	if (baseType != null){
		methods = baseType.abstractMethods.concat(selfMethods);;
	}
	else {
		Array.prototype.splice.apply(methods, [0, Number.MAX_VALUE].concat(selfMethods));
	}
	for (var i = 0; i <= methods.length - 1 | 0; ++i){
		var m = methods[i];
		if (r.definedMethods.indexOf(m) == -1){
			r.abstractMethods.push(m);
		}
	}
}
Record.prototype.finalize = function(){
	this.finalized = true;
	if (this.customConstructor != null && !this.customConstructorDefined){
		Errors.raise("constructor was declared for '" + this.name + "' but was not defined");
	}
	collectAbstractMethods(this);
	if (this.instantiated){
		ensureNonAbstract(this);
	}
	if (this.declaredAsVariable){
		ensureVariableCanBeDeclared(this);
	}
	ensureMethodDefinitions(this, this.lazyDefinitions);
	for (var i = 0; i <= this.nonExportedMethods.length - 1 | 0; ++i){
		JsMap.erase(this.declaredMethods, this.nonExportedMethods[i]);
	}
	this.nonExportedMethods.splice(0, Number.MAX_VALUE);
	Types.Record.prototype.finalize.call(this);
}
RecordField.prototype.asVar = function(isReadOnly/*BOOLEAN*/, cx/*Type*/){
	var actualReadOnly = isReadOnly;
	if (!actualReadOnly && cx.qualifyScope(Types.recordScope(this.record)).length != 0){
		actualReadOnly = RTL$.typeGuard(this.identdef(), EberonContext.IdentdefInfo).isReadOnly();
	}
	return Types.RecordField.prototype.asVar.call(this, actualReadOnly, cx);
}

function makeRecord(name/*STRING*/, cons/*STRING*/, scope/*PType*/){
	var result = null;
	result = new Record();
	Types.initRecord(result, name, cons, scope);
	result.declaredMethods = JsMap.make();
	result.lazyDefinitions = JsMap.make();
	result.fieldsInit = JsMap.makeStrings();
	result.lastFieldInit = -1;
	return result;
}

function genFieldInitCode(key/*STRING*/, value/*PType*/, closure/*VAR Type*/){
	
	function do$(f/*PField*/, closure/*VAR GenFieldInitCodeClosure*/){
		var code = '';
		var result = '';
		var type = RTL$.typeGuard(f.type(), Types.StorageType);
		if (JsMap.findString(closure.record.fieldsInit, key, {set: function($v){code = $v;}, get: function(){return code;}})){
			result = code;
		}
		else {
			result = "this." + Types.mangleField(key, type) + " = " + type.initializer(closure.cx, false, "");
		}
		closure.code = closure.code + result + ";" + Stream.kCR;
	}
	do$(RTL$.typeGuard(value, Types.Field), RTL$.typeGuard(closure, GenFieldInitCodeClosure));
}

function fieldsInitializationCode(r/*PRecord*/, cx/*PType*/){
	var closure = new GenFieldInitCodeClosure();
	closure.cx = cx;
	closure.record = r;
	JsMap.forEach(Types.recordOwnFields(r), genFieldInitCode, closure);
	return closure.code;
}

function makeRecordField(identdef/*PIdentdefInfo*/, type/*PType*/, record/*PRecord*/){
	var result = null;
	result = new RecordField();
	Types.initRecordField(identdef, type, result);
	result.record = record;
	return result;
}

function actualConstructor(r/*Record*/){
	var result = r.customConstructor;
	if (result == null && r.base != null){
		result = actualConstructor(RTL$.typeGuard(r.base, Record));
	}
	return result;
}
exports.Record = Record;
exports.requireMethodDefinition = requireMethodDefinition;
exports.makeRecord = makeRecord;
exports.fieldsInitializationCode = fieldsInitializationCode;
exports.makeRecordField = makeRecordField;
exports.actualConstructor = actualConstructor;
