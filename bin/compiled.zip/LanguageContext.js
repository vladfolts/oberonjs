var RTL$ = require("eberon/eberon_rtl.js");
var Code = require("js/Code.js");
var Context = require("js/Context.js");
var CodeGenerator = require("js/CodeGenerator.js");
var T = require("js/Types.js");
function CastOp(){
}
function Types(){
}
function Type(){
	Context.Type.call(this);
	this.moduleResolver = null;
	this.codeGenerator = null;
	this.types = null;
}
RTL$.extend(Type, Context.Type);
exports.CastOp = CastOp;
exports.Types = Types;
exports.Type = Type;
