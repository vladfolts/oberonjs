var RTL$ = require("rtl.js");
var Context = require("js/Context.js");
var Language = require("js/Language.js");
function Type(){
	Context.Type.call(this);
	this.types = null;
}
RTL$.extend(Type, Context.Type);
exports.Type = Type;
