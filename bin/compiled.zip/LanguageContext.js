var CodeGenerator = require("js/CodeGenerator.js");
var Context = require("js/Context.js");
var Expression = require("js/Expression.js");
var OberonRtl = require("js/OberonRtl.js");
var Symbols = require("js/Symbols.js");
var T = require("js/Types.js");
function CastOp(){
}
function Types(){
}
function Language(){
	this.moduleResolver = null;
	this.rtl = null;
	this.codeGenerator = null;
	this.types = null;
	this.stdSymbols = {};
}
function Type(language/*PLanguage*/, cx/*PType*/){
	this.language = language;
	this.cx = cx;
}
exports.CastOp = CastOp;
exports.Types = Types;
exports.Language = Language;
exports.Type = Type;
