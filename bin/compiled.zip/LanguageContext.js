var CodeGenerator = require("js/CodeGenerator.js");
var Context = require("js/Context.js");
var Expression = require("js/Expression.js");
var OberonRtl = require("js/OberonRtl.js");
var Symbols = require("js/Symbols.js");
var T = require("js/Types.js");
var $scope = "LanguageContext";
function CastOp(){
}
CastOp.prototype.$scope = $scope;
function Types(){
}
Types.prototype.$scope = $scope;
function ModuleGenerator(){
}
ModuleGenerator.prototype.$scope = $scope;
function Language(){
	this.moduleResolver = null;
	this.rtl = null;
	this.codeGenerator = null;
	this.types = null;
	this.stdSymbols = {};
}
Language.prototype.$scope = $scope;
Type.prototype.$scope = $scope;
function Type(language/*PLanguage*/, cx/*PType*/){
	this.language = language;
	this.cx = cx;
}
exports.CastOp = CastOp;
exports.Types = Types;
exports.ModuleGenerator = ModuleGenerator;
exports.Language = Language;
exports.Type = Type;
