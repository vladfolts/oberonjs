var RTL$ = require("rtl.js");
var Context = require("js/Context.js");
var Language = require("js/Language.js");
RTL$.extend(Type, Context.Type);
function Type(){
	Context.Type.call(this);
	this.types = null;
}
exports.Type = Type;
