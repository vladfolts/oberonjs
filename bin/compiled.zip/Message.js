var methodAnonRec = "cannot declare methods for anonymous records (POINTER TO RECORD)";
var methodExport = "{0} '{1}' cannot be exported because record itself is not exported";
exports.methodAnonRec = methodAnonRec;
exports.methodExport = methodExport;
