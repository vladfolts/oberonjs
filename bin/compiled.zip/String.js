var JS = GLOBAL;

function fromChar(c/*CHAR*/){
	var result = '';
	result = JS.String.fromCharCode(c);
	return result;
}

function fromInt(i/*INTEGER*/){
	var result = '';
	result = '' + i;
	return result;
}

function indexOf(self/*STRING*/, c/*CHAR*/){
	var result = 0;
	result = self.indexOf(JS.String.fromCharCode(c));
	return result;
}

function indexOfFrom(self/*STRING*/, c/*CHAR*/, pos/*INTEGER*/){
	var result = 0;
	result = self.indexOf(JS.String.fromCharCode(c), pos);
	return result;
}

function substr(self/*STRING*/, pos/*INTEGER*/, len/*INTEGER*/){
	var result = '';
	result = self.substr(pos, len);
	return result;
}
exports.fromChar = fromChar;
exports.fromInt = fromInt;
exports.indexOf = indexOf;
exports.indexOfFrom = indexOfFrom;
exports.substr = substr;
