var Context = require("js/Context.js");
var Errors = require("js/Errors.js");
var Stream = require("js/Stream.js");
var String = require("js/String.js");
var quote = "\"";
var commentBegin = "(*";
var commentEnd = "*)";
var jsReservedWords = "break case catch const continue debugger default delete do else finally " + "for function if in instanceof new return switch this throw try typeof " + "var void while with false true null class enum export extends " + "import super implements interface let package private protected " + "public static yield " + "Object Math Number";

function isDigit(c/*CHAR*/){
	return c >= 48 && c <= 57;
}

function isLetter(c/*CHAR*/){
	return c >= 97 && c <= 122 || c >= 65 && c <= 90;
}

function digit(stream/*VAR Type*/, context/*Type*/){
	var result = false;
	var c = 0;
	if (!Stream.eof(stream)){
		c = Stream.getChar(stream);
		if (isDigit(c)){
			context.handleChar(c);
			result = true;
		}
	}
	return result;
}

function hexDigit(stream/*VAR Type*/, context/*Type*/){
	var result = false;
	var c = 0;
	c = Stream.getChar(stream);
	if (isDigit(c) || c >= 65 && c <= 70){
		context.handleChar(c);
		result = true;
	}
	return result;
}

function point(stream/*VAR Type*/, context/*Type*/){
	var result = false;
	if (!Stream.eof(stream) && Stream.getChar(stream) == 46 && (Stream.eof(stream) || Stream.peekChar(stream) != 46)){
		context.handleLiteral(".");
		result = true;
	}
	return result;
}

function string(stream/*VAR Type*/, context/*Type*/){
	var result = false;
	var c = 0;
	var s = '';
	if (!Stream.eof(stream)){
		c = Stream.getChar(stream);
		if (c == 34){
			if (!Stream.eof(stream)){
				c = Stream.getChar(stream);
				while (true){
					if (c != 34 && !Stream.eof(stream)){
						if (c != 34){
							s = s + String.fromChar(c);
						}
						c = Stream.getChar(stream);
					} else break;
				}
			}
			else {
				c = 0;
			}
			if (c != 34){
				Errors.raise("unexpected end of string");
			}
			context.handleString(s);
			result = true;
		}
	}
	return result;
}

function isReservedWord(s/*STRING*/, words/*STRING*/){
	var i = 0;var w = 0;
	while (true){
		if (w < words.length && i < s.length && words.charCodeAt(w) == s.charCodeAt(i) && (i != 0 || w == 0 || words.charCodeAt(w - 1 | 0) == 32)){
			++w;
			++i;
		}
		else if (w < words.length && (i < s.length || words.charCodeAt(w) != 32)){
			++w;
			i = 0;
		} else break;
	}
	return i == s.length;
}

function ident(stream/*VAR Type*/, context/*Type*/, reservedWords/*STRING*/){
	var result = false;
	var c = 0;
	var s = '';
	if (!Stream.eof(stream)){
		c = Stream.getChar(stream);
		if (isLetter(c)){
			while (true){
				if (!Stream.eof(stream) && (isLetter(c) || isDigit(c))){
					s = s + String.fromChar(c);
					c = Stream.getChar(stream);
				} else break;
			}
			if (isLetter(c) || isDigit(c)){
				s = s + String.fromChar(c);
			}
			else {
				Stream.next(stream, -1);
			}
			if (!isReservedWord(s, reservedWords)){
				if (isReservedWord(s, jsReservedWords)){
					s = s + "$";
				}
				context.handleIdent(s);
				result = true;
			}
		}
	}
	return result;
}

function skipComment(stream/*VAR Type*/, context/*Type*/){
	var result = false;
	if (Stream.peekStr(stream, commentBegin)){
		Stream.next(stream, commentBegin.length);
		while (true){
			if (!Stream.peekStr(stream, commentEnd)){
				if (!skipComment(stream, context)){
					Stream.next(stream, 1);
					if (Stream.eof(stream)){
						Errors.raise("comment was not closed");
					}
				}
			} else break;
		}
		Stream.next(stream, commentEnd.length);
		result = true;
	}
	return result;
}

function readSpaces(c/*CHAR*/){
	return c == 32 || c == 8 || c == 9 || c == 10 || c == 13;
}

function skipSpaces(stream/*VAR Type*/, context/*Type*/){
	if (context.isLexem == null || !context.isLexem()){
		while (true){
			if (Stream.read(stream, readSpaces) && skipComment(stream, context)){
			} else break;
		}
	}
}

function separator(stream/*Type*/, context/*Type*/){
	return Stream.eof(stream) || !isLetter(Stream.peekChar(stream));
}
function Literal(s/*STRING*/){
	this.s = s;
}

function literal(l/*Literal*/, stream/*VAR Type*/, context/*Type*/){
	var result = false;
	if (Stream.peekStr(stream, l.s)){
		Stream.next(stream, l.s.length);
		if (context.isLexem != null && context.isLexem() || !isLetter(l.s.charCodeAt(l.s.length - 1 | 0)) || Stream.eof(stream) || !isLetter(Stream.peekChar(stream)) && !isDigit(Stream.peekChar(stream))){
			context.handleLiteral(l.s);
			result = true;
		}
	}
	return result;
}
exports.Literal = Literal;
exports.digit = digit;
exports.hexDigit = hexDigit;
exports.point = point;
exports.string = string;
exports.ident = ident;
exports.skipSpaces = skipSpaces;
exports.separator = separator;
exports.literal = literal;
