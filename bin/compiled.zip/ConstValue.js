var RTL$ = require("eberon/eberon_rtl.js");
function Type(){
}
RTL$.extend(Int, Type);
RTL$.extend(Real, Type);
RTL$.extend(Set, Type);
RTL$.extend(String, Type);
function Int(n/*INTEGER*/){
	Type.call(this);
	this.value = n;
}
function Real(r/*REAL*/){
	Type.call(this);
	this.value = r;
}
function Set(s/*SET*/){
	Type.call(this);
	this.value = s;
}
function String(s/*STRING*/){
	Type.call(this);
	this.value = s;
}
exports.Type = Type;
exports.Int = Int;
exports.Real = Real;
exports.Set = Set;
exports.String = String;
