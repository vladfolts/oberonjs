var RTL$ = require("rtl.js");
var Cast = require("js/Cast.js");
var Code = require("js/Code.js");
var Context = require("js/Context.js");
var EberonArray = require("js/EberonArray.js");
var Errors = require("js/Errors.js");
var LanguageContext = require("js/LanguageContext.js");
var Procedure = require("js/Procedure.js");
var Types = require("js/Types.js");
var methodNameAdd = "add";
var methodNameClear = "clear";
var methodNameRemove = "remove";
function DynamicArray(){
	Types.Array.call(this);
}
RTL$.extend(DynamicArray, Types.Array);
function AddCallGenerator(){
	Procedure.CallGenerator.call(this);
	this.cx = null;
	this.elementsType = null;
	this.code = '';
}
RTL$.extend(AddCallGenerator, Procedure.CallGenerator);
function Method(){
	EberonArray.Method.call(this);
}
RTL$.extend(Method, EberonArray.Method);
function MethodAdd(){
	Method.call(this);
	this.elementsType = null;
}
RTL$.extend(MethodAdd, Method);
function MethodClear(){
	Method.call(this);
}
RTL$.extend(MethodClear, Method);
function MethodRemove(){
	Method.call(this);
}
RTL$.extend(MethodRemove, Method);
function MethodCallClear(){
	Procedure.StdCall.call(this);
}
RTL$.extend(MethodCallClear, Procedure.StdCall);
function MethodCallRemove(){
	Procedure.StdCall.call(this);
}
RTL$.extend(MethodCallRemove, Procedure.StdCall);

function arrayDimensionDescription(a/*VAR Array*/){
	var result = '';
	if (a instanceof DynamicArray){
		result = "*";
	}
	else {
		result = Types.arrayDimensionDescription(a);
	}
	return result;
}
DynamicArray.prototype.initializer = function(cx/*Type*/, forNew/*BOOLEAN*/){
	return "[]";
}
DynamicArray.prototype.description = function(){
	return Types.arrayDescription(this, arrayDimensionDescription);
}

function makeAddField(elementsType/*PType*/){
	var result = null;
	result = new MethodAdd();
	result.name = methodNameAdd;
	result.elementsType = elementsType;
	return result;
}

function makeClearMethod(){
	var result = null;
	result = new MethodClear();
	result.name = methodNameClear;
	return result;
}

function makeRemoveMethod(){
	var result = null;
	result = new MethodRemove();
	result.name = methodNameRemove;
	return result;
}
DynamicArray.prototype.denote = function(id/*STRING*/){
	var method = null;
	var result = null;
	if (id == methodNameAdd){
		method = makeAddField(this.elementsType);
	}
	else if (id == methodNameClear){
		method = makeClearMethod();
	}
	else if (id == methodNameRemove){
		method = makeRemoveMethod();
	}
	else {
		method = EberonArray.denoteMethod(id, this.elementsType);
	}
	if (method != null){
		result = EberonArray.makeMethodField(method);
	}
	else {
		result = Types.Array.prototype.denote.call(this, id);
	}
	return result;
}

function makeDynamicArray(elementsType/*PType*/){
	var result = null;
	result = new DynamicArray();
	Types.initArray(elementsType, result);
	return result;
}
AddCallGenerator.prototype.handleArgument = function(e/*PExpression*/){
	if (this.code != ""){
		Errors.raise("method 'add' expects one argument, got many");
	}
	var argCode = Procedure.makeArgumentsCode(this.cx);
	Procedure.checkArgument(e, Types.makeProcedureArgument(this.elementsType, false), 0, argCode, this.cx.types);
	this.code = argCode.result();
	var t = e.type();
	if (t instanceof Types.Array){
		this.code = Cast.cloneArray(t, this.code, this.cx.rtl);
	}
	else if (t instanceof Types.Record){
		this.code = this.cx.rtl.cloneRecord(this.code);
	}
}
AddCallGenerator.prototype.end = function(){
	if (this.code == ""){
		Errors.raise("method 'add' expects one argument, got nothing");
	}
	return Code.makeSimpleExpression("(" + this.code + ")", null);
}
Method.prototype.description = function(){
	return "dynamic array method '" + this.name + "'";
}
MethodAdd.prototype.designatorCode = function(id/*STRING*/){
	return "push";
}
MethodAdd.prototype.callGenerator = function(cx/*PType*/){
	var result = null;
	result = new AddCallGenerator();
	result.cx = cx;
	result.elementsType = this.elementsType;
	return result;
}
MethodClear.prototype.designatorCode = function(id/*STRING*/){
	return "splice";
}
MethodCallClear.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
	Procedure.processArguments(args, this.args, null, cx.types);
	return Code.makeSimpleExpression("(0, Number.MAX_VALUE)", null);
}
MethodCallRemove.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
	var argCode = Procedure.makeArgumentsCode(cx);
	var arg = Procedure.checkSingleArgument(args, this, cx.types, argCode);
	var value = arg.constValue();
	if (value != null && value instanceof Code.IntConst){
		Code.checkIndex(value.value);
	}
	return Code.makeSimpleExpression("(" + argCode.result() + ", 1)", null);
}
MethodRemove.prototype.designatorCode = function(id/*STRING*/){
	return "splice";
}
MethodClear.prototype.callGenerator = function(cx/*PType*/){
	var call = null;
	call = new MethodCallClear();
	Procedure.initStdCall(call);
	return Procedure.makeCallGenerator(call, cx);
}
MethodRemove.prototype.callGenerator = function(cx/*PType*/){
	var a = null;
	var call = null;
	call = new MethodCallRemove();
	Procedure.initStdCall(call);
	a = new Types.ProcedureArgument();
	a.type = Types.basic().integer;
	call.args.push(a);
	return Procedure.makeCallGenerator(call, cx);
}
exports.DynamicArray = DynamicArray;
exports.makeDynamicArray = makeDynamicArray;
