var Code = require("js/Code.js");
var Context = require("js/Context.js");
var EberonTypes = require("js/EberonTypes.js");
var Errors = require("js/Errors.js");
var JsArray = require("js/JsArray.js");
var LanguageContext = require("js/LanguageContext.js");
var Procedure = require("js/Procedure.js");
var Types = require("js/Types.js");
var methodNameAdd = "add";
var methodNameRemove = "remove";
var methodNameIndexOf = "indexOf";
var DynamicArray = Types.Array.extend({
	init: function DynamicArray(){
		Types.Array.prototype.init.call(this);
	}
});
var Method = Procedure.Std.extend({
	init: function Method(){
		Procedure.Std.prototype.init.call(this);
	}
});
var MethodField = Types.Field.extend({
	init: function MethodField(){
		Types.Field.prototype.init.call(this);
		this.method = null;
	}
});
var AddCallGenerator = Procedure.CallGenerator.extend({
	init: function AddCallGenerator(){
		Procedure.CallGenerator.prototype.init.call(this);
		this.cx = null;
		this.elementsType = null;
		this.code = '';
	}
});
var MethodAdd = Method.extend({
	init: function MethodAdd(){
		Method.prototype.init.call(this);
		this.elementsType = null;
	}
});
var MethodRemove = Method.extend({
	init: function MethodRemove(){
		Method.prototype.init.call(this);
	}
});
var MethodIndexOf = Method.extend({
	init: function MethodIndexOf(){
		Method.prototype.init.call(this);
		this.elementsType = null;
	}
});
var MethodCallRemove = Procedure.StdCall.extend({
	init: function MethodCallRemove(){
		Procedure.StdCall.prototype.init.call(this);
	}
});
var MethodCallIndexOf = Procedure.StdCall.extend({
	init: function MethodCallIndexOf(){
		Procedure.StdCall.prototype.init.call(this);
	}
});

function arrayDimensionDescription(a/*VAR Array*/){
	var result = '';
	if (a instanceof DynamicArray){
		result = "*";
	}
	else {
		result = Types.arrayDimensionDescription(a);
	}
	return result;
}
DynamicArray.prototype.initializer = function(cx/*Type*/, forNew/*BOOLEAN*/){
	return "[]";
}
DynamicArray.prototype.description = function(){
	return Types.arrayDescription(this, arrayDimensionDescription);
}

function makeAddField(elementsType/*PType*/){
	var result = null;
	result = new MethodAdd();
	result.name = methodNameAdd;
	result.elementsType = elementsType;
	return result;
}

function makeRemoveField(){
	var result = null;
	result = new MethodRemove();
	result.name = methodNameRemove;
	return result;
}

function makeIndexOfField(elementsType/*PType*/){
	var result = null;
	result = new MethodIndexOf();
	result.name = methodNameIndexOf;
	result.elementsType = elementsType;
	return result;
}
DynamicArray.prototype.denote = function(id/*STRING*/){
	var field = null;
	var method = null;
	var result = null;
	if (id == methodNameAdd){
		method = makeAddField(this.elementsType);
	}
	else if (id == methodNameRemove){
		method = makeRemoveField();
	}
	else if (id == methodNameIndexOf){
		method = makeIndexOfField(this.elementsType);
	}
	if (method != null){
		field = new MethodField();
		field.method = method;
		result = field;
	}
	else {
		result = Types.Array.prototype.denote.call(this, id);
	}
	return result;
}

function makeDynamicArray(elementsType/*PType*/){
	var result = null;
	result = new DynamicArray();
	Types.initArray(elementsType, result);
	return result;
}
MethodField.prototype.id = function(){
	return "add";
}
MethodField.prototype.exported = function(){
	return false;
}
MethodField.prototype.type = function(){
	return this.method;
}
MethodField.prototype.asVar = function(){
	return EberonTypes.makeMethod(this.method);
}
AddCallGenerator.prototype.handleArgument = function(e/*PExpression*/){
	if (this.code != ""){
		Errors.raise("method 'add' expects one argument, got many");
	}
	var argCode = Procedure.makeArgumentsCode(this.cx);
	Procedure.checkArgument(e, Types.makeProcedureArgument(this.elementsType, false), 0, argCode, this.cx.types);
	this.code = argCode.result();
	var t = e.type();
	if (t instanceof Types.Record || t instanceof Types.Array){
		this.code = this.cx.rtl.clone(this.code);
	}
}
AddCallGenerator.prototype.end = function(){
	if (this.code == ""){
		Errors.raise("method 'add' expects one argument, got nothing");
	}
	return Code.makeSimpleExpression("(" + this.code + ")", null);
}
Method.prototype.description = function(){
	return "dynamic array method '" + this.name + "'";
}
MethodAdd.prototype.designatorCode = function(id/*STRING*/){
	return "push";
}
MethodAdd.prototype.callGenerator = function(cx/*PType*/){
	var result = null;
	result = new AddCallGenerator();
	result.cx = cx;
	result.elementsType = this.elementsType;
	return result;
}
MethodCallRemove.prototype.make = function(args/*Type*/, cx/*PType*/){
	var argCode = Procedure.makeArgumentsCode(cx);
	var arg = Procedure.checkSingleArgument(args, this, cx.types, argCode);
	var value = arg.constValue();
	if (value != null && value instanceof Code.IntConst){
		Code.checkIndex(value.value);
	}
	return Code.makeSimpleExpression("(" + argCode.result() + ", 1)", null);
}
MethodCallIndexOf.prototype.make = function(args/*Type*/, cx/*PType*/){
	var argCode = Procedure.makeArgumentsCode(cx);
	var void$ = Procedure.checkSingleArgument(args, this, cx.types, argCode);
	return Code.makeSimpleExpression("(" + argCode.result() + ")", Types.basic().integer);
}
MethodRemove.prototype.designatorCode = function(id/*STRING*/){
	return "splice";
}
MethodIndexOf.prototype.designatorCode = function(id/*STRING*/){
	return "indexOf";
}
MethodRemove.prototype.callGenerator = function(cx/*PType*/){
	var a = null;
	var call = null;
	call = new MethodCallRemove();
	Procedure.initStdCall(call);
	a = new Types.ProcedureArgument();
	a.type = Types.basic().integer;
	JsArray.add(call.args, a);
	return Procedure.makeCallGenerator(call, cx);
}
MethodIndexOf.prototype.callGenerator = function(cx/*PType*/){
	var a = null;
	var call = null;
	call = new MethodCallIndexOf();
	Procedure.initStdCall(call);
	a = new Types.ProcedureArgument();
	a.type = this.elementsType;
	JsArray.add(call.args, a);
	return Procedure.makeCallGenerator(call, cx);
}
exports.DynamicArray = DynamicArray;
exports.makeDynamicArray = makeDynamicArray;
