var Code = require("js/Code.js");
var Context = require("js/Context.js");
var EberonTypes = require("js/EberonTypes.js");
var Errors = require("js/Errors.js");
var JsArray = require("js/JsArray.js");
var LanguageContext = require("js/LanguageContext.js");
var Procedure = require("js/Procedure.js");
var Types = require("js/Types.js");
var DynamicArray = Types.Array.extend({
	init: function DynamicArray(){
		Types.Array.prototype.init.call(this);
	}
});
var DynamicArrayMethod = Procedure.Std.extend({
	init: function DynamicArrayMethod(){
		Procedure.Std.prototype.init.call(this);
	}
});
var DynamicArrayMethodField = Types.Field.extend({
	init: function DynamicArrayMethodField(){
		Types.Field.prototype.init.call(this);
		this.method = null;
	}
});
var DynamicArrayAddCallGenerator = Procedure.CallGenerator.extend({
	init: function DynamicArrayAddCallGenerator(){
		Procedure.CallGenerator.prototype.init.call(this);
		this.cx = null;
		this.elementsType = null;
		this.code = '';
	}
});
var DynamicArrayMethodAdd = DynamicArrayMethod.extend({
	init: function DynamicArrayMethodAdd(){
		DynamicArrayMethod.prototype.init.call(this);
		this.elementsType = null;
	}
});
var DynamicArrayMethodRemove = DynamicArrayMethod.extend({
	init: function DynamicArrayMethodRemove(){
		DynamicArrayMethod.prototype.init.call(this);
	}
});
var RemoveMethodCall = Procedure.StdCall.extend({
	init: function RemoveMethodCall(){
		Procedure.StdCall.prototype.init.call(this);
	}
});

function arrayDimensionDescription(a/*VAR Array*/){
	var result = '';
	if (a instanceof DynamicArray){
		result = "*";
	}
	else {
		result = Types.arrayDimensionDescription(a);
	}
	return result;
}
DynamicArray.prototype.initializer = function(cx/*Type*/, forNew/*BOOLEAN*/){
	return "[]";
}
DynamicArray.prototype.description = function(){
	return Types.arrayDescription(this, arrayDimensionDescription);
}

function makeAddField(elementsType/*PType*/){
	var result = null;
	result = new DynamicArrayMethodAdd();
	result.name = "add";
	result.elementsType = elementsType;
	return result;
}

function makeRemoveField(){
	var result = null;
	result = new DynamicArrayMethodRemove();
	result.name = "remove";
	return result;
}
DynamicArray.prototype.denote = function(id/*STRING*/){
	var field = null;
	var method = null;
	var result = null;
	if (id == "add"){
		method = makeAddField(this.elementsType);
	}
	else if (id == "remove"){
		method = makeRemoveField();
	}
	if (method != null){
		field = new DynamicArrayMethodField();
		field.method = method;
		result = field;
	}
	else {
		result = Types.Array.prototype.denote.call(this, id);
	}
	return result;
}

function makeDynamicArray(elementsType/*PType*/){
	var result = null;
	result = new DynamicArray();
	Types.initArray(elementsType, result);
	return result;
}
DynamicArrayMethodField.prototype.id = function(){
	return "add";
}
DynamicArrayMethodField.prototype.exported = function(){
	return false;
}
DynamicArrayMethodField.prototype.type = function(){
	return this.method;
}
DynamicArrayMethodField.prototype.asVar = function(){
	return EberonTypes.makeMethod(this.method);
}
DynamicArrayAddCallGenerator.prototype.handleArgument = function(e/*PExpression*/){
	if (this.code != ""){
		Errors.raise("method 'add' expects one argument, got many");
	}
	var argCode = Procedure.makeArgumentsCode(this.cx);
	Procedure.checkArgument(e, Types.makeProcedureArgument(this.elementsType, false), 0, argCode, this.cx.types);
	this.code = argCode.result();
	var t = e.type();
	if (t instanceof Types.Record || t instanceof Types.Array){
		this.code = this.cx.rtl.clone(this.code);
	}
}
DynamicArrayAddCallGenerator.prototype.end = function(){
	if (this.code == ""){
		Errors.raise("method 'add' expects one argument, got nothing");
	}
	return Code.makeSimpleExpression("(" + this.code + ")", null);
}
DynamicArrayMethod.prototype.description = function(){
	return "dynamic array method '" + this.name + "'";
}
DynamicArrayMethodAdd.prototype.designatorCode = function(id/*STRING*/){
	return "push";
}
DynamicArrayMethodAdd.prototype.callGenerator = function(cx/*PType*/){
	var result = null;
	result = new DynamicArrayAddCallGenerator();
	result.cx = cx;
	result.elementsType = this.elementsType;
	return result;
}
RemoveMethodCall.prototype.make = function(args/*Type*/, cx/*Type*/){
	var arg = Procedure.checkSingleArgument(args, this, cx.types);
	var value = arg.constValue();
	if (value != null && value instanceof Code.IntConst){
		Code.checkIndex(value.value);
	}
	return Code.makeSimpleExpression("(" + arg.code() + ", 1)", null);
}
DynamicArrayMethodRemove.prototype.designatorCode = function(id/*STRING*/){
	return "splice";
}
DynamicArrayMethodRemove.prototype.callGenerator = function(cx/*PType*/){
	var a = null;
	var call = null;
	call = new RemoveMethodCall();
	Procedure.initStdCall(call);
	a = new Types.ProcedureArgument();
	a.type = Types.basic().integer;
	JsArray.add(call.args, a);
	return Procedure.makeCallGenerator(call, cx);
}
exports.DynamicArray = DynamicArray;
exports.makeDynamicArray = makeDynamicArray;
