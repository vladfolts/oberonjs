var Cast = require("js/Cast.js");
var Code = require("js/Code.js");
var Context = require("js/Context.js");
var EberonTypes = require("js/EberonTypes.js");
var Errors = require("js/Errors.js");
var LanguageContext = require("js/LanguageContext.js");
var Procedure = require("js/Procedure.js");
var Types = require("js/Types.js");
var methodNameAdd = "add";
var methodNameClear = "clear";
var methodNameIndexOf = "indexOf";
var methodNameRemove = "remove";
var DynamicArray = Types.Array.extend({
	init: function DynamicArray(){
		Types.Array.prototype.init.call(this);
	}
});
var Method = Procedure.Std.extend({
	init: function Method(){
		Procedure.Std.prototype.init.call(this);
	}
});
var MethodField = Types.Field.extend({
	init: function MethodField(){
		Types.Field.prototype.init.call(this);
		this.method = null;
	}
});
var AddCallGenerator = Procedure.CallGenerator.extend({
	init: function AddCallGenerator(){
		Procedure.CallGenerator.prototype.init.call(this);
		this.cx = null;
		this.elementsType = null;
		this.code = '';
	}
});
var MethodAdd = Method.extend({
	init: function MethodAdd(){
		Method.prototype.init.call(this);
		this.elementsType = null;
	}
});
var MethodClear = Method.extend({
	init: function MethodClear(){
		Method.prototype.init.call(this);
	}
});
var MethodIndexOf = Method.extend({
	init: function MethodIndexOf(){
		Method.prototype.init.call(this);
		this.elementsType = null;
	}
});
var MethodRemove = Method.extend({
	init: function MethodRemove(){
		Method.prototype.init.call(this);
	}
});
var MethodCallClear = Procedure.StdCall.extend({
	init: function MethodCallClear(){
		Procedure.StdCall.prototype.init.call(this);
	}
});
var MethodCallRemove = Procedure.StdCall.extend({
	init: function MethodCallRemove(){
		Procedure.StdCall.prototype.init.call(this);
	}
});
var MethodCallIndexOf = Procedure.StdCall.extend({
	init: function MethodCallIndexOf(){
		Procedure.StdCall.prototype.init.call(this);
	}
});

function arrayDimensionDescription(a/*VAR Array*/){
	var result = '';
	if (a instanceof DynamicArray){
		result = "*";
	}
	else {
		result = Types.arrayDimensionDescription(a);
	}
	return result;
}
DynamicArray.prototype.initializer = function(cx/*Type*/, forNew/*BOOLEAN*/){
	return "[]";
}
DynamicArray.prototype.description = function(){
	return Types.arrayDescription(this, arrayDimensionDescription);
}

function makeAddField(elementsType/*PType*/){
	var result = null;
	result = new MethodAdd();
	result.name = methodNameAdd;
	result.elementsType = elementsType;
	return result;
}

function makeClearMethod(){
	var result = null;
	result = new MethodClear();
	result.name = methodNameClear;
	return result;
}

function makeIndexOfMethod(elementsType/*PType*/){
	var result = null;
	result = new MethodIndexOf();
	result.name = methodNameIndexOf;
	result.elementsType = elementsType;
	return result;
}

function makeRemoveMethod(){
	var result = null;
	result = new MethodRemove();
	result.name = methodNameRemove;
	return result;
}
DynamicArray.prototype.denote = function(id/*STRING*/){
	var field = null;
	var method = null;
	var result = null;
	if (id == methodNameAdd){
		method = makeAddField(this.elementsType);
	}
	else if (id == methodNameClear){
		method = makeClearMethod();
	}
	else if (id == methodNameIndexOf){
		method = makeIndexOfMethod(this.elementsType);
	}
	else if (id == methodNameRemove){
		method = makeRemoveMethod();
	}
	if (method != null){
		field = new MethodField();
		field.method = method;
		result = field;
	}
	else {
		result = Types.Array.prototype.denote.call(this, id);
	}
	return result;
}

function makeDynamicArray(elementsType/*PType*/){
	var result = null;
	result = new DynamicArray();
	Types.initArray(elementsType, result);
	return result;
}
MethodField.prototype.id = function(){
	return "add";
}
MethodField.prototype.exported = function(){
	return false;
}
MethodField.prototype.type = function(){
	return this.method;
}
MethodField.prototype.asVar = function(){
	return EberonTypes.makeMethod(this.method);
}
AddCallGenerator.prototype.handleArgument = function(e/*PExpression*/){
	if (this.code != ""){
		Errors.raise("method 'add' expects one argument, got many");
	}
	var argCode = Procedure.makeArgumentsCode(this.cx);
	Procedure.checkArgument(e, Types.makeProcedureArgument(this.elementsType, false), 0, argCode, this.cx.types);
	this.code = argCode.result();
	var t = e.type();
	if (t instanceof Types.Array){
		this.code = Cast.cloneArray(t, this.code, this.cx.rtl);
	}
	else if (t instanceof Types.Record){
		this.code = this.cx.rtl.cloneRecord(this.code);
	}
}
AddCallGenerator.prototype.end = function(){
	if (this.code == ""){
		Errors.raise("method 'add' expects one argument, got nothing");
	}
	return Code.makeSimpleExpression("(" + this.code + ")", null);
}
Method.prototype.description = function(){
	return "dynamic array method '" + this.name + "'";
}
MethodAdd.prototype.designatorCode = function(id/*STRING*/){
	return "push";
}
MethodAdd.prototype.callGenerator = function(cx/*PType*/){
	var result = null;
	result = new AddCallGenerator();
	result.cx = cx;
	result.elementsType = this.elementsType;
	return result;
}
MethodClear.prototype.designatorCode = function(id/*STRING*/){
	return "splice";
}
MethodCallClear.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
	Procedure.processArguments(args, this.args, null, cx.types);
	return Code.makeSimpleExpression("(0, Number.MAX_VALUE)", null);
}
MethodCallRemove.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
	var argCode = Procedure.makeArgumentsCode(cx);
	var arg = Procedure.checkSingleArgument(args, this, cx.types, argCode);
	var value = arg.constValue();
	if (value != null && value instanceof Code.IntConst){
		Code.checkIndex(value.value);
	}
	return Code.makeSimpleExpression("(" + argCode.result() + ", 1)", null);
}
MethodCallIndexOf.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
	var argCode = Procedure.makeArgumentsCode(cx);
	var argType = Procedure.checkSingleArgument(args, this, cx.types, argCode).type();
	if (argType instanceof Types.Record || argType instanceof Types.Array){
		Errors.raise("cannot search for element of type '" + argType.description() + "'");
	}
	return Code.makeSimpleExpression("(" + argCode.result() + ")", Types.basic().integer);
}
MethodRemove.prototype.designatorCode = function(id/*STRING*/){
	return "splice";
}
MethodIndexOf.prototype.designatorCode = function(id/*STRING*/){
	return "indexOf";
}
MethodClear.prototype.callGenerator = function(cx/*PType*/){
	var call = null;
	call = new MethodCallClear();
	Procedure.initStdCall(call);
	return Procedure.makeCallGenerator(call, cx);
}
MethodRemove.prototype.callGenerator = function(cx/*PType*/){
	var a = null;
	var call = null;
	call = new MethodCallRemove();
	Procedure.initStdCall(call);
	a = new Types.ProcedureArgument();
	a.type = Types.basic().integer;
	call.args.push(a);
	return Procedure.makeCallGenerator(call, cx);
}
MethodIndexOf.prototype.callGenerator = function(cx/*PType*/){
	var a = null;
	var call = null;
	call = new MethodCallIndexOf();
	Procedure.initStdCall(call);
	a = new Types.ProcedureArgument();
	a.type = this.elementsType;
	call.args.push(a);
	return Procedure.makeCallGenerator(call, cx);
}
exports.DynamicArray = DynamicArray;
exports.makeDynamicArray = makeDynamicArray;
