var RTL$ = require("eberon/eberon_rtl.js");
var ContextDesignator = require("js/ContextDesignator.js");
var ContextHierarchy = require("js/ContextHierarchy.js");
var ContextProcedure = require("js/ContextProcedure.js");
var EberonConstructor = require("js/EberonConstructor.js");
var EberonMap = require("js/EberonMap.js");
var EberonRtl = require("js/EberonRtl.js");
var EberonString = require("js/EberonString.js");
var EberonTypePromotion = require("js/EberonTypePromotion.js");
var Errors = require("js/Errors.js");
var Expression = require("js/Expression.js");
var Object$ = require("js/Object$.js");
var Procedure = require("js/Procedure.js");
var Record = require("js/Record.js");
var TypeId = require("js/TypeId.js");
var Types = require("js/Types.js");
var Variable = require("js/Variable.js");
function Type(){
	ContextDesignator.Type.apply(this, arguments);
	this.procCall = null;
}
RTL$.extend(Type, ContextDesignator.Type);
RTL$.extend(MapElementVariable, Types.Variable);
RTL$.extend(ResultVariable, Types.Variable);
function TypeNarrowVariableBase(){
	Types.Variable.call(this);
}
RTL$.extend(TypeNarrowVariableBase, Types.Variable);
RTL$.extend(TypeNarrowVariable, TypeNarrowVariableBase);
RTL$.extend(DereferencedTypeNarrowVariable, TypeNarrowVariableBase);
function SelfAsPointer(){
	Types.Id.call(this);
}
RTL$.extend(SelfAsPointer, Types.Id);
RTL$.extend(OperatorNewMsg, ContextHierarchy.Message);
RTL$.extend(PromoteTypeMsg, ContextHierarchy.Message);
RTL$.extend(TransferPromotedTypesMsg, ContextHierarchy.Message);
function GetMethodSelfMsg(){
	ContextHierarchy.Message.call(this);
}
RTL$.extend(GetMethodSelfMsg, ContextHierarchy.Message);
function GetSelfAsPointerMsg(){
	ContextHierarchy.Message.call(this);
}
RTL$.extend(GetSelfAsPointerMsg, ContextHierarchy.Message);
function GetMethodSuperMsg(){
	ContextHierarchy.Message.call(this);
}
RTL$.extend(GetMethodSuperMsg, ContextHierarchy.Message);
RTL$.extend(SuperMethodInfo, Object$.Type);
var getMethodSelfMsg = new GetMethodSelfMsg();
var getSelfAsPointerMsg = new GetSelfAsPointerMsg();
var getMethodSuperMsg = new GetMethodSuperMsg();

function checkMapKeyType(type/*PType*/){
	if (type != EberonString.string() && !Types.isString(type)){
		Errors.raise("invalid MAP key type: STRING or string literal or ARRAY OF CHAR expected, got '" + type.description() + "'");
	}
}
Type.prototype.doCheckIndexType = function(type/*PType*/){
	if (this.currentType instanceof EberonMap.Type){
		checkMapKeyType(type);
	}
	else {
		ContextDesignator.Type.prototype.doCheckIndexType.call(this, type);
	}
};
Type.prototype.doIndexSequence = function(info/*PId*/, code/*STRING*/, indexCode/*STRING*/){
	var result = null;
	var currentType = this.currentType;
	if (currentType == EberonString.string()){
		result = new ContextDesignator.Index(0, Types.basic().ch, EberonString.makeElementVariable(), ContextDesignator.stringIndexCode(this), "", "");
	}
	else if (currentType instanceof EberonMap.Type){
		var indexType = currentType.valueType;
		var rtl = RTL$.typeGuard(this.root().language().rtl, EberonRtl.Type);
		var rval = rtl.getMappedValue(code, indexCode);
		var lval = code + "[" + indexCode + "]";
		var var$ = new MapElementVariable(indexType, RTL$.typeGuard(info, Types.Variable).isReadOnly(), rval);
		result = new ContextDesignator.Index(0, indexType, var$, rval, lval, "");
	}
	else {
		result = ContextDesignator.Type.prototype.doIndexSequence.call(this, info, code, indexCode);
	}
	return result;
};
Type.prototype.doMakeDerefVar = function(info/*PId*/){
	var result = null;
	if (info instanceof TypeNarrowVariable){
		result = new DereferencedTypeNarrowVariable(info);
	}
	else {
		result = ContextDesignator.Type.prototype.doMakeDerefVar.call(this, info);
	}
	return result;
};

function beginCall(d/*PType*/){
	var type = d.currentType;
	var info = d.info;
	if (info instanceof TypeId.Type && type instanceof Types.Record){
		var cx = ContextHierarchy.makeLanguageContext(d);
		d.procCall = EberonConstructor.makeConstructorCall(info, cx, false);
		ContextDesignator.discardCode(d);
	}
	else {
		d.procCall = ContextProcedure.makeCall(d, type, info);
	}
}

function endCall(d/*VAR Type*/){
	var e = d.procCall.end();
	ContextDesignator.advance(d, e.type(), new ResultVariable(e), e.code(), "", false);
	d.procCall = null;
}

function breakTypePromotion(msg/*VAR Message*/){
	var result = false;
	if (msg instanceof TransferPromotedTypesMsg){
		msg.promotion.clear();
		result = true;
	}
	else if (msg instanceof PromoteTypeMsg){
		result = true;
	}
	return result;
}
Type.prototype.handleMessage = function(msg/*VAR Message*/){
	var result = null;
	if (msg instanceof ContextDesignator.BeginCallMsg){
		beginCall(this);
	}
	else if (msg instanceof ContextDesignator.EndCallMsg){
		endCall(this);
	}
	else if (msg instanceof OperatorNewMsg){
		var e = msg.expression;
		ContextDesignator.advance(this, e.type(), new ResultVariable(e), e.code(), "", false);
	}
	else if (!breakTypePromotion(msg)){
		result = ContextDesignator.Type.prototype.handleMessage.call(this, msg);
	}
	return result;
};
Type.prototype.handleExpression = function(e/*PType*/){
	if (this.procCall != null){
		this.procCall.handleArgument(e);
	}
	else {
		ContextDesignator.Type.prototype.handleExpression.call(this, e);
	}
};
Type.prototype.handleLiteral = function(s/*STRING*/){
	if (s == "SELF"){
		var type = RTL$.typeGuard(this.handleMessage(getMethodSelfMsg), Types.StorageType);
		var info = new Variable.DeclaredVariable("this", type);
		ContextDesignator.advance(this, type, info, "this", "", false);
	}
	else if (s == "POINTER"){
		var type = RTL$.typeGuard(this.handleMessage(getSelfAsPointerMsg), Types.StorageType);
		var typeId = new TypeId.Type(type);
		var pointerType = new Record.Pointer("", typeId);
		ContextDesignator.advance(this, pointerType, new SelfAsPointer(), "", "", false);
	}
	else if (s == "SUPER"){
		var ms = RTL$.typeGuard(this.handleMessage(getMethodSuperMsg), SuperMethodInfo);
		ContextDesignator.advance(this, ms.info.type, ms.info, ms.code, "", false);
	}
	else {
		ContextDesignator.Type.prototype.handleLiteral.call(this, s);
	}
};
function MapElementVariable(type/*PStorageType*/, readOnly/*BOOLEAN*/, code/*STRING*/){
	Types.Variable.call(this);
	this.elementType = type;
	this.readOnly = readOnly;
	this.code = code;
}
MapElementVariable.prototype.type = function(){
	return this.elementType;
};
MapElementVariable.prototype.isReference = function(){
	return false;
};
MapElementVariable.prototype.isReadOnly = function(){
	return this.readOnly;
};
MapElementVariable.prototype.referenceCode = function(){
	if (this.elementType.isScalar()){
		Errors.raise("cannot reference map element of type '" + this.elementType.description() + "'");
	}
	return this.code;
};
MapElementVariable.prototype.idType = function(){
	var result = '';
	result = "MAP's element";
	if (this.readOnly){
		result = "read-only " + result;
	}
	return result;
};
function ResultVariable(e/*PType*/){
	Types.Variable.call(this);
	this.expression = e;
}
ResultVariable.prototype.type = function(){
	return RTL$.typeGuard(this.expression.type(), Types.StorageType);
};
ResultVariable.prototype.isReference = function(){
	return false;
};
ResultVariable.prototype.referenceCode = function(){
	return "";
};
ResultVariable.prototype.isReadOnly = function(){
	return true;
};
ResultVariable.prototype.idType = function(){
	var result = '';
	if (this.expression.type() != null){
		result = "result";
	}
	else {
		result = "statement";
	}
	return "procedure call " + result;
};
function TypeNarrowVariable(type/*PStorageType*/, isRef/*BOOLEAN*/, isReadOnly/*BOOLEAN*/, code/*STRING*/){
	TypeNarrowVariableBase.call(this);
	this.mType = type;
	this.isRef = isRef;
	this.readOnly = isReadOnly;
	this.code = code;
}
TypeNarrowVariable.prototype.type = function(){
	return this.mType;
};
TypeNarrowVariable.prototype.setType = function(type/*PStorageType*/){
	this.mType = type;
};
TypeNarrowVariable.prototype.isReference = function(){
	return this.isRef;
};
TypeNarrowVariable.prototype.isReadOnly = function(){
	return this.readOnly;
};
TypeNarrowVariable.prototype.referenceCode = function(){
	return this.code;
};
TypeNarrowVariable.prototype.idType = function(){
	var result = '';
	if (this.readOnly){
		result = "non-VAR formal parameter";
	}
	else {
		result = TypeNarrowVariableBase.prototype.idType.call(this);
	}
	return result;
};
function DereferencedTypeNarrowVariable(var$/*PTypeNarrowVariable*/){
	TypeNarrowVariableBase.call(this);
	this.var$ = var$;
}
DereferencedTypeNarrowVariable.prototype.type = function(){
	return this.var$.type();
};
DereferencedTypeNarrowVariable.prototype.setType = function(type/*PStorageType*/){
	this.var$.setType(type);
};
DereferencedTypeNarrowVariable.prototype.isReference = function(){
	return true;
};
DereferencedTypeNarrowVariable.prototype.isReadOnly = function(){
	return false;
};
DereferencedTypeNarrowVariable.prototype.referenceCode = function(){
	return this.var$.code;
};
SelfAsPointer.prototype.idType = function(){
	return "SELF(POINTER)";
};
function OperatorNewMsg(e/*PType*/){
	ContextHierarchy.Message.call(this);
	this.expression = e;
}
function PromoteTypeMsg(info/*PId*/, type/*PType*/){
	ContextHierarchy.Message.call(this);
	this.info = info;
	this.type = type;
}
function TransferPromotedTypesMsg(p/*PCombined*/){
	ContextHierarchy.Message.call(this);
	this.promotion = p;
}
function SuperMethodInfo(info/*PProcedureId*/, code/*STRING*/){
	Object$.Type.call(this);
	this.info = info;
	this.code = code;
}
exports.Type = Type;
exports.ResultVariable = ResultVariable;
exports.TypeNarrowVariableBase = TypeNarrowVariableBase;
exports.TypeNarrowVariable = TypeNarrowVariable;
exports.OperatorNewMsg = OperatorNewMsg;
exports.PromoteTypeMsg = PromoteTypeMsg;
exports.TransferPromotedTypesMsg = TransferPromotedTypesMsg;
exports.GetMethodSelfMsg = GetMethodSelfMsg;
exports.GetSelfAsPointerMsg = GetSelfAsPointerMsg;
exports.GetMethodSuperMsg = GetMethodSuperMsg;
exports.SuperMethodInfo = SuperMethodInfo;
exports.checkMapKeyType = checkMapKeyType;
exports.breakTypePromotion = breakTypePromotion;
