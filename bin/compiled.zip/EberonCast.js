var RTL$ = require("rtl.js");
var Cast = require("js/Cast.js");
var EberonString = require("js/EberonString.js");
var Types = require("js/Types.js");

function implicit(from/*PType*/, to/*PType*/, toVar/*BOOLEAN*/, ops/*Operations*/, op/*VAR PCastOp*/){
	var result = 0;
	if (from == EberonString.string() && to instanceof Types.Array && Types.arrayLength(RTL$.typeGuard(to, Types.Array)) == Types.openArrayLength || Types.isString(from) && to == EberonString.string()){
		if (toVar){
			result = Cast.errVarParameter;
		}
		else {
			result = Cast.errNo;
		}
	}
	else {
		result = Cast.implicit(from, to, toVar, ops, op);
	}
	return result;
}
exports.implicit = implicit;
