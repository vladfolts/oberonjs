var RTL$ = require("rtl.js");
var Cast = require("js/Cast.js");
var EberonString = require("js/EberonString.js");
var EberonTypes = require("js/EberonTypes.js");
var Types = require("js/Types.js");

function isOpenCharArray(type/*PType*/){
	var result = false;
	if (type instanceof Types.Array){
		result = Types.arrayElementsType(type) == Types.basic().ch && Types.arrayLength(type) == Types.openArrayLength;
	}
	return result;
}

function implicit(from/*PType*/, to/*PType*/, toVar/*BOOLEAN*/, ops/*Operations*/, op/*VAR PCastOp*/){
	var result = 0;
	if (from == EberonString.string() && (to instanceof Types.String || isOpenCharArray(to)) || from instanceof Types.String && to == EberonString.string()){
		if (toVar){
			result = Cast.errVarParameter;
		}
		else {
			result = Cast.errNo;
		}
	}
	else if (from instanceof Types.Array && EberonTypes.isDynamicArray(to) && Cast.areTypesExactlyMatch()(Types.arrayElementsType(from), Types.arrayElementsType(RTL$.typeGuard(to, Types.Array)))){
		if (toVar && !EberonTypes.isDynamicArray(from)){
			result = Cast.errVarParameter;
		}
		else {
			result = Cast.errNo;
		}
	}
	else {
		result = Cast.implicit(from, to, toVar, ops, op);
	}
	return result;
}
exports.implicit = implicit;
