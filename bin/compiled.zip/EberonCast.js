var Cast = require("js/Cast.js");
var Code = require("js/Code.js");
var EberonString = require("js/EberonString.js");
var EberonDynamicArray = require("js/EberonDynamicArray.js");
var OberonRtl = require("js/OberonRtl.js");
var Types = require("js/Types.js");
var CastOpToDynamicArray = Cast.CastOp.extend({
	init: function CastOpToDynamicArray(){
		Cast.CastOp.prototype.init.call(this);
	}
});
var castOpToDynamicArray = null;
CastOpToDynamicArray.prototype.make = function(rtl/*PType*/, e/*PExpression*/){
	return Code.makeSimpleExpression(rtl.clone(e.code()), null);
}

function isOpenCharArray(type/*PType*/){
	return type instanceof Types.OpenArray && Types.arrayElementsType(type) == Types.basic().ch;
}

function implicit(from/*PType*/, to/*PType*/, toVar/*BOOLEAN*/, ops/*Operations*/, op/*VAR PCastOp*/){
	var result = 0;
	if (from == EberonString.string() && (to instanceof Types.String || isOpenCharArray(to)) || from instanceof Types.String && to == EberonString.string()){
		if (toVar){
			result = Cast.errVarParameter;
		}
		else {
			result = Cast.errNo;
		}
	}
	else if (from instanceof Types.Array && to instanceof EberonDynamicArray.DynamicArray && Cast.areTypesExactlyMatch()(Types.arrayElementsType(from), Types.arrayElementsType(to))){
		if (toVar && !(from instanceof EberonDynamicArray.DynamicArray)){
			result = Cast.errVarParameter;
		}
		else {
			op.set(castOpToDynamicArray);
			result = Cast.errNo;
		}
	}
	else {
		result = Cast.implicit(from, to, toVar, ops, op);
	}
	return result;
}
castOpToDynamicArray = new CastOpToDynamicArray();
exports.implicit = implicit;
