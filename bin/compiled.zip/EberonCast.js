var RTL$ = require("rtl.js");
var Cast = require("js/Cast.js");
var Code = require("js/Code.js");
var EberonString = require("js/EberonString.js");
var EberonDynamicArray = require("js/EberonDynamicArray.js");
var OberonRtl = require("js/OberonRtl.js");
var Types = require("js/Types.js");
var CastOpToDynamicArray = Cast.CastOp.extend({
	init: function CastOpToDynamicArray(){
		Cast.CastOp.prototype.init.call(this);
	}
});
var castOpToDynamicArray = null;
CastOpToDynamicArray.prototype.make = function(rtl/*PType*/, e/*PExpression*/){
	return Code.makeSimpleExpression(Cast.cloneArray(RTL$.typeGuard(e.type(), Types.Array), e.code(), rtl), null);
}

function copyArray(t/*Array*/, leftCode/*STRING*/, rightCode/*STRING*/, rtl/*Type*/){
	var result = '';
	if (Types.isScalar(Types.arrayElementsType(t))){
		result = "Array.prototype.splice.apply(" + leftCode + ", [0, Number.MAX_VALUE].concat(" + rightCode + "))";
	}
	else if (Types.isScalar(Types.arrayBaseElementsType(t))){
		result = rtl.copyArrayOfScalars(rightCode, leftCode);
	}
	else {
		result = rtl.copyArrayOfRecords(rightCode, leftCode);
	}
	return result;
}
CastOpToDynamicArray.prototype.assign = function(rtl/*PType*/, left/*PExpression*/, right/*PExpression*/){
	return copyArray(RTL$.typeGuard(left.type(), Types.Array), left.code(), right.code(), rtl);
}

function isOpenCharArray(type/*PType*/){
	return type instanceof Types.OpenArray && Types.arrayElementsType(type) == Types.basic().ch;
}

function areTypesExactlyMatch(t1/*PType*/, t2/*PType*/){
	var result = false;
	if (t1 instanceof EberonDynamicArray.DynamicArray && t2 instanceof EberonDynamicArray.DynamicArray){
		result = areTypesExactlyMatch(Types.arrayElementsType(t1), Types.arrayElementsType(t2));
	}
	else {
		result = Cast.areTypesExactlyMatch()(t1, t2);
	}
	return result;
}

function implicit(from/*PType*/, to/*PType*/, toVar/*BOOLEAN*/, ops/*Operations*/, op/*VAR PCastOp*/){
	var result = 0;
	if (from == EberonString.string() && (to instanceof Types.String || isOpenCharArray(to)) || from instanceof Types.String && to == EberonString.string()){
		if (toVar){
			result = Cast.errVarParameter;
		}
		else {
			op.set(Cast.doNothing());
			result = Cast.errNo;
		}
	}
	else if (from instanceof Types.Array && to instanceof EberonDynamicArray.DynamicArray && areTypesExactlyMatch(Types.arrayElementsType(from), Types.arrayElementsType(to))){
		if (toVar){
			if (!(from instanceof EberonDynamicArray.DynamicArray)){
				result = Cast.errVarParameter;
			}
			else {
				op.set(Cast.doNothing());
				result = Cast.errNo;
			}
		}
		else {
			op.set(castOpToDynamicArray);
			result = Cast.errNo;
		}
	}
	else {
		result = Cast.implicit(from, to, toVar, ops, op);
	}
	return result;
}
castOpToDynamicArray = new CastOpToDynamicArray();
exports.implicit = implicit;
