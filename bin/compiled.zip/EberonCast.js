var Cast = require("js/Cast.js");
var EberonString = require("js/EberonString.js");
var EberonTypes = require("js/EberonTypes.js");
var Types = require("js/Types.js");

function isOpenCharArray(type/*PType*/){
	return type instanceof Types.OpenArray && Types.arrayElementsType(type) == Types.basic().ch;
}

function implicit(from/*PType*/, to/*PType*/, toVar/*BOOLEAN*/, ops/*Operations*/, op/*VAR PCastOp*/){
	var result = 0;
	if (from == EberonString.string() && (to instanceof Types.String || isOpenCharArray(to)) || from instanceof Types.String && to == EberonString.string()){
		if (toVar){
			result = Cast.errVarParameter;
		}
		else {
			result = Cast.errNo;
		}
	}
	else if (from instanceof Types.Array && to instanceof EberonTypes.DynamicArray && Cast.areTypesExactlyMatch()(Types.arrayElementsType(from), Types.arrayElementsType(to))){
		if (toVar && !(from instanceof EberonTypes.DynamicArray)){
			result = Cast.errVarParameter;
		}
		else {
			result = Cast.errNo;
		}
	}
	else {
		result = Cast.implicit(from, to, toVar, ops, op);
	}
	return result;
}
exports.implicit = implicit;
