var JS = global;

function format(f/*STRING*/, args/*ARRAY OF JS.var*/){
	var result = '';
	result = f.replace(/{(\d+)}/g, function(match, number){return args[number];});;
	return result;
}

function format1(f/*STRING*/, a1/*JS.var*/){
	var result = '';
	result = format(f, [a1]);;
	return result;
}

function format2(f/*STRING*/, a1/*JS.var*/, a2/*JS.var*/){
	var result = '';
	result = format(f, [a1, a2]);;
	return result;
}

function format3(f/*STRING*/, a1/*JS.var*/, a2/*JS.var*/, a3/*JS.var*/){
	var result = '';
	result = format(f, [a1, a2, a3]);;
	return result;
}
exports.format1 = format1;
exports.format2 = format2;
exports.format3 = format3;
