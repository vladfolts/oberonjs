var $scope = "Object";
function Type(){
}
Type.prototype.$scope = $scope;
exports.Type = Type;
