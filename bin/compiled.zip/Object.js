var RTL$ = require("rtl.js");
var Type = RTL$.extend({
	init: function Type(){
	}
});
exports.Type = Type;
