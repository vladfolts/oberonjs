var RTL$ = require("eberon/eberon_rtl.js");
var Context = require("js/Context.js");
var LanguageContext = require("js/LanguageContext.js");
var Procedure = require("js/Procedure.js");
var Types = require("js/Types.js");
RTL$.extend(MethodType, Procedure.Std);
function MethodVariable(){
	Types.ProcedureId.apply(this, arguments);
}
RTL$.extend(MethodVariable, Types.ProcedureId);
RTL$.extend(MethodField, Types.Field);
MethodType.prototype.designatorCode = function(id/*STRING*/){
	return id;
}
MethodType.prototype.procType = function(){
	return this.type;
}
MethodType.prototype.description = function(){
	return "method '" + this.name + "'";
}
MethodType.prototype.callGenerator = function(cx/*PType*/){
	return this.call(cx, this.type);
}
function MethodType(id/*STRING*/, t/*PDefinedProcedure*/, call/*CallGenerator*/){
	Procedure.Std.call(this, id, null);
	this.type = null;
	this.call = null;
	this.type = t;
	this.call = call;
}
MethodVariable.prototype.idType = function(){
	return "method";
}
function MethodField(method/*PMethod*/){
	Types.Field.call(this);
	this.method = method;
}
MethodField.prototype.id = function(){
	return this.method.name;
}
MethodField.prototype.exported = function(){
	return false;
}
MethodField.prototype.type = function(){
	return this.method;
}
MethodField.prototype.asVar = function(isReadOnly/*BOOLEAN*/, cx/*Type*/){
	return new MethodVariable(this.method);
}
MethodField.prototype.designatorCode = function(leadCode/*STRING*/, cx/*Type*/){
	return new Types.FieldCode(leadCode + "." + Types.mangleField(this.method.name, this.method), "", "");
}
exports.MethodType = MethodType;
exports.MethodVariable = MethodVariable;
exports.MethodField = MethodField;
