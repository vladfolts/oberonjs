var Types = require("js/Types.js");
var dynamicArrayLength = Types.openArrayLength - 1 | 0;
var Array = Types.Array.extend({
	init: function Array(){
		Types.Array.prototype.init.call(this);
	}
});

function isDynamicArray(type/*VAR Type*/){
	return type instanceof Types.Array && Types.arrayLength(type) == dynamicArrayLength;
}

function arrayDimensionDescription(dim/*INTEGER*/){
	var result = '';
	if (dim == dynamicArrayLength){
		result = "*";
	}
	else {
		result = Types.arrayDimensionDescription(dim);
	}
	return result;
}
Array.prototype.description = function(){
	return Types.arrayDescription(this, arrayDimensionDescription);
}

function makeArray(initializer/*STRING*/, elementsType/*PType*/, len/*INTEGER*/){
	var result = null;
	result = new Array();
	Types.initArray(initializer, elementsType, len, result);
	return result;
}
exports.dynamicArrayLength = dynamicArrayLength;
exports.isDynamicArray = isDynamicArray;
exports.arrayDimensionDescription = arrayDimensionDescription;
exports.makeArray = makeArray;
