var Code = require("js/Code.js");
var Context = require("js/Context.js");
var JsArray = require("js/JsArray.js");
var LanguageContext = require("js/LanguageContext.js");
var Procedure = require("js/Procedure.js");
var Types = require("js/Types.js");
var MethodType = Procedure.Std.extend({
	init: function MethodType(){
		Procedure.Std.prototype.init.call(this);
		this.type = null;
		this.call = null;
	}
});
var MethodVariable = Types.Variable.extend({
	init: function MethodVariable(){
		Types.Variable.prototype.init.call(this);
		this.mType = null;
	}
});
var DynamicArray = Types.Array.extend({
	init: function DynamicArray(){
		Types.Array.prototype.init.call(this);
	}
});
var DynamicArrayMethodField = Types.Field.extend({
	init: function DynamicArrayMethodField(){
		Types.Field.prototype.init.call(this);
	}
});
var DynamicArrayAddCallGenerator = Procedure.CallGenerator.extend({
	init: function DynamicArrayAddCallGenerator(){
		Procedure.CallGenerator.prototype.init.call(this);
		this.arg = null;
	}
});
var DynamicArrayMethod = Procedure.Std.extend({
	init: function DynamicArrayMethod(){
		Procedure.Std.prototype.init.call(this);
	}
});
var dynamicArrayAdd = null;
var dynamicArrayAddMethod = null;

function arrayDimensionDescription(a/*VAR Array*/){
	var result = '';
	if (a instanceof DynamicArray){
		result = "*";
	}
	else {
		result = Types.arrayDimensionDescription(a);
	}
	return result;
}
DynamicArray.prototype.initializer = function(cx/*Type*/, forNew/*BOOLEAN*/){
	return "[]";
}
DynamicArray.prototype.description = function(){
	return Types.arrayDescription(this, arrayDimensionDescription);
}
DynamicArray.prototype.denote = function(id/*STRING*/){
	return dynamicArrayAdd;
}
MethodType.prototype.designatorCode = function(id/*STRING*/){
	return id;
}
MethodType.prototype.procType = function(){
	return this.type;
}
MethodType.prototype.args = function(){
	return this.type.args();
}
MethodType.prototype.result = function(){
	return this.type.result();
}
MethodType.prototype.description = function(){
	return "method " + this.name;
}
MethodType.prototype.procDescription = function(){
	return this.type.description();
}
MethodType.prototype.callGenerator = function(cx/*PType*/){
	return this.call(cx, this.type);
}

function makeMethodType(id/*STRING*/, t/*PDefinedProcedure*/, call/*CallGenerator*/){
	var result = null;
	result = new MethodType();
	result.name = id;
	result.type = t;
	result.call = call;
	return result;
}
MethodVariable.prototype.type = function(){
	return this.mType;
}
MethodVariable.prototype.isReadOnly = function(){
	return true;
}
MethodVariable.prototype.idType = function(){
	return "method";
}
MethodVariable.prototype.isReference = function(){
	return false;
}

function makeMethodVariable(type/*PType*/){
	var result = null;
	result = new MethodVariable();
	result.mType = type;
	return result;
}

function makeDynamicArray(elementsType/*PType*/){
	var result = null;
	result = new DynamicArray();
	Types.initArray(elementsType, result);
	return result;
}
DynamicArrayMethodField.prototype.id = function(){
	return "add";
}
DynamicArrayMethodField.prototype.exported = function(){
	return false;
}
DynamicArrayMethodField.prototype.type = function(){
	return dynamicArrayAddMethod;
}
DynamicArrayMethodField.prototype.asVar = function(){
	return makeMethodVariable(dynamicArrayAddMethod);
}
DynamicArrayAddCallGenerator.prototype.handleArgument = function(e/*PExpression*/){
	this.arg = e;
}
DynamicArrayAddCallGenerator.prototype.end = function(){
	return Code.makeSimpleExpression("(" + this.arg.code() + ")", null);
}
DynamicArrayMethod.prototype.designatorCode = function(id/*STRING*/){
	return "push";
}
DynamicArrayMethod.prototype.callGenerator = function(cx/*PType*/){
	var result = null;
	result = new DynamicArrayAddCallGenerator();
	return result;
}
dynamicArrayAddMethod = new DynamicArrayMethod();
dynamicArrayAdd = new DynamicArrayMethodField();
exports.MethodType = MethodType;
exports.MethodVariable = MethodVariable;
exports.DynamicArray = DynamicArray;
exports.arrayDimensionDescription = arrayDimensionDescription;
exports.makeMethodType = makeMethodType;
exports.makeMethodVariable = makeMethodVariable;
exports.makeDynamicArray = makeDynamicArray;
