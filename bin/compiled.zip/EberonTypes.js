var Context = require("js/Context.js");
var JsArray = require("js/JsArray.js");
var LanguageContext = require("js/LanguageContext.js");
var Procedure = require("js/Procedure.js");
var Types = require("js/Types.js");
var MethodType = Procedure.Std.extend({
	init: function MethodType(){
		Procedure.Std.prototype.init.call(this);
		this.type = null;
		this.call = null;
	}
});
var DynamicArray = Types.Array.extend({
	init: function DynamicArray(){
		Types.Array.prototype.init.call(this);
	}
});
var DynamicArrayMethod = Types.Field.extend({
	init: function DynamicArrayMethod(){
		Types.Field.prototype.init.call(this);
	}
});
var dynamicArrayAdd = null;
var dynamicArrayAddType = null;

function arrayDimensionDescription(a/*VAR Array*/){
	var result = '';
	if (a instanceof DynamicArray){
		result = "*";
	}
	else {
		result = Types.arrayDimensionDescription(a);
	}
	return result;
}
DynamicArray.prototype.initializer = function(cx/*Type*/, forNew/*BOOLEAN*/){
	return "[]";
}
DynamicArray.prototype.description = function(){
	return Types.arrayDescription(this, arrayDimensionDescription);
}
DynamicArray.prototype.denote = function(id/*STRING*/){
	return dynamicArrayAdd;
}
MethodType.prototype.procType = function(){
	return this.type;
}
MethodType.prototype.args = function(){
	return this.type.args();
}
MethodType.prototype.result = function(){
	return this.type.result();
}
MethodType.prototype.description = function(){
	return "method " + this.name;
}
MethodType.prototype.procDescription = function(){
	return this.type.description();
}
MethodType.prototype.callGenerator = function(cx/*PType*/, id/*STRING*/){
	return this.call(cx, id, this.type);
}

function makeMethodType(id/*STRING*/, t/*PDefinedProcedure*/, call/*CallGenerator*/){
	var result = null;
	result = new MethodType();
	result.name = id;
	result.type = t;
	result.call = call;
	return result;
}

function makeDynamicArray(elementsType/*PType*/){
	var result = null;
	result = new DynamicArray();
	Types.initArray(elementsType, result);
	return result;
}
DynamicArrayMethod.prototype.id = function(){
	return "add";
}
DynamicArrayMethod.prototype.exported = function(){
	return false;
}
DynamicArrayMethod.prototype.type = function(){
	return dynamicArrayAddType;
}
DynamicArrayMethod.prototype.asVar = function(){
	return null;
}
dynamicArrayAddType = Procedure.makeStd("add", null);
dynamicArrayAdd = new DynamicArrayMethod();
exports.MethodType = MethodType;
exports.DynamicArray = DynamicArray;
exports.arrayDimensionDescription = arrayDimensionDescription;
exports.makeMethodType = makeMethodType;
exports.makeDynamicArray = makeDynamicArray;
