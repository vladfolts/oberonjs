var Code = require("js/Code.js");
var Context = require("js/Context.js");
var Errors = require("js/Errors.js");
var JsArray = require("js/JsArray.js");
var Language = require("js/Language.js");
var LanguageContext = require("js/LanguageContext.js");
var Procedure = require("js/Procedure.js");
var Types = require("js/Types.js");
var MethodType = Procedure.Std.extend({
	init: function MethodType(){
		Procedure.Std.prototype.init.call(this);
		this.type = null;
		this.call = null;
	}
});
var MethodVariable = Types.ProcedureId.extend({
	init: function MethodVariable(){
		Types.ProcedureId.prototype.init.call(this);
	}
});
var DynamicArray = Types.Array.extend({
	init: function DynamicArray(){
		Types.Array.prototype.init.call(this);
	}
});
var DynamicArrayMethodField = Types.Field.extend({
	init: function DynamicArrayMethodField(){
		Types.Field.prototype.init.call(this);
		this.method = null;
	}
});
var DynamicArrayAddCallGenerator = Procedure.CallGenerator.extend({
	init: function DynamicArrayAddCallGenerator(){
		Procedure.CallGenerator.prototype.init.call(this);
		this.cx = null;
		this.elementsType = null;
		this.argCode = null;
	}
});
var DynamicArrayMethod = Procedure.Std.extend({
	init: function DynamicArrayMethod(){
		Procedure.Std.prototype.init.call(this);
		this.elementsType = null;
	}
});

function arrayDimensionDescription(a/*VAR Array*/){
	var result = '';
	if (a instanceof DynamicArray){
		result = "*";
	}
	else {
		result = Types.arrayDimensionDescription(a);
	}
	return result;
}
DynamicArray.prototype.initializer = function(cx/*Type*/, forNew/*BOOLEAN*/){
	return "[]";
}
DynamicArray.prototype.description = function(){
	return Types.arrayDescription(this, arrayDimensionDescription);
}
DynamicArray.prototype.denote = function(id/*STRING*/){
	var result = null;
	result = new DynamicArrayMethodField();
	result.method = new DynamicArrayMethod();
	result.method.name = "add";
	result.method.elementsType = this.elementsType;
	return result;
}
MethodType.prototype.designatorCode = function(id/*STRING*/){
	return id;
}
MethodType.prototype.procType = function(){
	return this.type;
}
MethodType.prototype.args = function(){
	return this.type.args();
}
MethodType.prototype.result = function(){
	return this.type.result();
}
MethodType.prototype.description = function(){
	return "method '" + this.name + "'";
}
MethodType.prototype.procDescription = function(){
	return this.type.description();
}
MethodType.prototype.callGenerator = function(cx/*PType*/){
	return this.call(cx, this.type);
}

function makeMethodType(id/*STRING*/, t/*PDefinedProcedure*/, call/*CallGenerator*/){
	var result = null;
	result = new MethodType();
	result.name = id;
	result.type = t;
	result.call = call;
	return result;
}
MethodVariable.prototype.idType = function(){
	return "method";
}

function makeMethod(type/*PType*/){
	var result = null;
	result = new MethodVariable();
	result.type = type;
	return result;
}

function makeDynamicArray(elementsType/*PType*/){
	var result = null;
	result = new DynamicArray();
	Types.initArray(elementsType, result);
	return result;
}
DynamicArrayMethodField.prototype.id = function(){
	return "add";
}
DynamicArrayMethodField.prototype.exported = function(){
	return false;
}
DynamicArrayMethodField.prototype.type = function(){
	return this.method;
}
DynamicArrayMethodField.prototype.asVar = function(){
	return makeMethod(this.method);
}
DynamicArrayAddCallGenerator.prototype.handleArgument = function(e/*PExpression*/){
	if (this.argCode != null){
		Errors.raise("method 'add' expects one argument, got many");
	}
	this.argCode = Procedure.makeArgumentsCode(this.cx);
	Procedure.checkArgument(e, Types.makeProcedureArgument(this.elementsType, false), 0, this.argCode, this.cx.types);
}
DynamicArrayAddCallGenerator.prototype.end = function(){
	if (this.argCode == null){
		Errors.raise("method 'add' expects one argument, got nothing");
	}
	return Code.makeSimpleExpression("(" + this.argCode.result() + ")", null);
}
DynamicArrayMethod.prototype.description = function(){
	return "dynamic array method '" + this.name + "'";
}
DynamicArrayMethod.prototype.designatorCode = function(id/*STRING*/){
	return "push";
}
DynamicArrayMethod.prototype.callGenerator = function(cx/*PType*/){
	var result = null;
	result = new DynamicArrayAddCallGenerator();
	result.cx = cx;
	result.elementsType = this.elementsType;
	return result;
}
exports.MethodType = MethodType;
exports.MethodVariable = MethodVariable;
exports.DynamicArray = DynamicArray;
exports.arrayDimensionDescription = arrayDimensionDescription;
exports.makeMethodType = makeMethodType;
exports.makeMethod = makeMethod;
exports.makeDynamicArray = makeDynamicArray;
