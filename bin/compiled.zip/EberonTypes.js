var RTL$ = require("rtl.js");
var LanguageContext = require("js/LanguageContext.js");
var Procedure = require("js/Procedure.js");
var Types = require("js/Types.js");
function MethodType(){
	Procedure.Std.call(this);
	this.type = null;
	this.call = null;
}
RTL$.extend(MethodType, Procedure.Std);
function MethodVariable(){
	Types.ProcedureId.call(this);
}
RTL$.extend(MethodVariable, Types.ProcedureId);
MethodType.prototype.designatorCode = function(id/*STRING*/){
	return id;
}
MethodType.prototype.procType = function(){
	return this.type;
}
MethodType.prototype.description = function(){
	return "method '" + this.name + "'";
}
MethodType.prototype.callGenerator = function(cx/*PType*/){
	return this.call(cx, this.type);
}

function makeMethodType(id/*STRING*/, t/*PDefinedProcedure*/, call/*CallGenerator*/){
	var result = null;
	result = new MethodType();
	result.name = id;
	result.type = t;
	result.call = call;
	return result;
}
MethodVariable.prototype.idType = function(){
	return "method";
}

function makeMethod(type/*PType*/){
	var result = null;
	result = new MethodVariable();
	result.type = type;
	return result;
}
exports.MethodType = MethodType;
exports.MethodVariable = MethodVariable;
exports.makeMethodType = makeMethodType;
exports.makeMethod = makeMethod;
