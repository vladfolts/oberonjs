var Context = require("js/Context.js");
var Types = require("js/Types.js");
var DynamicArray = Types.Array.extend({
	init: function DynamicArray(){
		Types.Array.prototype.init.call(this);
	}
});

function arrayDimensionDescription(a/*VAR Array*/){
	var result = '';
	if (a instanceof DynamicArray){
		result = "*";
	}
	else {
		result = Types.arrayDimensionDescription(a);
	}
	return result;
}
DynamicArray.prototype.initializer = function(cx/*Type*/, forNew/*BOOLEAN*/){
	return "[]";
}
DynamicArray.prototype.description = function(){
	return Types.arrayDescription(this, arrayDimensionDescription);
}

function makeDynamicArray(elementsType/*PType*/){
	var result = null;
	result = new DynamicArray();
	Types.initArray(elementsType, result);
	return result;
}
exports.DynamicArray = DynamicArray;
exports.arrayDimensionDescription = arrayDimensionDescription;
exports.makeDynamicArray = makeDynamicArray;
