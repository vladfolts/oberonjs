var RTL$ = require("rtl.js");
var LanguageContext = require("js/LanguageContext.js");
var Procedure = require("js/Procedure.js");
var Types = require("js/Types.js");
RTL$.extend(MethodType, Procedure.Std);
function MethodVariable(){
	Types.ProcedureId.apply(this, arguments);
}
RTL$.extend(MethodVariable, Types.ProcedureId);
MethodType.prototype.designatorCode = function(id/*STRING*/){
	return id;
}
MethodType.prototype.procType = function(){
	return this.type;
}
MethodType.prototype.description = function(){
	return "method '" + this.name + "'";
}
MethodType.prototype.callGenerator = function(cx/*PType*/){
	return this.call(cx, this.type);
}
function MethodType(id/*STRING*/, t/*PDefinedProcedure*/, call/*CallGenerator*/){
	Procedure.Std.call(this, id, null);
	this.type = null;
	this.call = null;
	this.type = t;
	this.call = call;
}
MethodVariable.prototype.idType = function(){
	return "method";
}

function makeMethod(type/*PType*/){
	return new MethodVariable(type);
}
exports.MethodType = MethodType;
exports.MethodVariable = MethodVariable;
exports.makeMethod = makeMethod;
