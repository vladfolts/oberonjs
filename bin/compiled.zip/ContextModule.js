var RTL$ = require("eberon/eberon_rtl.js");
var ContextHierarchy = require("js/ContextHierarchy.js");
var Errors = require("js/Errors.js");
var LanguageContext = require("js/LanguageContext.js");
var Scope = require("js/Scope.js");
var ScopeBase = require("js/ScopeBase.js");
var Symbols = require("js/Symbols.js");
var Types = require("js/Types.js");
function Declaration(){
	ContextHierarchy.Node.apply(this, arguments);
	this.name = '';
	this.imports = {};
	this.moduleScope = null;
	this.moduleGen = null;
}
RTL$.extend(Declaration, ContextHierarchy.Node);
Declaration.prototype.handleIdent = function(id/*STRING*/){
	if (this.name.length == 0){
		this.name = id;
		var root = this.root();
		this.moduleScope = new Scope.Module(id, root.language().stdSymbols);
		root.pushScope(this.moduleScope);
	}
	else if (id == this.name){
		var scope = this.moduleScope;
		scope.close();
		Scope.defineExports(scope);
		this.codeGenerator().write(this.moduleGen.epilog(scope.exports));
	}
	else {
		Errors.raise("original module name '" + this.name + "' expected, got '" + id + "'");
	}
};
Declaration.prototype.findModule = function(name/*STRING*/){
	if (name == this.name){
		Errors.raise("module '" + this.name + "' cannot import itself");
	}
	return this.root().findModule(name);
};
Declaration.prototype.handleImport = function(modules/*ARRAY OF PSymbol*/){
	var moduleAliases = {};
	var root = this.root();
	var scope = root.currentScope();
	for (var i = 0; i <= modules.length - 1 | 0; ++i){
		var s = modules[i];
		var name = RTL$.typeGuard(s.info(), Types.Module).name;
		this.imports[name] = s;
		scope.addSymbol(s, false);
		moduleAliases[name] = s.id();
	}
	this.moduleGen = root.language().moduleGenerator(this.name, moduleAliases);
	this.codeGenerator().write(this.moduleGen.prolog());
};
Declaration.prototype.qualifyScope = function(scope/*PType*/){
	var result = '';
	if (scope != this.moduleScope && scope instanceof Scope.Module){
		var id = scope.symbol.id();
		if (!Object.prototype.hasOwnProperty.call(this.imports, id)){
			result = "module '" + id + "' is not imported";
		}
		else {
			result = RTL$.getMappedValue(this.imports, id).id() + ".";
		}
	}
	return result;
};
exports.Declaration = Declaration;
