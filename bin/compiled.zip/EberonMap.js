var RTL$ = require("rtl.js");
var Context = require("js/Context.js");
var Types = require("js/Types.js");
RTL$.extend(Type, Types.StorageType);
Type.prototype.initializer = function(cx/*Type*/){
	return "{}";
}
Type.prototype.description = function(){
	return "MAP " + this.from.description() + " TO " + this.to.description();
}
function Type(from/*PType*/, to/*PType*/){
	Types.StorageType.call(this);
	this.from = from;
	this.to = to;
}
exports.Type = Type;
