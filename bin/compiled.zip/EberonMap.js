var RTL$ = require("rtl.js");
var Context = require("js/Context.js");
var Types = require("js/Types.js");
RTL$.extend(Type, Types.StorageType);
Type.prototype.initializer = function(cx/*Type*/){
	return "{}";
}
Type.prototype.description = function(){
	return "MAP OF " + this.valueType.description();
}
function Type(valueType/*PType*/){
	Types.StorageType.call(this);
	this.valueType = valueType;
}
exports.Type = Type;
