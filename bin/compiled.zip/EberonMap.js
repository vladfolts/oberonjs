var RTL$ = require("rtl.js");
var Context = require("js/Context.js");
var Types = require("js/Types.js");
RTL$.extend(Type, Types.StorageType);
Type.prototype.initializer = function(cx/*Type*/){
	return "{}";
}
Type.prototype.description = function(){
	return "MAP OF " + this.type.description();
}
function Type(type/*PType*/){
	Types.StorageType.call(this);
	this.type = type;
}
exports.Type = Type;
