var RTL$ = require("rtl.js");
var Code = require("js/Code.js");
var Context = require("js/Context.js");
var EberonString = require("js/EberonString.js");
var EberonTypes = require("js/EberonTypes.js");
var LanguageContext = require("js/LanguageContext.js");
var Procedure = require("js/Procedure.js");
var Types = require("js/Types.js");
var removeMethodName = "remove";
RTL$.extend(Type, Types.StorageType);
function Method(){
	Procedure.Std.apply(this, arguments);
}
RTL$.extend(Method, Procedure.Std);
RTL$.extend(MethodRemoveField, EberonTypes.MethodField);
function MethodRemove(){
	Method.apply(this, arguments);
}
RTL$.extend(MethodRemove, Method);
function MethodCallRemove(){
	Procedure.StdCall.call(this);
}
RTL$.extend(MethodCallRemove, Procedure.StdCall);
Type.prototype.initializer = function(cx/*Type*/){
	return "{}";
}
Type.prototype.description = function(){
	return "MAP OF " + this.valueType.description();
}
function Type(valueType/*PType*/){
	Types.StorageType.call(this);
	this.valueType = valueType;
}
Type.prototype.denote = function(id/*STRING*/){
	var result = null;
	if (id == removeMethodName){
		result = new MethodRemoveField();
	}
	else {
		result = Types.StorageType.prototype.denote.call(this, id);
	}
	return result;
}
MethodCallRemove.prototype.make = function(args/*ARRAY OF PExpression*/, cx/*PType*/){
	var argCode = Procedure.makeArgumentsCode(cx);
	var arg = Procedure.checkSingleArgument(args, this, cx.types, argCode);
	return Code.makeSimpleExpression("[" + argCode.result() + "]", null);
}
MethodRemove.prototype.description = function(){
	return "MAP's method 'remove'";
}
MethodRemove.prototype.callGenerator = function(cx/*PType*/){
	var call = new MethodCallRemove();
	var a = new Types.ProcedureArgument(new Types.OpenArray(Types.basic().ch), false);
	call.args.push(a);
	return Procedure.makeCallGenerator(call, cx);
}
function MethodRemoveField(){
	EberonTypes.MethodField.call(this, new MethodRemove(removeMethodName, null));
}
MethodRemoveField.prototype.designatorCode = function(leadCode/*STRING*/){
	return new Types.FieldCode("delete " + leadCode, "", "");
}
exports.Type = Type;
