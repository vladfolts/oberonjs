var RTL$ = require("rtl.js");
var Code = require("js/Code.js");
var CodePrecedence = require("js/CodePrecedence.js");
var OberonRtl = require("js/OberonRtl.js");
var Operator = require("js/Operator.js");
var Types = require("js/Types.js");

function opAddStr(left/*PConst*/, right/*PConst*/){
	return Code.makeStringConst(RTL$.typeGuard(left, Code.StringConst).value + RTL$.typeGuard(right, Code.StringConst).value);
}

function opEqualStr(left/*PConst*/, right/*PConst*/){
	return Code.makeIntConst(RTL$.typeGuard(left, Code.StringConst).value == RTL$.typeGuard(right, Code.StringConst).value ? 1 : 0);
}

function opNotEqualStr(left/*PConst*/, right/*PConst*/){
	return Code.makeIntConst(RTL$.typeGuard(left, Code.StringConst).value != RTL$.typeGuard(right, Code.StringConst).value ? 1 : 0);
}

function opLessStr(left/*PConst*/, right/*PConst*/){
	return Code.makeIntConst(RTL$.typeGuard(left, Code.StringConst).value < RTL$.typeGuard(right, Code.StringConst).value ? 1 : 0);
}

function opGreaterStr(left/*PConst*/, right/*PConst*/){
	return Code.makeIntConst(RTL$.typeGuard(left, Code.StringConst).value > RTL$.typeGuard(right, Code.StringConst).value ? 1 : 0);
}

function opLessEqualStr(left/*PConst*/, right/*PConst*/){
	return Code.makeIntConst(RTL$.typeGuard(left, Code.StringConst).value <= RTL$.typeGuard(right, Code.StringConst).value ? 1 : 0);
}

function opGraterEqualStr(left/*PConst*/, right/*PConst*/){
	return Code.makeIntConst(RTL$.typeGuard(left, Code.StringConst).value >= RTL$.typeGuard(right, Code.StringConst).value ? 1 : 0);
}

function addStr(left/*PExpression*/, right/*PExpression*/, rtl/*PType*/){
	return Operator.binaryWithCode(left, right, rtl, opAddStr, " + ", CodePrecedence.addSub);
}

function equalStr(left/*PExpression*/, right/*PExpression*/, rtl/*PType*/){
	return Operator.equal(left, right, rtl, opEqualStr, " == ");
}

function notEqualStr(left/*PExpression*/, right/*PExpression*/, rtl/*PType*/){
	return Operator.equal(left, right, rtl, opNotEqualStr, " != ");
}

function lessStr(left/*PExpression*/, right/*PExpression*/, rtl/*PType*/){
	return Operator.relational(left, right, rtl, opLessStr, " < ");
}

function greaterStr(left/*PExpression*/, right/*PExpression*/, rtl/*PType*/){
	return Operator.relational(left, right, rtl, opGreaterStr, " > ");
}

function lessEqualStr(left/*PExpression*/, right/*PExpression*/, rtl/*PType*/){
	return Operator.relational(left, right, rtl, opLessEqualStr, " <= ");
}

function greaterEqualStr(left/*PExpression*/, right/*PExpression*/, rtl/*PType*/){
	return Operator.relational(left, right, rtl, opGraterEqualStr, " >= ");
}

function inMap(left/*PExpression*/, right/*PExpression*/, rtl/*PType*/){
	return Code.makeSimpleExpression("Object.prototype.hasOwnProperty.call(" + right.code() + ", " + left.code() + ")", Types.basic().bool);
}
exports.addStr = addStr;
exports.equalStr = equalStr;
exports.notEqualStr = notEqualStr;
exports.lessStr = lessStr;
exports.greaterStr = greaterStr;
exports.lessEqualStr = lessEqualStr;
exports.greaterEqualStr = greaterEqualStr;
exports.inMap = inMap;
