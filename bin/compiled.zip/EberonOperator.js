var RTL$ = require("eberon/eberon_rtl.js");
var Cast = require("js/Cast.js");
var Code = require("js/Code.js");
var CodePrecedence = require("js/CodePrecedence.js");
var EberonMap = require("js/EberonMap.js");
var LanguageContext = require("js/LanguageContext.js");
var OberonRtl = require("js/OberonRtl.js");
var Operator = require("js/Operator.js");
var Types = require("js/Types.js");
function CastOpRecord(){
	Cast.CastOpRecord.call(this);
}
RTL$.extend(CastOpRecord, Cast.CastOpRecord);
var castOperations = new Cast.Operations();

function opAddStr(left/*PConst*/, right/*PConst*/){
	return Code.makeStringConst(RTL$.typeGuard(left, Code.StringConst).value + RTL$.typeGuard(right, Code.StringConst).value);
}

function opEqualStr(left/*PConst*/, right/*PConst*/){
	return Code.makeIntConst(RTL$.typeGuard(left, Code.StringConst).value == RTL$.typeGuard(right, Code.StringConst).value ? 1 : 0);
}

function opNotEqualStr(left/*PConst*/, right/*PConst*/){
	return Code.makeIntConst(RTL$.typeGuard(left, Code.StringConst).value != RTL$.typeGuard(right, Code.StringConst).value ? 1 : 0);
}

function opLessStr(left/*PConst*/, right/*PConst*/){
	return Code.makeIntConst(RTL$.typeGuard(left, Code.StringConst).value < RTL$.typeGuard(right, Code.StringConst).value ? 1 : 0);
}

function opGreaterStr(left/*PConst*/, right/*PConst*/){
	return Code.makeIntConst(RTL$.typeGuard(left, Code.StringConst).value > RTL$.typeGuard(right, Code.StringConst).value ? 1 : 0);
}

function opLessEqualStr(left/*PConst*/, right/*PConst*/){
	return Code.makeIntConst(RTL$.typeGuard(left, Code.StringConst).value <= RTL$.typeGuard(right, Code.StringConst).value ? 1 : 0);
}

function opGraterEqualStr(left/*PConst*/, right/*PConst*/){
	return Code.makeIntConst(RTL$.typeGuard(left, Code.StringConst).value >= RTL$.typeGuard(right, Code.StringConst).value ? 1 : 0);
}

function addStr(left/*PExpression*/, right/*PExpression*/){
	return Operator.binaryWithCode(left, right, opAddStr, " + ", CodePrecedence.addSub);
}

function equalStr(left/*PExpression*/, right/*PExpression*/){
	return Operator.equal(left, right, opEqualStr, " == ");
}

function notEqualStr(left/*PExpression*/, right/*PExpression*/){
	return Operator.equal(left, right, opNotEqualStr, " != ");
}

function lessStr(left/*PExpression*/, right/*PExpression*/){
	return Operator.relational(left, right, opLessStr, " < ");
}

function greaterStr(left/*PExpression*/, right/*PExpression*/){
	return Operator.relational(left, right, opGreaterStr, " > ");
}

function lessEqualStr(left/*PExpression*/, right/*PExpression*/){
	return Operator.relational(left, right, opLessEqualStr, " <= ");
}

function greaterEqualStr(left/*PExpression*/, right/*PExpression*/){
	return Operator.relational(left, right, opGraterEqualStr, " >= ");
}

function inMap(left/*PExpression*/, right/*PExpression*/, rtl/*PType*/){
	return Code.makeSimpleExpression("Object.prototype.hasOwnProperty.call(" + right.code() + ", " + left.code() + ")", Types.basic().bool);
}

function generateTypeInfo(type/*PType*/){
	var result = '';
	if (type instanceof EberonMap.Type){
		result = "{map: " + generateTypeInfo(type.valueType) + "}";
	}
	else {
		result = Types.generateTypeInfo(type);
	}
	return result;
}
CastOpRecord.prototype.assign = function(cx/*PType*/, left/*PExpression*/, right/*PExpression*/){
	var result = '';
	var leftCode = left.code();
	var leftLval = left.lval();
	if (leftCode != leftLval){
		if (right.designator() == null && left.type() == right.type()){
			result = leftLval + " = " + right.code();
		}
		else {
			result = leftLval + " = " + cx.rtl.clone(right.code(), generateTypeInfo(left.type()), Types.recordConstructor(cx, RTL$.typeGuard(left.type(), Types.Record)));
		}
	}
	else {
		result = Cast.CastOpRecord.prototype.assign.call(this, cx, left, right);
	}
	return result;
}
castOperations.castToUint8 = new Operator.CastToUint8();
castOperations.castToRecord = new CastOpRecord();
exports.castOperations = function(){return castOperations;};
exports.addStr = addStr;
exports.equalStr = equalStr;
exports.notEqualStr = notEqualStr;
exports.lessStr = lessStr;
exports.greaterStr = greaterStr;
exports.lessEqualStr = lessEqualStr;
exports.greaterEqualStr = greaterEqualStr;
exports.inMap = inMap;
exports.generateTypeInfo = generateTypeInfo;
